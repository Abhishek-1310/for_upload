# 🔧 Module 6: Microservices Architecture

> Microservices is the dominant architectural pattern at large-scale companies like Netflix, Amazon, and Uber.

---

## 1. Monolith vs Microservices

> 🔍 **What is it?**
> - **Monolith:** The entire application is one deployable unit — all modules (user, order, payment) live in one codebase and are deployed together.
> - **Microservices:** The application is split into many **small, independent services**, each responsible for one domain, with its own database and deployment lifecycle.

> 💡 **Why it matters?**
> The architecture you choose dictates how your teams work, how fast you can deploy, and how you can scale. Microservices let large organizations (Netflix has 700+ services) move fast independently without stepping on each other.

> ⚠️ **Without understanding the trade-off (Impact):**
> Choosing microservices too early (10 engineers, simple app) creates massive overhead — now you're managing 20 services, Kubernetes, distributed tracing, and inter-service networking. You spend more time on infrastructure than product. Sticking with a monolith too long (1000 engineers, one codebase) means **deployment takes 2 hours** and one team's bug takes down the entire product. The trade-off is real and choosing wrong at either end is expensive.

### Monolithic Architecture
```
┌────────────────────────────────────────┐
│             Single Application          │
│  ┌────────┐  ┌────────┐  ┌──────────┐  │
│  │  User  │  │ Order  │  │ Payment  │  │
│  │ Module │  │ Module │  │  Module  │  │
│  └────────┘  └────────┘  └──────────┘  │
│              Single DB                  │
└────────────────────────────────────────┘
```

**✅ Pros:** Simple to develop, test, deploy initially  
**❌ Cons:** Hard to scale parts independently, long deployments, team coupling, tech lock-in

---

### Microservices Architecture
```
       API Gateway
      /     |      \
User Svc  Order Svc  Payment Svc
  |DB|      |DB|        |DB|
```

Each service:
- Has its **own database**
- **Deploys independently**
- **Scales independently**
- Has a **single responsibility**

**✅ Pros:** Independent scaling, independent deployments, technology flexibility  
**❌ Cons:** Distributed systems complexity, network latency, data consistency challenges

---

## 2. When to Use Microservices

> 🔍 **What is it?**
> A decision framework for determining when the complexity of microservices is justified over the simplicity of a monolith. The answer depends on team size, scale requirements, deployment frequency, and organizational structure.

> 💡 **Why it matters?**
> Microservices are not inherently better than monoliths — they are a **trade-off**. Understanding when to make that trade-off prevents both premature optimization and technical debt from staying with a monolith too long.

> ⚠️ **Without this judgment (Impact):**
> Amazon famously migrated FROM a monolith TO microservices when they needed to scale. But many startups do the reverse — building microservices on day one, spending 80% of engineering time on infrastructure and 20% on product. This is one reason many funded startups fail: **over-engineering before product-market fit**. As Martin Fowler says: start with a monolith.
```
Team size < 10?         → Start with Monolith
System at scale?        → Consider Microservices
Different scaling needs? → Microservices
Multiple teams?          → Microservices
```

> **Famous quote:** "Don't start with microservices. Start with a monolith and extract services when you have clear boundaries." — Martin Fowler

---

## 3. Service Communication Patterns

> 🔍 **What is it?**
> In microservices, services need to talk to each other. There are two main approaches: **Synchronous** (direct request-response, like REST or gRPC) where the caller waits for a reply, and **Asynchronous** (event-driven, via message queues) where the caller sends a message and moves on.

> 💡 **Why it matters?**
> The communication pattern affects your system's **resilience and latency**. Synchronous chains mean failures propagate. Async messaging means services are decoupled and can fail independently without taking each other down.

> ⚠️ **Without the right choice (Impact):**
> Using only synchronous calls in a chain of 5 services means: if Service 5 is slow, **all 5 services are slow**. If Service 3 crashes, the entire chain fails. A single slow service creates a cascading slowdown that makes your whole system feel broken. Netflix found this out the hard way — it's why they pioneered the circuit breaker pattern.

### Synchronous (Request-Response)
```
Service A ──REST/gRPC──▶ Service B (waits for response)
```
✅ Simple, immediate response  
❌ Coupling (if B is down, A fails)  
❌ Cascading failures  

### Asynchronous (Event-Driven)
```
Service A ──event──▶ Message Queue ──▶ Service B (processes later)
```
✅ Decoupled (A doesn't care if B is slow/down)  
✅ Better for workflows that don't need immediate response  
❌ Harder to debug, eventual consistency  

---

## 4. Service Discovery ⭐

> 🔍 **What is it?**
> Service Discovery is the mechanism by which services in a dynamic environment **automatically find and connect to each other** without hardcoded IP addresses. Services register themselves with a registry when they start, and others look up their current location from that registry.

> 💡 **Why it matters?**
> In Kubernetes or cloud environments, service instances are constantly starting, stopping, and moving to different IPs. You can't hardcode addresses. Service discovery makes the system **self-configuring** — new instances automatically get traffic, crashed instances are automatically removed.

> ⚠️ **Without it (Impact):**
> You hardcode `http://192.168.1.42:3000` as the payment service address. When it restarts and gets a new IP, every other service that hardcoded that address **breaks simultaneously**. In Kubernetes where pods restart constantly, hardcoding IPs makes the system completely unmanageable. This is why service discovery is a fundamental building block of any microservices platform.

**Problem:** In dynamic environments (Kubernetes), service IPs change constantly.  
**Solution:** Service Registry — services register themselves, others look them up.

### Client-Side Discovery
```
Service A ──query──▶ Service Registry ──▶ returns [Service B IPs]
Service A picks one and calls directly
```

### Server-Side Discovery
```
Service A ──▶ Load Balancer ──▶ Service Registry ──▶ Service B
```

### Tools
| Tool | Type |
|------|------|
| **Consul** | Service registry + health checking |
| **Eureka** | Netflix OSS, Java-focused |
| **Kubernetes DNS** | Automatic in K8s |
| **AWS Cloud Map** | AWS native |

---

## 5. Circuit Breaker Pattern ⭐

> 🔍 **What is it?**
> A Circuit Breaker is a design pattern that **wraps calls to external services** and monitors for failures. If failures exceed a threshold, the circuit "opens" and calls to that service are immediately rejected (fast fail) without actually trying to call it — until it recovers.

> 💡 **Why it matters?**
> Without a circuit breaker, when Service B is struggling, Service A keeps sending requests — those requests pile up, threads exhaust, and **Service A also goes down** (cascading failure). The circuit breaker stops this: as soon as B is struggling, A fast-fails instantly, freeing its resources and staying healthy.

> ⚠️ **Without it (Impact):**
> Netflix's entire streaming platform was nearly brought down by a single failing recommendation service because every request waited for it to respond. This is what motivated them to build **Hystrix** (the first famous circuit breaker library) and publish it as open source. Without circuit breakers in a microservices architecture, **one struggling service can cascade and take down your entire platform** within minutes. This is not theoretical — it has happened at Netflix, Amazon, and many others.

**Problem:** Service A calls Service B which is failing. A keeps trying → threads pile up → A also crashes.

**Solution:** Circuit Breaker — detect failures and stop calling failing service.

```
States:
CLOSED ──(failures exceed threshold)──▶ OPEN
  ↑                                        │
  └──(some requests succeed)── HALF-OPEN ◀─┘
                                 (let some requests through to test)
```

| State | Behavior |
|-------|---------|
| **CLOSED** | Normal operation, requests pass through |
| **OPEN** | Requests fail immediately (fast fail), don't call downstream |
| **HALF-OPEN** | Allow a few requests to test if service recovered |

```python
# Conceptual Circuit Breaker
class CircuitBreaker:
    def call(self, service_fn):
        if self.state == OPEN:
            raise ServiceUnavailable("Circuit is OPEN")  # Fast fail
        try:
            result = service_fn()
            self.on_success()
            return result
        except Exception:
            self.on_failure()
            raise
```

> **Libraries:** Hystrix (Netflix), Resilience4j (Java), Polly (.NET), Pybreaker (Python)

---

## 6. API Gateway vs Service Mesh

> 🔍 **What is it?**
> - **API Gateway:** Handles **external (north-south) traffic** — requests coming from clients outside your system. It manages authentication, routing, rate limiting for inbound traffic.
> - **Service Mesh:** Handles **internal (east-west) traffic** — communication between microservices inside your system. It manages mTLS, retries, observability, and circuit breaking automatically via sidecar proxies.

> 💡 **Why it matters?**
> These solve different problems at different layers. The API Gateway secures and manages what comes IN. The Service Mesh manages how internal services talk to EACH OTHER. Both are needed in a mature microservices platform.

> ⚠️ **Without them (Impact):**
> Without an API Gateway: each microservice handles its own auth, rate limiting, and SSL — duplicated logic everywhere, easy to miss. Without a Service Mesh: there's no encryption between internal services (so a compromised internal service can eavesdrop on all traffic), no automatic retries, and no distributed traces — debugging production issues becomes **detective work across 50 services' logs manually**.

### API Gateway (North-South Traffic)
- Handles **external** client to service communication
- Authentication, rate limiting, routing
- Examples: Kong, AWS API Gateway

### Service Mesh (East-West Traffic)
- Handles **internal** service-to-service communication
- mTLS, observability, circuit breaking — automatically!
- Works via **sidecar proxy** (injected alongside each service)

```
┌─────────────────────────────────────┐
│  Service A  │  Sidecar Proxy (Envoy) │──▶ Service Mesh Control Plane
│  (App Code) │  (handles: mTLS,       │
│             │   retries, metrics)    │
└─────────────────────────────────────┘
```

> **Examples:** Istio, Linkerd, AWS App Mesh

---

## 7. Microservices Design Patterns

### Strangler Fig Pattern
Migrate monolith to microservices **incrementally**.

```
Step 1: All traffic → Monolith
Step 2: New feature → New Microservice, rest → Monolith
Step 3: Extract User Service → Microservice
Step 4: Extract Order Service → Microservice
Step N: Monolith is gone!
```

---

### Sidecar Pattern
Deploy helper functionality as a separate process alongside the main service.

```
┌────────────────────────────────┐
│  Main Container (your app)     │
│  Sidecar Container:            │
│    - Logging agent             │
│    - Metrics collector         │
│    - Service mesh proxy        │
└────────────────────────────────┘
```

---

### BFF (Backend for Frontend) Pattern
Create separate backend services tailored for each frontend.

```
Mobile App ──▶ Mobile BFF ──▶ Microservices
Web App    ──▶ Web BFF    ──▶ Microservices
3rd Party  ──▶ Public API ──▶ Microservices
```
✅ Each BFF optimized for its client's needs  
✅ Mobile can get compact responses, Web can get richer data  

---

## 8. Data Management in Microservices

### Database Per Service ⭐
```
User Service   ──▶ Users DB (PostgreSQL)
Order Service  ──▶ Orders DB (MongoDB)
Payment Service ──▶ Payments DB (PostgreSQL)
Search Service ──▶ Search DB (Elasticsearch)
```
✅ Services are truly independent  
✅ Each uses best DB for its needs  
❌ No cross-service joins  
❌ Distributed transactions needed  

### Shared Database (Anti-Pattern!)
```
All Services ──▶ Single DB  ← ❌ AVOID
```
❌ Services are coupled at the data layer  
❌ One bad query can take down all services  

---

## 9. Observability ⭐

> 🔍 **What is it?**
> Observability is the ability to understand the **internal state of your system** from its external outputs. The three pillars are: **Logs** (what happened), **Metrics** (how much/how fast), and **Traces** (which path did a request take through all services).

> 💡 **Why it matters?**
> In microservices, a user request touches 10+ services. When something goes wrong, you need to find **where and why** quickly. Observability is your debugging toolkit for distributed systems. Without it, production incidents become fire-fighting in the dark.

> ⚠️ **Without it (Impact):**
> An API is slow. Is it the DB? The network? Service A? Service C? Without distributed tracing, you manually SSH into each server, grep through logs, and spend **hours debugging what took 200ms**. Without metrics, you don't know a service is degrading until users are already complaining. A major outage without observability can take **days to resolve** instead of minutes. This is why SRE teams at Google treat observability as non-negotiable.

In microservices, debugging requires three pillars:

### Three Pillars of Observability

| Pillar | What it is | Tool Examples |
|--------|-----------|--------------|
| **Logs** | Timestamped records of events | ELK Stack, Splunk, CloudWatch |
| **Metrics** | Numerical measurements over time | Prometheus, Grafana, Datadog |
| **Traces** | Track a request across services | Jaeger, Zipkin, AWS X-Ray |

### Distributed Tracing
```
User Request ──▶ API Gateway ──▶ User Service ──▶ Order Service ──▶ DB
                     │               │                 │
                 trace-id: abc   trace-id: abc    trace-id: abc
                 span: 1ms       span: 5ms        span: 20ms
```
All spans collected and visualized — you can see WHERE time is spent!

### Key Metrics to Monitor (RED Method)
| Metric | Description |
|--------|-------------|
| **R**ate | Requests per second |
| **E**rrors | Error rate (%) |
| **D**uration | Latency (p50, p95, p99) |

---

## 10. Container & Orchestration

### Docker
Packages service + dependencies into a **container**.
```dockerfile
FROM node:18
WORKDIR /app
COPY . .
RUN npm install
EXPOSE 3000
CMD ["node", "server.js"]
```

### Kubernetes (K8s)
Orchestrates containers at scale.

| K8s Concept | Description |
|------------|-------------|
| **Pod** | Smallest deployable unit (1+ containers) |
| **Deployment** | Manages pod replicas, rolling updates |
| **Service** | Stable DNS name + load balancing for pods |
| **Ingress** | HTTP routing from outside to services |
| **ConfigMap** | External configuration |
| **Secret** | Sensitive data (passwords, keys) |
| **HPA** | Horizontal Pod Autoscaler — auto-scale pods |

---

## ✅ Module 6 Summary Checklist

- [ ] Can explain monolith vs microservices trade-offs
- [ ] Know when NOT to use microservices
- [ ] Understand circuit breaker pattern (3 states)
- [ ] Know API Gateway vs Service Mesh difference
- [ ] Understand Database per Service pattern
- [ ] Know 3 pillars of observability
- [ ] Can explain BFF and Strangler Fig patterns

---

**Next:** [Module 7 - Real World Designs →](../07-Real-World-Designs/README.md)
