# 📘 Module 1: Fundamentals of System Design

> These are the **building blocks** every architect must know cold.

---

## 1. Scalability

> 🔍 **What is it?**
> Scalability is the ability of a system to handle **growing load** (more users, more data, more traffic) without degrading performance. It means your system can grow as your user base grows.

> 💡 **Why it matters?**
> Every successful product grows. Instagram started with 13 employees and millions of users. If your system can't scale, it **crashes under success** — the worst possible time to fail. Scalability is what separates a toy project from a production-grade system.

> ⚠️ **Without it (Impact):**
> Your app works fine with 100 users but crashes with 100,000. You'd need to rewrite your entire architecture under pressure, lose users, lose revenue, and damage your reputation. Amazon calculated that every **100ms of latency cost them 1% in sales**. Imagine your whole system being down.

Scalability = ability of a system to handle **growing load** without degrading performance.

### 🔼 Vertical Scaling (Scale Up)
- Add more CPU/RAM/Disk to **one machine**
- ✅ Simple, no code changes
- ❌ Has a hard limit, single point of failure, expensive

### 🔀 Horizontal Scaling (Scale Out)
- Add **more machines** to your pool
- ✅ Theoretically infinite scale, fault-tolerant
- ❌ Complexity: distributed state, network issues, data consistency

```
Vertical:       Horizontal:
┌──────────┐    ┌──────┐ ┌──────┐ ┌──────┐
│  Bigger  │    │ Srv1 │ │ Srv2 │ │ Srv3 │
│  Server  │    └──────┘ └──────┘ └──────┘
└──────────┘         (Load Balancer in front)
```

> **Interview Tip:** Always prefer horizontal scaling for large-scale systems. Vertical has a ceiling.

---

## 2. Availability vs Reliability

> 🔍 **What is it?**
> - **Availability** = the % of time a system is up and responding to requests.
> - **Reliability** = the system produces **correct, consistent results** over time (doesn't corrupt or lose data).
> - **Fault Tolerance** = the system keeps working even when parts of it fail.

> 💡 **Why it matters?**
> Users expect your system to **always be there**. Every minute of downtime = lost users, lost money, broken trust. For financial or healthcare systems, downtime can even be life-threatening.

> ⚠️ **Without it (Impact):**
> A system with no availability strategy could be down for **days per year**. Netflix going down during prime time costs millions. Banks that are unavailable block customer transactions. Even 30 seconds of downtime on Google causes massive financial and reputational damage. Without fault tolerance, one failing server takes down your whole app.

| Term | Definition | Example |
|------|-----------|---------|
| **Availability** | % of time system is operational | 99.99% = ~52 min downtime/year |
| **Reliability** | Probability of correct operation over time | System doesn't corrupt data |
| **Fault Tolerance** | Continues working despite failures | Netflix still works if one DC is down |

### Availability Nines

| Level | Uptime | Downtime/Year |
|-------|--------|---------------|
| 99% | Two nines | ~3.65 days |
| 99.9% | Three nines | ~8.7 hours |
| 99.99% | Four nines | ~52 minutes |
| 99.999% | Five nines | ~5 minutes |

> **Key:** Most enterprise systems target **99.99%**. Achieving 5 nines is extremely expensive.

---

## 3. CAP Theorem ⭐ (Very Important)

> 🔍 **What is it?**
> A foundational theorem in distributed systems by Eric Brewer: in a **distributed system**, you can ONLY guarantee **2 out of these 3 properties** simultaneously — Consistency, Availability, and Partition Tolerance.

> 💡 **Why it matters?**
> Every distributed database makes a trade-off based on CAP. Understanding this lets you **choose the right database** for each use case. It's why you'd use Cassandra for social media and PostgreSQL for banking — they make different CAP trade-offs.

> ⚠️ **Without understanding it (Impact):**
> You might choose a Cassandra (AP) database for banking — and end up with **inconsistent account balances**. Or use MySQL (CP) for a high-traffic social feed — and the DB starts **refusing requests** during network hiccups, causing massive downtime. Wrong choice here causes serious bugs or production outages that are very hard to fix later.

> In a **distributed system**, you can only guarantee **2 out of 3**:

```
         Consistency
              /\
             /  \
            /    \
           /  ??  \
          /________\
   Availability   Partition
                  Tolerance
```

| Property | Meaning |
|----------|---------|
| **C**onsistency | Every read gets the most recent write |
| **A**vailability | Every request gets a (non-error) response |
| **P**artition Tolerance | System works even if network splits |

### In Practice:
> **Network partitions WILL happen.** So you must choose: **CP or AP**.

| Choice | Examples | When to Use |
|--------|---------|-------------|
| **CP** (Consistent + Partition Tolerant) | MongoDB, HBase, Zookeeper | Banking, transactions |
| **AP** (Available + Partition Tolerant) | Cassandra, DynamoDB, CouchDB | Social media, DNS, shopping carts |

---

## 4. ACID vs BASE

> 🔍 **What is it?**
> Two opposite sets of guarantees that databases can provide:
> - **ACID** = strict, strong guarantees used by relational (SQL) databases to ensure every transaction is safe.
> - **BASE** = relaxed, flexible guarantees used by NoSQL databases to enable massive scale.

> 💡 **Why it matters?**
> ACID ensures data is **always correct and consistent** — critical for money, orders, medical records. BASE allows **massive scale and speed** at the cost of temporary inconsistency — acceptable for social feeds, product views, analytics.

> ⚠️ **Without knowing this (Impact):**
> You might store bank transactions in an "eventually consistent" NoSQL DB — meaning a user's balance shows $500 even after spending $600. OR you'd use a heavy ACID database for a voting counter that handles 10M concurrent writes — and it **collapses under load**. This is one of the most costly architectural mistakes in real systems.

### ACID (Relational Databases)
| Property | Meaning |
|----------|---------|
| **A**tomicity | All or nothing — transaction fully completes or fully rolls back |
| **C**onsistency | DB goes from one valid state to another |
| **I**solation | Concurrent transactions don't interfere |
| **D**urability | Committed data is permanent (even after crash) |

### BASE (NoSQL Databases)
| Property | Meaning |
|----------|---------|
| **B**asically **A**vailable | System guarantees availability |
| **S**oft State | State may change over time (even without input) |
| **E**ventual Consistency | System will EVENTUALLY become consistent |

> **Rule of thumb:** Use ACID for financial/critical data. Use BASE for high-scale, eventual-consistency-tolerant data.

---

## 5. Latency vs Throughput

> 🔍 **What is it?**
> - **Latency** = how long ONE request takes from start to finish (speed of a single operation).
> - **Throughput** = how many requests the system handles per second (the volume capacity).
> - **Bandwidth** = the maximum amount of data that can travel through a network link per second.

> 💡 **Why it matters?**
> You can't optimize what you don't measure. A system with low latency **feels fast** to the user. A system with high throughput can **serve many users simultaneously**. Architects must balance both — you need speed AND scale.

> ⚠️ **Without understanding this (Impact):**
> You might optimize only for throughput — system handles 1M req/sec but each takes 10 seconds (users think it's broken). Or optimize only for latency — each request takes 1ms but the system handles only 10 concurrent users and crashes under real load. Google found that a **0.5 second slowdown reduced searches by 20%**. These numbers have real business consequences.

| Term | Definition | Unit |
|------|-----------|------|
| **Latency** | Time to complete ONE request | ms, µs |
| **Throughput** | Requests handled per unit time | RPS (req/sec), QPS |
| **Bandwidth** | Max data transferred per second | Mbps, Gbps |

### Latency Numbers Every Engineer Must Know

```
L1 cache reference:           0.5 ns
Branch mispredict:            5   ns
L2 cache reference:           7   ns
Mutex lock/unlock:           25   ns
Main memory reference:      100   ns
SSD random read:          150,000 ns  = 0.15 ms
HDD seek:              10,000,000 ns  = 10 ms
Network: same DC:           500,000 ns  = 0.5 ms
Network: SF → NYC:       40,000,000 ns  = 40 ms
Network: SF → Australia: 183,000,000 ns = 183 ms
```

> **Key Insight:** Memory is 1000x faster than SSD. SSD is 100x faster than HDD. Minimize disk I/O!

---

## 6. Load Balancing

> 🔍 **What is it?**
> A Load Balancer is a component that **distributes incoming network traffic evenly across multiple servers**, so no single server is overwhelmed. It sits in front of your server pool and routes each request intelligently.

> 💡 **Why it matters?**
> Without load balancing, one server handles everything — it becomes the ceiling of your system's capacity. With load balancing, you can add 10, 100, or 1000 servers transparently. It also provides **automatic failover** — if a server dies, requests are rerouted to healthy ones instantly.

> ⚠️ **Without it (Impact):**
> Your single server gets overwhelmed, slows down, and eventually crashes. There is no failover — if that server goes down, your **entire application goes down** with it. You can never scale horizontally without a load balancer. This is the most common Single Point of Failure (SPOF) in naive architectures.

Distributes incoming traffic across multiple servers.

### Algorithms
| Algorithm | How it works | Best for |
|-----------|-------------|---------|
| **Round Robin** | Request 1→Srv1, Req2→Srv2, Req3→Srv3... | Uniform servers |
| **Least Connections** | Route to server with fewest active connections | Varying request lengths |
| **IP Hash** | Hash client IP → always same server | Session persistence |
| **Weighted** | Servers get traffic proportional to weight | Different server capacities |

```
           ┌─────────────────┐
Clients ──▶│  Load Balancer  │──▶ Server 1
           │  (HAProxy/Nginx)│──▶ Server 2
           └─────────────────┘──▶ Server 3
```

### Layer 4 vs Layer 7 Load Balancing
| Type | Level | Sees | Speed |
|------|-------|------|-------|
| L4 | Transport (TCP/UDP) | IP + Port only | Faster |
| L7 | Application (HTTP) | Headers, URL, cookies | Smarter (route /api vs /static) |

---

## 7. Consistent Hashing ⭐

> 🔍 **What is it?**
> A special hashing technique where both servers and data keys are placed on a virtual "ring". Each key is assigned to the nearest server clockwise on the ring. When a server is added or removed, **only the keys near that server need to be moved** — not all keys.

> 💡 **Why it matters?**
> In distributed caches or databases, servers are frequently added or removed (scaling up, failures, maintenance). Standard hashing remaps almost all data when the server count changes. Consistent hashing minimizes this disruption — only `K/N` keys move instead of most of them.

> ⚠️ **Without it (Impact):**
> Every time you add a cache server (e.g., scaling from 5 to 6 Redis nodes), nearly **83% of all cache keys point to wrong servers** → instant cache miss storm → all 83% of requests simultaneously hit the database → database is overwhelmed → **system goes down**. This exact scenario has caused major production outages at companies that didn't use consistent hashing.

**Problem:** When you add/remove servers, standard modulo hashing (`hash(key) % N`) remaps almost ALL keys.

**Solution:** Consistent Hashing — only `K/N` keys need to move (K=keys, N=nodes).

```
          0
        /   \
      270   90
        \   /
         180

Servers placed on ring at hashed positions.
A key maps to the NEXT server clockwise.
Add/remove a server → only neighbor keys move.
```

> **Used in:** Amazon DynamoDB, Apache Cassandra, Memcached, Akamai CDN

---

## 8. SQL vs NoSQL — Quick Summary

> 🔍 **What is it?**
> Two broad families of databases:
> - **SQL (Relational):** Structured tables, fixed schema, powerful joins, full ACID support. (PostgreSQL, MySQL)
> - **NoSQL (Non-relational):** Flexible schema, built for horizontal scaling, multiple data models — document, key-value, graph, wide-column. (MongoDB, Cassandra, Redis)

> 💡 **Why it matters?**
> The database you choose **shapes your entire architecture**. Each is optimized for different patterns. The wrong choice causes performance bottlenecks you can't easily fix later (changing databases at scale is incredibly painful and expensive).

> ⚠️ **Without knowing the difference (Impact):**
> You might store user sessions in a relational DB (slow, expensive) instead of Redis. Or try to do complex financial multi-table transactions in MongoDB without ACID support — leading to **partial transactions and corrupted data**. Many startup failures trace back to the wrong database choice made early on.

| | SQL | NoSQL |
|--|-----|-------|
| **Schema** | Fixed (rigid) | Flexible (dynamic) |
| **Scaling** | Vertical (mostly) | Horizontal |
| **ACID** | ✅ Full support | Partial/None |
| **Query** | SQL (powerful joins) | Limited (no joins usually) |
| **Examples** | MySQL, PostgreSQL | MongoDB, Cassandra, Redis |
| **Best for** | Complex queries, transactions | High scale, flexible data |

---

## 9. Single Point of Failure (SPOF)

> 🔍 **What is it?**
> A Single Point of Failure is any **single component** in your system whose failure would cause the **entire system to stop working**. It's the weakest link — if it breaks, everything stops regardless of how robust the rest of the system is.

> 💡 **Why it matters?**
> In real production systems, components WILL fail — hardware dies, networks disconnect, processes crash. Good system design anticipates failures and uses **redundancy** so the system survives individual component failures without user-facing impact.

> ⚠️ **Without eliminating it (Impact):**
> Your one database server gets a disk failure at 2 AM → entire application is down until someone manually fixes it. Even if you have 100 servers, one SPOF makes your system as reliable as that **single weakest component**. Real example: in 2021, a single BGP configuration mistake (one SPOF) took Facebook, Instagram, and WhatsApp **completely offline for 6+ hours**.

Any component whose failure takes down the entire system.

**How to eliminate SPOFs:**
- Redundancy (multiple instances)
- Failover mechanisms
- Health checks + auto-restart

```
BAD:                    GOOD:
  LB                    LB1  LB2  (Active-Active)
  |                      |    |
  DB ← SPOF             DB Primary + Replicas
```

---

## 10. Back-of-the-Envelope Estimation ⭐

> 🔍 **What is it?**
> A technique to make quick, rough calculations estimating the **scale and resource requirements** of a system — QPS (queries per second), storage size, bandwidth, memory needed — before writing any code.

> 💡 **Why it matters?**
> Estimation drives every architecture decision. Knowing you need 100 QPS vs 1,000,000 QPS changes EVERYTHING — database choice, caching strategy, number of servers, need for sharding. It prevents both over-engineering (building for 10x more than you need) and under-engineering (system collapses on launch day).

> ⚠️ **Without it (Impact):**
> You build a system for 1,000 users, it gets 1,000,000 on day one — and it **collapses under real load**. OR you spend 3 years building a complex, expensive distributed system for an app that never exceeds 500 users. In interviews, **skipping estimation is a major red flag** that signals you don't think at scale — critical for any senior or architect role.

Essential skill for interviews!

### Common Conversions
```
1 million   = 10^6
1 billion   = 10^9
1 trillion  = 10^12

1 KB = 10^3 bytes
1 MB = 10^6 bytes
1 GB = 10^9 bytes
1 TB = 10^12 bytes

1 day  = 86,400 seconds  ≈ 10^5 seconds
1 year = 3.15 × 10^7 seconds ≈ 30 million seconds
```

### Example: Twitter QPS Estimation
```
Daily Active Users (DAU)       = 300 million
Tweets per user per day        = 5
Total tweets/day               = 300M × 5 = 1.5 billion
Tweets per second (write QPS)  = 1.5B / 86400 ≈ 17,000 QPS

Read:Write ratio               = 100:1
Read QPS                       = 17,000 × 100 = 1.7 million QPS
```

---

## ✅ Module 1 Summary Checklist

- [ ] Can explain vertical vs horizontal scaling
- [ ] Can explain CAP theorem with real DB examples
- [ ] Know the difference between ACID and BASE
- [ ] Can calculate QPS, storage estimates
- [ ] Can explain consistent hashing
- [ ] Know latency numbers by heart

---

**Next:** [Module 2 - Databases →](../02-Databases/README.md)
