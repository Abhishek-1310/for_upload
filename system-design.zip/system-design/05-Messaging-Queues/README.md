# 📨 Module 5: Messaging & Queues

> Asynchronous messaging decouples services, improves resilience, and enables massive scale.

---

## 1. Why Messaging?

> 🔍 **What is it?**
> Messaging is a pattern where services communicate **asynchronously** by sending messages through an intermediary (a queue or topic), rather than calling each other directly. The sender puts a message in the queue and moves on — the receiver processes it whenever it's ready.

> 💡 **Why it matters?**
> Messaging **decouples services** so they don't need to be up at the same time. It buffers traffic spikes (the queue absorbs bursts), enables retries on failure, and allows multiple services to react to the same event independently. It transforms fragile chains of synchronous calls into resilient, independent workflows.

> ⚠️ **Without it (Impact):**
> In a synchronous order flow (Order → calls Inventory → calls Email → calls Analytics), if the Email service is slow, the entire user request **waits**. If Analytics crashes, the order **fails**. Every service is a potential point of failure for every other service. This creates **cascading failures** — one service going down takes the entire chain with it. This is exactly why companies like Uber, Netflix, and Amazon built their systems around async messaging.

**Without messaging (Synchronous):**
```
User ──▶ Order Service ──▶ [calls] Inventory Service (must wait)
                       ──▶ [calls] Email Service (must wait)
                       ──▶ [calls] Analytics Service (must wait)
Total latency = sum of ALL services
```

**With messaging (Asynchronous):**
```
User ──▶ Order Service ──▶ Queue ──▶ Inventory Service (async)
                            │──▶ Email Service (async)
                            └──▶ Analytics Service (async)
User gets response immediately! Services process in background.
```

**Benefits:**
- Services are **decoupled** (don't need to know about each other)
- **Failure isolation** (if email service dies, orders still work)
- **Load buffering** (queue absorbs traffic spikes)
- **Retry on failure** (messages stay in queue until processed)

---

## 2. Message Queue vs Pub/Sub

> 🔍 **What is it?**
> Two messaging patterns:
> - **Message Queue:** A producer sends a message; **exactly one consumer** processes it (the message is deleted after processing). Like a task queue.
> - **Pub/Sub (Publish-Subscribe):** A publisher sends a message to a topic; **all subscribers** receive their own copy. Like a broadcast channel.

> 💡 **Why it matters?**
> These solve different problems. A queue is for distributing work ("process this order"). Pub/Sub is for broadcasting events ("an order was placed" — notify inventory, email, analytics all at once). Picking the wrong model leads to either **missed notifications** or **double-processed tasks**.

> ⚠️ **Without knowing the difference (Impact):**
> Using a simple queue for notifications means only ONE of your three notification services (email, SMS, push) gets each notification — users randomly miss their alerts. Using Pub/Sub for task processing means all 10 consumer instances try to process the same payment simultaneously — **charging the customer 10 times**. Wrong model choice = serious bugs in production.

| | Message Queue | Pub/Sub |
|--|--------------|---------|
| **Model** | One producer, one consumer | One publisher, many subscribers |
| **Message read** | Once (deleted after consumed) | Each subscriber gets own copy |
| **Use case** | Task distribution, work queues | Event broadcasting, notifications |
| **Example** | RabbitMQ, Amazon SQS | Kafka, Google Pub/Sub, Redis Pub/Sub |

```
Message Queue:               Pub/Sub:
Producer ──▶ Queue ──▶ Consumer 1  Publisher ──▶ Topic ──▶ Subscriber 1
                  (only ONE consumer gets each message)         │──▶ Subscriber 2
                                                                └──▶ Subscriber 3
```

---

## 3. Apache Kafka ⭐ (Must Know)

> 🔍 **What is it?**
> Kafka is a **distributed event streaming platform** built by LinkedIn (now Apache). It stores events as an ordered, immutable log across partitioned topics. Consumers read from the log at their own pace and can **replay events from any point in history**. It's designed for extreme throughput (millions of events/second).

> 💡 **Why it matters?**
> Kafka is the backbone of real-time data pipelines at companies like LinkedIn (1 trillion messages/day), Uber (log aggregation + real-time analytics), Netflix (activity tracking), and Airbnb. It decouples producers from consumers, enables event replay for new services, and handles **traffic bursts that would kill any other system**.

> ⚠️ **Without it (Impact):**
> Without Kafka (using synchronous calls or simple queues): a traffic spike of 10x normal volume overwhelms your downstream services; a new analytics service can't retroactively process historical events; if a consumer is down for an hour, messages are lost forever; you can't replay events to rebuild a database after a corruption. These are **fundamental limitations** that Kafka solves and that become critical problems at scale.

Kafka is a **distributed event streaming platform** — the backbone of modern data pipelines.

### Core Concepts

```
Producers ──▶ Topics (Partitioned) ──▶ Consumers
                │
                ├── Partition 0: [msg1, msg4, msg7]
                ├── Partition 1: [msg2, msg5, msg8]
                └── Partition 2: [msg3, msg6, msg9]
```

| Concept | Description |
|---------|-------------|
| **Producer** | Sends messages to a topic |
| **Consumer** | Reads messages from a topic |
| **Topic** | Category/feed of messages |
| **Partition** | Ordered, immutable sequence within a topic |
| **Offset** | Position of a message in a partition |
| **Consumer Group** | Multiple consumers sharing work |
| **Broker** | Kafka server (usually 3+ for HA) |
| **Zookeeper/KRaft** | Cluster coordination |

### Why Kafka is Special

```
Traditional Queue:          Kafka:
Message consumed → deleted  Messages stored for N days (configurable)
One consumer per message    Multiple consumer groups, each reads all messages
Hard to replay              Can replay from any offset! ✅
```

### Kafka Guarantees

| Setting | Guarantee | Trade-off |
|---------|-----------|---------|
| **at-most-once** | Message delivered 0 or 1 times | Fast, but can lose messages |
| **at-least-once** | Message delivered 1+ times | Reliable, but duplicates possible |
| **exactly-once** | Exactly one delivery | Slowest, complex, but perfect |

### Consumer Groups
```
Topic: orders (3 partitions)
Consumer Group: payment-service (3 consumers)

Partition 0 ──▶ Consumer A
Partition 1 ──▶ Consumer B
Partition 2 ──▶ Consumer C
(Each partition → one consumer, enabling parallel processing)
```

### Kafka Use Cases
- **Event Sourcing:** Log all events as source of truth
- **Stream Processing:** Real-time analytics (with Kafka Streams)
- **Log Aggregation:** Collect logs from many services
- **Activity Tracking:** User clickstreams, page views
- **Metrics Pipeline:** Time-series data to monitoring systems

---

## 4. RabbitMQ

> 🔍 **What is it?**
> RabbitMQ is a traditional **message broker** that implements the AMQP protocol. It uses an **exchange** model where producers send messages to exchanges, and exchanges route them to queues based on routing rules (Direct, Topic, Fanout, Headers).

> 💡 **Why it matters?**
> RabbitMQ excels at **complex routing logic** and traditional task queue patterns. It supports priority queues, message acknowledgments, dead-letter queues, and rich exchange types that Kafka doesn't have natively. It's the go-to for backend job processing, email queues, and workflow orchestration.

> ⚠️ **Without knowing when to use it vs Kafka (Impact):**
> Using Kafka for a simple background job queue ("resize this image") adds massive operational complexity for no benefit. Using RabbitMQ to stream 1 million IoT sensor events per second means it **can't keep up** and messages pile up until memory is exhausted. The choice between them has real production consequences.

A traditional **message broker** with rich routing capabilities.

### Exchange Types

```
Direct Exchange:   Route by exact routing key match
Topic Exchange:    Route by pattern (user.*, *.payment)
Fanout Exchange:   Broadcast to ALL queues
Headers Exchange:  Route by message headers
```

### RabbitMQ vs Kafka

| | RabbitMQ | Kafka |
|--|----------|-------|
| **Model** | Push-based (broker pushes to consumer) | Pull-based (consumer pulls) |
| **Message Replay** | ❌ No (deleted after ack) | ✅ Yes (configurable retention) |
| **Throughput** | ~10K-50K msg/sec | **~1M+ msg/sec** |
| **Routing** | ✅ Complex routing logic | ❌ Simple (by partition key) |
| **Use Case** | Task queues, complex routing | Event streaming, high throughput |
| **Message Order** | Per-queue | Per-partition ✅ |

> **Rule:** Use **RabbitMQ** for task queues with complex routing. Use **Kafka** for high-throughput event streaming.

---

## 5. Event-Driven Architecture ⭐

> 🔍 **What is it?**
> An architectural pattern where system components **communicate by producing and consuming events** rather than by direct calls. When something happens ("Order Placed"), a service publishes an event, and any interested services react to it independently.

> 💡 **Why it matters?**
> Event-driven architecture enables **true service independence**. Adding a new feature (e.g., fraud detection on orders) means just subscribing to the existing "Order Placed" event — you don't modify the Order Service at all. Services evolve independently, scale independently, and fail independently.

> ⚠️ **Without it (Impact):**
> Adding fraud detection requires modifying the Order Service to call the Fraud Service directly. Now they're coupled — if Fraud Service is slow, orders slow down; if it crashes, orders might fail. After 5 years, your Order Service has 20 direct calls to 20 other services — it's a **"God Service"** that can't be changed without breaking everything. This is the architecture anti-pattern that event-driven design prevents.

System components communicate by **producing and consuming events**.

```
Order Placed Event
        │
        ├──▶ Payment Service   (charge customer)
        ├──▶ Inventory Service (reduce stock)
        ├──▶ Email Service     (send confirmation)
        └──▶ Analytics Service (record sale)
```

### Event Sourcing Pattern
Instead of storing current state, store **sequence of events**.

```
Traditional (Store State):   Event Sourcing (Store Events):
DB: { balance: 500 }         Events:
                               [1] AccountCreated: balance=0
                               [2] Deposited: amount=1000
                               [3] Withdrawn: amount=500
                               Current balance = 0+1000-500 = 500 ✅
```

✅ Complete audit trail  
✅ Can replay to rebuild state  
✅ Can create projections for different use cases  
❌ More complex  
❌ Querying current state requires replaying events  

---

## 6. CQRS Pattern ⭐

**Command Query Responsibility Segregation** — separate read and write models.

```
                ┌──────────┐
Commands ──▶    │  Write   │──▶ Event Bus ──▶ Read Model Update
(create,update) │  Model   │
                └──────────┘

                ┌──────────┐
Queries ──▶     │  Read    │──▶ Optimized Read DB (e.g., Elasticsearch)
(search,fetch)  │  Model   │
                └──────────┘
```

✅ Read and write can scale independently  
✅ Read model optimized for queries (denormalized)  
✅ Works great with Event Sourcing  
❌ Eventual consistency between models  
❌ More complexity  

---

## 7. Dead Letter Queue (DLQ)

> 🔍 **What is it?**
> A Dead Letter Queue is a special queue where messages go when they **fail to be processed** after a configured number of retries. Instead of being silently dropped, failed messages are moved to the DLQ for investigation and potential reprocessing.

> 💡 **Why it matters?**
> In any real system, some messages will fail to process — due to bugs, malformed data, or downstream service failures. A DLQ ensures **no message is silently lost**. You can inspect failed messages, fix the bug, and replay them.

> ⚠️ **Without it (Impact):**
> A payment processing message fails due to a temporary bug. Without a DLQ, it retries forever, **blocking the entire queue** for all other messages. Or it gets dropped silently — the customer is charged (or not charged) but never informed. Lost messages in a payment system mean lost revenue and legal issues. A DLQ is cheap to set up and **saves you from catastrophic silent failures**.

When a message fails to process after N retries, it goes to a **Dead Letter Queue**.

```
Queue ──▶ Consumer (fails 3 times) ──▶ Dead Letter Queue
                                              │
                                        Investigate,
                                        fix, replay
```

> Always configure DLQ! Without it, failed messages are silently dropped.

---

## 8. Message Patterns Summary

| Pattern | Description | Use Case |
|---------|-------------|---------|
| **Point-to-Point** | One producer, one consumer | Task delegation |
| **Pub/Sub** | One producer, many consumers | Notifications |
| **Request-Reply** | Producer waits for response | Sync over async |
| **Saga** | Sequence of events across services | Distributed transactions |
| **Outbox** | Write to DB + message table atomically | Reliable messaging |
| **Competing Consumers** | Multiple consumers share queue | Parallel processing |

---

## 9. Saga Pattern (Distributed Transactions) ⭐

> 🔍 **What is it?**
> A Saga is a sequence of **local transactions across multiple services**, each publishing an event to trigger the next step. If any step fails, **compensating transactions** are run in reverse to undo the previous steps — achieving eventual consistency without a distributed ACID transaction.

> 💡 **Why it matters?**
> In microservices, you can't have a single ACID transaction across multiple databases. But many business operations (place order → charge card → reserve inventory → ship) need all steps to succeed or all to be rolled back. Sagas provide a way to achieve this **without the 2-phase commit complexity**.

> ⚠️ **Without it (Impact):**
> A user places an order: payment succeeds, but inventory reservation fails. Without Saga-style compensation, you've charged the user but can't fulfill the order. Now you have **inconsistent data across services** — a nightmare to detect and fix manually. Or you use 2-Phase Commit (2PC) which requires all services to lock resources simultaneously — causing **massive performance degradation** and tight coupling. Saga is the practical solution that real systems use.

**Problem:** You need a transaction across multiple services but can't use DB ACID.

```
Order Saga:
1. Order Service: Create Order ──▶ success
2. Payment Service: Charge Card ──▶ success
3. Inventory Service: Reserve Item ──▶ FAIL!
   Compensating transactions:
3a. Inventory: (skip)
2a. Payment Service: Refund Card
1a. Order Service: Cancel Order
```

### Types
| Type | How | Trade-off |
|------|-----|---------|
| **Choreography** | Services emit events and react | Decoupled, but hard to track flow |
| **Orchestration** | Central orchestrator controls steps | Easy to track, but orchestrator can be bottleneck |

---

## ✅ Module 5 Summary Checklist

- [ ] Know difference between message queue and pub/sub
- [ ] Know Kafka core concepts (topic, partition, offset, consumer group)
- [ ] Can compare Kafka vs RabbitMQ and choose correctly
- [ ] Understand Event Sourcing and CQRS patterns
- [ ] Know what a Dead Letter Queue is
- [ ] Can explain the Saga pattern for distributed transactions

---

**Next:** [Module 6 - Microservices →](../06-Microservices/README.md)
