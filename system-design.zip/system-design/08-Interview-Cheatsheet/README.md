# 🎯 Module 8: Interview Cheatsheet

> Your quick reference before any system design interview.

---

## 🔑 The RESHADED Framework

> 🔍 **What is it?**
> RESHADED is a structured 8-step framework for tackling any system design interview question. Each letter stands for a phase of the design process that must be covered for a complete, senior-level answer.

> 💡 **Why it matters?**
> Interviewers evaluate not just your architecture, but your **thinking process**. RESHADED ensures you don't miss critical aspects like scale estimation, trade-off discussion, or failure handling — the parts that separate senior candidates from junior ones.

> ⚠️ **Without a framework (Impact):**
> Most failed interviews are not due to wrong architecture — they fail because the candidate **jumped to solutions without clarifying requirements**, or **never discussed trade-offs**, or forgot to mention monitoring. RESHADED is your insurance policy against these common pitfalls.

```
R - Requirements     → Ask functional + non-functional requirements
E - Estimation       → Calculate QPS, storage, bandwidth
S - Storage Schema   → Design DB tables/collections
H - High-Level       → Draw the architecture diagram
A - API Design       → Define key API endpoints
D - Deep Dive        → Focus on hardest components
E - Evaluation       → Monitoring, alerting, failure handling
D - Discuss Trade-offs → What are you sacrificing?
```

---

## ⚡ Quick Reference Cards

### Scaling Cheatsheet

> 🔍 **What is it?**
> A problem-solution reference mapping common system bottlenecks to their proven solutions.

> 💡 **Why it matters?**
> In interviews, you'll be asked "how would you scale this?" for every component. This cheatsheet gives you **instant answers** for the most common scaling problems you'll encounter.

> ⚠️ **Without knowing these solutions (Impact):**
> Saying "I'd just add more servers" to every problem is a red flag. Interviewers expect you to know **which tool solves which problem** — adding Redis for slow reads, Kafka for coupling, sharding for slow writes. Vague answers lose senior-level offers.

| Problem | Solution |
|---------|---------|
| Too many requests | Add more servers + Load Balancer |
| DB reads too slow | Add Read Replicas + Cache (Redis) |
| DB writes too slow | Sharding |
| Global users, high latency | CDN + Multi-region deployment |
| Single point of failure | Redundancy + Health checks |
| Slow static content | CDN (Cloudflare, CloudFront) |
| Large files | Object storage (S3) |
| Real-time communication | WebSocket |
| Service coupling | Message Queue (Kafka) |
| Slow searches | Search engine (Elasticsearch) |
| Rate limiting | Token Bucket + Redis |

---

### Database Selection Cheatsheet

| Data Type | Best Database | Why |
|-----------|--------------|-----|
| User profiles, orders | PostgreSQL | ACID, relations |
| Product catalog | MongoDB | Flexible schema |
| Session data | Redis | Fast key-value |
| Activity feeds | Cassandra | Write-heavy, time-series |
| Social graph | Neo4j | Relationship traversal |
| Search (full-text) | Elasticsearch | Inverted index |
| Analytics/OLAP | ClickHouse, BigQuery | Column-oriented |
| Time-series metrics | InfluxDB, TimescaleDB | Optimized for time |
| Files/Images/Videos | S3, GCS | Object storage |

---

### Numbers to Know by Heart

```
Storage:
1 char  = 1 byte
1 tweet = ~280 bytes
1 photo = ~1 MB
1 video (1 min) = ~50 MB

Time:
1 day   = 86,400 sec ≈ 10^5
1 month = 2.5M sec  ≈ 30 × 10^5
1 year  = 30M sec   ≈ 3 × 10^7

Throughput:
1M users, 1 req/day = ~12 QPS
1M users, 10 req/day = ~120 QPS
100M users, 10 req/day = ~12,000 QPS

Data Size:
1M users × 1KB = 1 GB
1B users × 1KB = 1 TB
1B users × 1MB = 1 PB
```

---

### Availability Cheatsheet

| SLA | Annual Downtime | Monthly Downtime |
|-----|----------------|-----------------|
| 99% | 3.65 days | 7.2 hours |
| 99.9% | 8.7 hours | 43.8 min |
| 99.99% | 52.6 min | 4.4 min |
| 99.999% | 5.26 min | 26.3 sec |

**How to achieve high availability:**
- Multiple instances (no SPOF)
- Load balancing
- Health checks + auto-restart
- Multi-region deployment
- Circuit breakers
- Graceful degradation

---

## 🚫 Common Interview Mistakes

> 🔍 **What is it?**
> The most frequent errors candidates make in system design interviews that cause rejections — even when their architecture is technically sound.

> 💡 **Why it matters?**
> Knowing these mistakes lets you **actively avoid them** during your interview. Many brilliant engineers fail system design not because of technical weakness, but because of process mistakes (jumping to solutions, not clarifying, forgetting trade-offs).

> ⚠️ **Without knowing them (Impact):**
> You design a great system but never asked "what's the scale?" — you designed for 1,000 users, the interviewer wanted 1 billion. Or you never discussed trade-offs and the interviewer thinks you believe your design is perfect — a sign of inexperience. These are **interview-killers that have nothing to do with your actual skill level**.

| Mistake | Better Approach |
|---------|----------------|
| Jumping to solution immediately | Start with requirements/clarifications |
| Over-engineering from start | Start simple, then scale |
| Forgetting non-functional requirements | Ask about scale, latency, availability |
| No capacity estimation | Always estimate QPS and storage |
| Single database for everything | Choose DB per use case |
| No caching strategy | Always add Redis for read-heavy data |
| Forgetting failure scenarios | Ask "what happens if X fails?" |
| No monitoring/observability | Mention metrics, logs, traces |
| Ignoring security | Mention auth, HTTPS, rate limiting |

---

## 💬 Questions to Ask Interviewer

### Functional Requirements
```
- What are the core features we MUST have?
- What features can we skip for now?
- Who are the users? (consumers, businesses, internal?)
- Mobile app, web, or both?
```

### Non-Functional Requirements
```
- How many daily active users?
- What's the read:write ratio?
- What latency is acceptable? (< 100ms? < 1s?)
- What availability do we need? (99.9%? 99.99%?)
- Is the data highly consistent, or is eventual consistency OK?
- Is this system global or one region?
- What's the data retention policy?
```

---

## 🏆 Advanced Concepts to Mention

> 🔍 **What is it?**
> A list of advanced distributed systems concepts that, when mentioned appropriately during an interview, demonstrate **senior/staff-level depth of knowledge**.

> 💡 **Why it matters?**
> Most candidates know the basics (REST, cache, DB). Mentioning Bloom Filters, Merkle Trees, or Vector Clocks at the right moment signals you've **built or studied real production systems** at scale — which is exactly what Staff and Architect roles require.

> ⚠️ **Without knowing them (Impact):**
> When asked "how do you prevent cache penetration for non-existent keys?", saying "I'm not sure" vs "I'd use a Bloom Filter" is the difference between a "no hire" and a "strong hire" at FAANG companies. These concepts aren't tricks — they're **real tools that solve real problems** and knowing them shows you've gone deep.

Mentioning these makes you stand out:

| Concept | When to Mention |
|---------|----------------|
| **Consistent Hashing** | When discussing horizontal scaling of caches/DBs |
| **Bloom Filter** | When checking existence without hitting DB |
| **Geospatial Index** | Location-based features (Uber, Yelp) |
| **Vector Clock** | Resolving conflicts in distributed systems |
| **Two-Phase Commit** | Distributed transactions (and why to avoid it) |
| **Raft/Paxos** | Leader election in distributed systems |
| **Merkle Trees** | Data synchronization (Git, DynamoDB anti-entropy) |
| **HyperLogLog** | Approximate unique counts (page views) |
| **Trie** | Autocomplete/typeahead feature |
| **Quadtree** | Geospatial partitioning (proximity services) |

---

## 📊 Design Patterns Quick Reference

| Pattern | Problem It Solves | Example |
|---------|------------------|---------|
| **Cache-Aside** | Reduce DB load | Session storage |
| **CQRS** | Scale reads/writes separately | Social feed |
| **Event Sourcing** | Audit trail, replay | Banking transactions |
| **Saga** | Distributed transactions | E-commerce order flow |
| **Strangler Fig** | Monolith migration | Incremental microservice extraction |
| **Circuit Breaker** | Cascading failures | Service calls |
| **Bulkhead** | Isolate failures | Separate thread pools per service |
| **Sidecar** | Cross-cutting concerns | Logging, metrics, proxy |
| **BFF** | Frontend-specific backends | Mobile vs Web APIs |
| **Outbox Pattern** | Reliable event publishing | DB write + event publish atomically |

---

## 🗣️ How to Talk During the Interview

### Opening (Clarifying)
> *"Before I start designing, let me clarify the requirements. Is this a global system or single region? What scale are we targeting — is it millions of users or billions? What's more important — consistency or availability?"*

### Estimation
> *"Let me do some back-of-envelope math. Assuming 100M DAU with 10 requests per day, that's roughly 12,000 QPS on average, with peak around 2-3x that, so ~30,000 QPS peak."*

### Architecture
> *"At a high level, I'd have clients connecting through an API Gateway, which handles auth and rate limiting. Behind that, I'll have separate services for [X, Y, Z]..."*

### Trade-offs
> *"I chose Cassandra here for its write scalability, but the trade-off is we lose strong consistency. Given this is a social feed and eventual consistency is acceptable, I think that's the right trade-off."*

### Scaling
> *"If we need to scale further, the first bottleneck would be the database writes. I'd address that by sharding by user_id..."*

---

## 🎯 Top 10 System Design Questions (Practice These)

| # | Question | Key Concepts |
|---|---------|-------------|
| 1 | Design URL Shortener | Hashing, Base62, Caching, DB |
| 2 | Design Twitter/Social Feed | Fan-out, Caching, Kafka, Cassandra |
| 3 | Design YouTube | CDN, Transcoding, HLS, S3 |
| 4 | Design WhatsApp | WebSocket, Presence, Push notifications |
| 5 | Design Uber/Lyft | Geospatial, Real-time tracking, Matching |
| 6 | Design Google Drive | Chunking, Sync, S3, Metadata DB |
| 7 | Design Rate Limiter | Token Bucket, Redis, Sliding Window |
| 8 | Design Notification System | Kafka, Push/Email/SMS, Fan-out |
| 9 | Design Search Autocomplete | Trie, Elasticsearch, Caching |
| 10 | Design Distributed Cache | Consistent Hashing, LRU, Redis Cluster |

---

## 📈 Progression Path

```
Junior Engineer:
  → Knows basic REST, SQL, simple scaling

Mid-Level Engineer:
  → Understands caching, queues, replication
  → Can design simple systems end-to-end

Senior Engineer:
  → Deep knowledge of trade-offs
  → Knows distributed systems patterns
  → Can estimate scale and bottlenecks

Staff/Architect:
  → Designs for failure, not just success
  → Thinks about org structure (Conway's Law)
  → Considers security, compliance, cost
  → Challenges requirements when appropriate
```

---

## 📚 Recommended Resources

| Resource | Type | Best For |
|----------|------|---------|
| **Designing Data-Intensive Applications** (Martin Kleppmann) | Book | Deep fundamentals ⭐⭐⭐⭐⭐ |
| **System Design Interview** (Alex Xu) | Book | Interview prep ⭐⭐⭐⭐ |
| **High Scalability Blog** | Blog | Real architectures |
| **AWS Architecture Center** | Docs | Cloud patterns |
| **ByteByteGo** (Alex Xu) | Newsletter/YouTube | Visual explanations |
| **Martin Fowler's Blog** | Blog | Patterns & architecture |

---

> 🎓 **Final Advice:** System design interviews test your **thinking process**, not memorization. Practice explaining your reasoning out loud. Think about trade-offs. Ask clarifying questions. Show that you understand the real-world implications of your choices.
>
> **You've got this! 🚀**
