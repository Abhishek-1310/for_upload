# ⚡ Module 3: Caching

> Caching is one of the **highest-impact** optimizations in system design. It can reduce latency by 100x and cut database load by 90%.

---

## 1. Why Cache?

> 🔍 **What is it?**
> Caching is the practice of storing **copies of frequently accessed data in fast, temporary storage** (usually memory) so future requests for that data can be served faster, without going to the slow original source (database, disk, or remote service).

> 💡 **Why it matters?**
> Memory is **100x faster** than SSD and **1000x faster** than a typical database query. Caching is the single most impactful optimization in most systems — it can reduce response times from 100ms to 1ms and cut database load by 80-90%.

> ⚠️ **Without it (Impact):**
> Every user request goes all the way to the database. At 100,000 requests/second, your database gets 100,000 hits/second. Databases are not built for that — they **collapse**. Twitter without caching would need 100x more database servers. Without cache, your system is slow, expensive, and fragile under any real traffic.
```
Without Cache:          With Cache:
User ──▶ Server ──▶ DB  User ──▶ Server ──▶ Cache (hit!) ──▶ User
         100ms                    1ms ✅

If Cache Miss:
User ──▶ Server ──▶ Cache (miss) ──▶ DB ──▶ Cache ──▶ User
```

**Benefits:**
- Reduce latency (memory vs disk)
- Reduce database load
- Increase throughput
- Improve user experience

---

## 2. Cache Hierarchy

> 🔍 **What is it?**
> A layered system of caches at different levels — from CPU registers (nanoseconds) to application cache (Redis, microseconds) to CDN (milliseconds). Each layer is progressively slower but larger in capacity.

> 💡 **Why it matters?**
> Understanding the hierarchy helps you choose **where to cache what**. Static images belong at the CDN edge. User sessions belong in Redis. Frequently computed values belong in application memory. The right layer for each data type maximizes performance.

> ⚠️ **Without understanding it (Impact):**
> You might cache a 4K video in Redis (bad — exhausts memory fast) instead of a CDN. Or cache user-specific personalized data in a CDN (bad — user A sees user B's data). Misplacing cache leads to either **wasted resources** or **security vulnerabilities**.
```
CPU Registers   → L1 Cache → L2 Cache → L3 Cache
        ↓
    Main Memory (RAM)
        ↓
    Application Cache (Redis/Memcached)
        ↓
    CDN Cache (Edge Servers)
        ↓
    Database
```

---

## 3. Cache Strategies ⭐

> 🔍 **What is it?**
> The rules that define **when and how** data gets into the cache, updated in the cache, and written to the database. The 4 main strategies are: Cache-Aside, Write-Through, Write-Behind, and Read-Through.

> 💡 **Why it matters?**
> Different strategies have different trade-offs between **consistency, latency, and complexity**. Picking the wrong strategy means your cache is either always stale (users see old data), always slow (defeats the purpose), or risks losing data on crash.

> ⚠️ **Without a strategy (Impact):**
> Your cache becomes a **consistency nightmare** — users see stale prices, old profiles, or missed notifications. Or your cache and database get out of sync, causing bugs that are nearly impossible to reproduce and debug. A clear cache strategy is non-negotiable in any system design.

### Cache-Aside (Lazy Loading) — Most Common
```
READ:
  1. App checks cache
  2. Cache HIT → return data
  3. Cache MISS → fetch from DB → store in cache → return

WRITE:
  1. App writes to DB
  2. Invalidate or update cache entry
```
✅ Cache only what's actually needed  
✅ Cache failure doesn't break the system  
❌ First request always hits DB (cold start)  
❌ Data can be stale between DB write and cache invalidation  

---

### Write-Through
```
WRITE:
  1. App writes to Cache
  2. Cache synchronously writes to DB
  3. Return success
```
✅ Cache is always up-to-date  
✅ No stale data  
❌ Higher write latency (must write to DB too)  
❌ Cache gets polluted with data that's never read  

---

### Write-Behind (Write-Back)
```
WRITE:
  1. App writes to Cache
  2. Return success immediately
  3. Cache asynchronously flushes to DB (later)
```
✅ Very low write latency  
✅ DB gets batched writes (efficient)  
❌ Risk of data loss if cache crashes before flush  
❌ Complex to implement  

---

### Read-Through
```
READ:
  1. App asks Cache for data
  2. Cache MISS → Cache itself fetches from DB
  3. Cache stores it and returns to App
```
✅ App code is simpler (no DB logic)  
✅ Good for read-heavy workloads  
❌ Cache becomes a critical dependency  

---

### Strategy Comparison

| Strategy | Best For | Risk |
|----------|---------|------|
| Cache-Aside | General purpose | Stale data |
| Write-Through | Read-heavy, consistency needed | High write latency |
| Write-Behind | Write-heavy, speed critical | Data loss on crash |
| Read-Through | Read-heavy, simplified app code | Cold start latency |

---

## 4. Cache Eviction Policies ⭐

> 🔍 **What is it?**
> Cache has finite memory. Eviction policies define **which cached items get removed first** when the cache is full and new data needs to be stored. Common policies: LRU, LFU, FIFO, TTL.

> 💡 **Why it matters?**
> The right eviction policy keeps your cache filled with **the most useful data** at all times — maximizing cache hit rate. A high hit rate (e.g., 95%) means only 5% of requests touch the database, which is the goal.

> ⚠️ **Without the right policy (Impact):**
> With a bad policy, your cache fills with **stale, rarely-used data** and evicts the frequently-accessed data. Your cache hit rate drops to 20% — now 80% of requests still hit the database, giving you almost no benefit from the cache. Worse, without TTL, you serve users outdated data indefinitely (imagine showing an old price on an e-commerce site).

When cache is full, which items to remove?

| Policy | Description | Best For |
|--------|-------------|---------|
| **LRU** (Least Recently Used) | Remove least recently accessed item | General purpose ✅ |
| **LFU** (Least Frequently Used) | Remove least accessed item overall | Trending content |
| **FIFO** | Remove oldest inserted item | Simple queues |
| **MRU** (Most Recently Used) | Remove most recently used item | Rare — sequential scans |
| **Random** | Remove random item | Simple, low overhead |
| **TTL** (Time To Live) | Auto-expire after N seconds | Session data, tokens |

> **Redis default:** LRU. Always set a TTL on cache entries to prevent stale data!

---

## 5. Redis — The Swiss Army Knife ⭐

> 🔍 **What is it?**
> Redis (Remote Dictionary Server) is an open-source, **in-memory data structure store** that can be used as a cache, primary database, message broker, and more. It stores data in RAM, making it orders of magnitude faster than disk-based databases.

> 💡 **Why it matters?**
> Redis is the **most widely used caching solution** in the world. It's behind Twitter's timelines, GitHub's rate limiting, Snapchat's presence system, and countless other high-scale systems. It provides atomic operations, rich data structures, and persistence — far beyond what a simple cache needs.

> ⚠️ **Without Redis (Impact):**
> Without Redis, every feature that needs fast shared state (sessions, rate limiting, leaderboards, pub/sub, distributed locks) must be solved with slow, complicated DB queries or custom in-memory solutions that don't scale across multiple servers. Teams that skip Redis end up reinventing it badly.

Redis is an **in-memory** data structure store used as cache, database, message broker.

### Redis Data Types & Use Cases

| Type | Example | Use Case |
|------|---------|---------|
| **String** | `SET user:1 "Abhishek"` | Simple cache, counters |
| **Hash** | `HSET user:1 name "Abhi" age 25` | User profiles, objects |
| **List** | `LPUSH feed:1 postId` | Activity feeds, queues |
| **Set** | `SADD online_users user:1` | Unique items, tags |
| **Sorted Set** | `ZADD leaderboard 1000 user:1` | Leaderboards, rankings |
| **Bitmap** | `SETBIT active_users 42 1` | Feature flags, presence |
| **HyperLogLog** | `PFADD pageviews url1` | Approximate unique counts |
| **Stream** | `XADD events * action click` | Event sourcing, Kafka-like |

### Common Redis Patterns

```bash
# Cache with TTL
SET session:abc123 '{"userId":1}' EX 3600   # expires in 1 hour

# Atomic counter (no race condition!)
INCR page_views:home_page

# Rate limiting
INCR requests:user:1
EXPIRE requests:user:1 60                    # reset every minute

# Distributed Lock
SET lock:resource "owner" NX EX 30          # NX = only if not exists
```

### Redis Persistence Options
| Mode | How | Data Safety |
|------|-----|-------------|
| **RDB** (snapshot) | Periodic dump to disk | Some data loss (last snapshot) |
| **AOF** (append-only file) | Log every write | Almost no data loss |
| **RDB + AOF** | Both | Best durability |
| **No persistence** | Pure cache | Data lost on restart |

---

## 6. CDN (Content Delivery Network) ⭐

> 🔍 **What is it?**
> A CDN is a **globally distributed network of servers** (called edge nodes or PoPs — Points of Presence) that cache static content (images, videos, JS, CSS) close to the user's physical location, so content travels a shorter distance and loads faster.

> 💡 **Why it matters?**
> Network latency is physical — data can't travel faster than light. A user in Mumbai loading a video from a US server has 180ms+ of latency just from distance. A CDN edge server in Singapore brings that to ~20ms. CDNs also absorb massive traffic spikes and protect your origin servers from DDoS attacks.

> ⚠️ **Without CDN (Impact):**
> Every image, video, and JS file is served from your one origin server. For a global app with millions of users, your origin gets **hammered with static asset requests** — most of which are identical files served to millions of people. Your bandwidth costs explode, your server slows down for API requests too, and users in distant regions experience **2-5x worse load times**. YouTube without a CDN would be physically impossible.

A globally distributed network of servers that cache **static content** close to users.

```
Without CDN:              With CDN:
User (Mumbai) ──────────▶ Origin Server (US) [High latency!]

User (Mumbai) ──▶ CDN Edge (Singapore) [Low latency ✅]
                         ↑
                  (cached copy here)
```

### What CDNs Cache
- Images, videos, audio
- HTML, CSS, JavaScript files
- API responses (with proper cache headers)
- Large file downloads

### CDN Providers
| Provider | Strength |
|---------|---------|
| **Cloudflare** | DDoS protection, free tier, edge computing |
| **AWS CloudFront** | Tight AWS integration |
| **Akamai** | Enterprise, global reach |
| **Fastly** | Real-time purging, edge compute |

### Cache-Control Headers
```http
Cache-Control: public, max-age=86400    # Cache for 1 day
Cache-Control: private, no-store        # Don't cache (user-specific)
Cache-Control: no-cache                 # Must revalidate before serving
ETag: "abc123"                          # Version fingerprint
```

---

## 7. Cache Problems & Solutions

> 🔍 **What is it?**
> Even with caching, several failure modes can occur that **negate the cache's benefits or cause system overload**. The major problems are: Cache Stampede (Thundering Herd), Cold Start, Cache Avalanche, and Cache Penetration.

> 💡 **Why it matters?**
> These are real production failure modes that have taken down major systems. Knowing them and their solutions separates junior engineers ("add a cache") from senior engineers ("add a cache safely with proper patterns").

> ⚠️ **Without knowing these (Impact):**
> You add Redis thinking you solved your DB overload problem. Then a popular item's cache expires at 3 AM — 100,000 simultaneous requests hit your DB (Cache Stampede) — DB crashes — your whole app goes down. You didn't break the system, your **cache** broke the system. These problems are sneaky and only appear under real load.

### 🔥 Cache Stampede (Thundering Herd)
**Problem:** Cache entry expires → thousands of requests simultaneously hit the DB.

**Solutions:**
- **Mutex/Lock:** Only one request refreshes cache, others wait
- **Probabilistic Early Expiration:** Randomly refresh before TTL expires
- **Background refresh:** Refresh cache before it expires

---

### ❄️ Cold Start Problem
**Problem:** New cache has no data → all requests hit DB.

**Solutions:**
- Pre-warm cache before traffic hits (load popular data on startup)
- Gradual rollout

---

### 💥 Cache Avalanche
**Problem:** Many cache entries expire at the same time → DB overload.

**Solutions:**
- Add **random jitter** to TTL: `TTL = base_TTL + random(0, 300)`
- Use **circuit breaker** to protect DB
- Stagger cache population

---

### 👻 Cache Penetration
**Problem:** Requests for **non-existent data** (e.g., user ID 99999) always miss cache → DB hammered.

**Solutions:**
- Cache **null results** too (`SET user:99999 "NULL" EX 300`)
- **Bloom Filter:** Probabilistic check if key might exist before hitting DB

---

## 8. Memcached vs Redis

> 🔍 **What is it?**
> Two popular in-memory caching systems. **Memcached** is a simple, high-performance, distributed key-value cache. **Redis** is a more feature-rich in-memory store that supports many data types, persistence, replication, and pub/sub.

> 💡 **Why it matters?**
> You'll encounter both in existing codebases or need to choose between them. Understanding their trade-offs helps you make the right call and explain it in interviews.

> ⚠️ **Choosing wrong (Impact):**
> If you choose Memcached for a use case needing sorted leaderboards, pub/sub, or persistence — you'll realize it's impossible and have to migrate. If you use Redis but configure zero persistence and your server restarts — you lose all cached data and your app behaves as if it has no cache until it warms up again (cold start problem on production).

| Feature | Memcached | Redis |
|---------|-----------|-------|
| Data Types | String only | String, List, Set, Hash, ZSet... |
| Persistence | ❌ | ✅ (RDB + AOF) |
| Replication | ❌ | ✅ |
| Pub/Sub | ❌ | ✅ |
| Lua Scripting | ❌ | ✅ |
| Multi-threading | ✅ | Single-threaded (mostly) |
| Use Case | Simple caching | Cache + much more |

> **Verdict:** Almost always use **Redis**. Memcached is only better if you need pure multi-threaded caching.

---

## ✅ Module 3 Summary Checklist

- [ ] Know all 4 caching strategies (Cache-Aside, Write-Through, Write-Behind, Read-Through)
- [ ] Know LRU, LFU, TTL eviction policies
- [ ] Know Redis data types and when to use each
- [ ] Can explain CDN and cache-control headers
- [ ] Can explain and solve Cache Stampede, Avalanche, Penetration
- [ ] Know when to use Bloom Filters

---

**Next:** [Module 4 - Networking & APIs →](../04-Networking-APIs/README.md)
