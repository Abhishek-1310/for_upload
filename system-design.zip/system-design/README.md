# 🏗️ System Design Mastery — Complete Learning Path

> **Goal:** Become an advanced developer & architect who can crack any system design interview.

---

## 📚 Modules

| # | Module | Topics Covered |
|---|--------|---------------|
| 1 | [Fundamentals](./01-Fundamentals/README.md) | Scalability, Availability, CAP, ACID, BASE, Latency |
| 2 | [Databases](./02-Databases/README.md) | SQL, NoSQL, Sharding, Replication, Indexing |
| 3 | [Caching](./03-Caching/README.md) | Redis, CDN, Cache Strategies, Invalidation |
| 4 | [Networking & APIs](./04-Networking-APIs/README.md) | REST, gRPC, WebSockets, Load Balancers, DNS |
| 5 | [Messaging & Queues](./05-Messaging-Queues/README.md) | Kafka, RabbitMQ, Event-Driven Architecture |
| 6 | [Microservices](./06-Microservices/README.md) | Service Mesh, Patterns, Service Discovery |
| 7 | [Real World Designs](./07-Real-World-Designs/README.md) | Twitter, YouTube, URL Shortener, WhatsApp, Uber |
| 8 | [Interview Cheatsheet](./08-Interview-Cheatsheet/README.md) | Quick Reference, Framework, Common Mistakes |

---

## 🎯 How to Use This Guide

1. **Start from Module 1** and go in order — each module builds on the previous.
2. **Draw diagrams** as you read — system design is visual.
3. **Practice out loud** — explain each concept as if in an interview.
4. **Attempt real designs** in Module 7 before reading the solutions.

---

## ⏱️ Recommended Study Plan

| Week | Focus |
|------|-------|
| Week 1 | Fundamentals + Databases |
| Week 2 | Caching + Networking & APIs |
| Week 3 | Messaging + Microservices |
| Week 4 | Real World Designs + Interview Practice |

---

## 🔑 Key Interview Framework (RESHADED)

```
R - Requirements (Functional & Non-Functional)
E - Estimation (Scale, QPS, Storage)
S - Storage Schema (DB design)
H - High-Level Design (Components/Architecture)
A - APIs Design
D - Deep Dive (Bottlenecks, Trade-offs)
E - Evaluation (How to monitor, scale)
D - Discuss Trade-offs
```

---

> 💡 **Tip:** Senior engineers are NOT expected to have perfect answers — they are expected to **think through trade-offs** and **ask the right questions**.
