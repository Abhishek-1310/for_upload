# 🌐 Module 4: Networking & APIs

> Understanding how systems communicate is critical for designing scalable, reliable architectures.

---

## 1. Communication Protocols Overview

> 🔍 **What is it?**
> Communication protocols are the **agreed-upon rules** for how a client and server exchange data. Different protocols exist for different needs: REST for standard web APIs, gRPC for fast internal services, WebSocket for real-time bidirectional communication.

> 💡 **Why it matters?**
> Choosing the wrong protocol is like sending a fax when you need a phone call. The protocol determines your system's speed, reliability, real-time capability, and developer experience.

> ⚠️ **Without understanding this (Impact):**
> Using REST for a real-time chat app means polling every second — wasteful, laggy, and expensive. Using WebSockets for a public REST API confuses every API consumer. Using JSON over HTTP for internal microservices calling each other 10,000 times/second wastes huge amounts of CPU on serialization. The wrong protocol choice can make your system **fundamentally unfit for purpose**.
```
Client ◀─────────────────────────────▶ Server
        HTTP/REST
        GraphQL
        gRPC
        WebSocket
        WebRTC
```

---

## 2. REST API ⭐

> 🔍 **What is it?**
> REST (Representational State Transfer) is an architectural style for building APIs over HTTP. It uses standard HTTP methods (GET, POST, PUT, DELETE), treats everything as a **resource** with a URL, and is **stateless** (each request is self-contained).

> 💡 **Why it matters?**
> REST is the **most widely used API style** in the world — virtually every web app, mobile app, and public API uses it. It's simple, universally understood, works in browsers, and has excellent tooling. Understanding REST deeply makes you effective across any tech stack.

> ⚠️ **Without it (Impact):**
> Without a standard like REST, every developer invents their own API style — `/getUser`, `/fetchUserById`, `/user_fetch` — creating inconsistent, unmaintainable APIs. Bad REST design causes confusion, security issues (using GET for destructive actions), and bugs from improper use of HTTP methods and status codes.

**RE**presentational **S**tate **T**ransfer — the most common API style.

### REST Principles
- **Stateless:** Each request contains all info needed
- **Resource-based:** URLs represent resources (`/users/1`, not `/getUser?id=1`)
- **HTTP Verbs:** GET, POST, PUT, PATCH, DELETE

### HTTP Methods

| Method | Purpose | Idempotent? | Body? |
|--------|---------|-------------|-------|
| **GET** | Read data | ✅ Yes | ❌ No |
| **POST** | Create new resource | ❌ No | ✅ Yes |
| **PUT** | Replace entire resource | ✅ Yes | ✅ Yes |
| **PATCH** | Update partial resource | ✅ Yes | ✅ Yes |
| **DELETE** | Remove resource | ✅ Yes | Optional |

### HTTP Status Codes (Must Know)

| Code | Meaning |
|------|---------|
| `200 OK` | Success |
| `201 Created` | Resource created |
| `204 No Content` | Success, no body (DELETE) |
| `400 Bad Request` | Invalid input from client |
| `401 Unauthorized` | Not authenticated |
| `403 Forbidden` | Authenticated but no permission |
| `404 Not Found` | Resource doesn't exist |
| `409 Conflict` | Resource conflict (duplicate) |
| `429 Too Many Requests` | Rate limited |
| `500 Internal Server Error` | Server bug |
| `503 Service Unavailable` | Server overloaded/down |

### REST API Design Best Practices
```
# ✅ GOOD — Nouns, plural, hierarchical
GET    /users                  # list all users
GET    /users/{id}             # get specific user
POST   /users                  # create user
PUT    /users/{id}             # update user
DELETE /users/{id}             # delete user
GET    /users/{id}/orders      # user's orders
GET    /users/{id}/orders/{oid}# specific order

# ❌ BAD — Verbs in URLs
GET /getUser?id=1
POST /createUser
GET /deleteUser?id=1
```

---

## 3. GraphQL

> 🔍 **What is it?**
> GraphQL is a query language for APIs (developed by Facebook) where the **client specifies exactly what data it wants**, rather than the server deciding. A single endpoint (`/graphql`) handles all operations, and the client sends a query describing the shape of the response it needs.

> 💡 **Why it matters?**
> REST over-fetches (returns too much data) or under-fetches (requires multiple requests for related data). GraphQL solves both. It's especially powerful for **complex UIs** that need data from multiple entities in one request, and for mobile apps where bandwidth matters.

> ⚠️ **Without it (Impact):**
> A mobile app needs user name + their last 3 orders + order totals — with REST this is 3 separate HTTP calls (user endpoint, orders endpoint, filtering). This means 3x the latency, 3x the battery usage, and 3x the data transfer on a slow mobile network. Many teams at Facebook, GitHub, and Shopify switched to GraphQL specifically to solve this **over-fetching / under-fetching problem**.

A query language for APIs where **client decides what data to fetch**.

```graphql
# Client requests EXACTLY what it needs
query {
  user(id: "1") {
    name
    email
    orders {
      id
      total
    }
  }
}
```

### REST vs GraphQL

| | REST | GraphQL |
|--|------|---------|
| **Over-fetching** | ❌ Gets all fields | ✅ Gets only requested fields |
| **Under-fetching** | ❌ Multiple requests needed | ✅ One request for all data |
| **Type System** | Optional | ✅ Strongly typed schema |
| **Caching** | ✅ Easy (HTTP cache) | ❌ Harder (all POST requests) |
| **Learning Curve** | Low | Higher |
| **Best for** | Simple CRUD APIs | Complex, multi-entity UIs |

---

## 4. gRPC ⭐

> 🔍 **What is it?**
> gRPC (Google Remote Procedure Call) is a high-performance, open-source RPC framework that uses **Protocol Buffers (binary format)** for serialization and **HTTP/2** for transport. You define your service and messages in a `.proto` file, and gRPC generates client/server code in any language.

> 💡 **Why it matters?**
> gRPC is **5-10x faster** than REST with JSON because binary serialization is much more compact than text. HTTP/2 enables multiplexing (multiple requests over one connection) and bi-directional streaming. This makes it the standard choice for **internal microservice communication** at Google, Netflix, Uber, and others.

> ⚠️ **Without it (Impact):**
> Internal microservices calling each other thousands of times per second over REST/JSON waste enormous CPU cycles on JSON serialization/deserialization. At Google's scale, this would require **millions of additional servers** just for the serialization overhead. gRPC's efficiency translates directly to lower infrastructure costs and faster response times across the entire system.

**g**oogle **R**emote **P**rocedure **C**all — high-performance RPC framework.

```protobuf
// Define service in .proto file
service UserService {
  rpc GetUser (GetUserRequest) returns (UserResponse);
  rpc StreamUsers (Empty) returns (stream UserResponse);
}

message GetUserRequest {
  string user_id = 1;
}
```

### REST vs gRPC

| | REST | gRPC |
|--|------|------|
| **Protocol** | HTTP/1.1 | HTTP/2 |
| **Data Format** | JSON (text) | Protocol Buffers (binary) |
| **Speed** | Slower | **5-10x faster** |
| **Type Safety** | Optional | ✅ Strongly typed |
| **Streaming** | Limited | ✅ Bi-directional streaming |
| **Browser Support** | ✅ Native | ❌ Needs proxy |
| **Best for** | Public APIs, mobile | Internal microservices |

> **Use gRPC for:** Internal service-to-service communication  
> **Use REST for:** Public-facing APIs, browser clients

---

## 5. WebSockets ⭐

> 🔍 **What is it?**
> WebSocket is a protocol that provides a **persistent, full-duplex (bidirectional) communication channel** over a single TCP connection. After an initial HTTP handshake to "upgrade" the connection, both client and server can send messages to each other **at any time** without a new request.

> 💡 **Why it matters?**
> HTTP is a request-response protocol — the server can only send data when the client asks. For real-time features (chat, live scores, collaborative editing), you need the **server to push data to the client** the moment something happens. WebSockets enable this with minimal overhead.

> ⚠️ **Without it (Impact):**
> Building real-time chat with HTTP short-polling (client asks server every second: "any new messages?") means 1 HTTP request per second per user. With 100,000 users, that's **100,000 pointless requests per second** to your servers, 99% of which return "no new messages". Your servers are swamped with wasted traffic. WhatsApp, Slack, and Discord all use WebSockets because real-time communication is literally impossible at scale without it.

Full-duplex, persistent connection between client and server.

```
HTTP (Request-Response):         WebSocket (Full-Duplex):
Client ──GET /data──▶ Server     Client ◀══persistent══▶ Server
Client ◀──response── Server      (both can send anytime!)
Client ──GET /data──▶ Server
...repeat for every update
```

### WebSocket Handshake
```http
# Client upgrades HTTP to WebSocket
GET /chat HTTP/1.1
Upgrade: websocket
Connection: Upgrade

# Server responds
HTTP/1.1 101 Switching Protocols
Upgrade: websocket
```

### When to Use WebSockets

| Use Case | Why |
|---------|-----|
| Chat apps | Real-time messaging |
| Live sports scores | Server pushes updates |
| Collaborative editing | Multi-user real-time |
| Trading platforms | Real-time price feeds |
| Online games | Low-latency bidirectional |

### Polling Alternatives Comparison

| Method | How | Latency | Server Load |
|--------|-----|---------|-------------|
| **Short Polling** | Client polls every N seconds | High | High |
| **Long Polling** | Server holds request until data | Medium | Medium |
| **SSE** (Server-Sent Events) | Server pushes one-way | Low | Low |
| **WebSocket** | Full duplex persistent | Lowest | Medium |

---

## 6. Load Balancers (Deep Dive)

> 🔍 **What is it?**
> A load balancer is a device or software that **distributes incoming traffic across a pool of servers**. It monitors server health, removes unhealthy servers from rotation, and can route traffic based on various algorithms (Round Robin, Least Connections, IP Hash, etc.).

> 💡 **Why it matters?**
> Load balancers are the **gateway to horizontal scaling**. Without them, you can't add more servers. They also provide automatic failover, health checking, SSL termination, and DDoS protection — making them central to any production architecture.

> ⚠️ **Without it (Impact):**
> One server handles all traffic. When it reaches capacity, new users get errors or timeouts. When it crashes, the entire application goes offline. You can't deploy new code without taking down the whole service. Load balancers are so fundamental that **no production system at any meaningful scale runs without them**.
```
         Internet
              │
         ┌────▼────┐
         │  DNS    │
         └────┬────┘
              │
    ┌─────────▼──────────┐
    │   Global Load       │
    │   Balancer (GLB)    │  ← Routes to nearest data center
    └─────────┬──────────┘
              │
    ┌─────────▼──────────┐
    │   Regional LB      │  ← L4/L7 within data center
    └──┬──────┬──────┬───┘
       │      │      │
    Srv1   Srv2   Srv3
```

### Health Checks
Load balancers continuously check server health:
```
LB pings: GET /health every 10s
Server responds: 200 OK → Healthy ✅
Server responds: 5xx / timeout → Remove from pool ❌
```

### Session Persistence (Sticky Sessions)
Problem: Stateful app needs same user to hit same server.  
Solution: LB uses `session_id` cookie to route user to same server.

> **Better solution:** Make your app stateless — store sessions in Redis!

---

## 7. API Gateway ⭐

> 🔍 **What is it?**
> An API Gateway is a **single entry point** for all client requests to a microservices backend. It handles cross-cutting concerns like authentication, rate limiting, SSL termination, routing, logging, and request transformation — so individual microservices don't have to.

> 💡 **Why it matters?**
> In a microservices architecture with 50+ services, without an API Gateway, every client needs to know the address of every service. Every service must independently implement auth, rate limiting, and logging. The API Gateway **centralizes** all of this, making the system simpler, more secure, and easier to manage.

> ⚠️ **Without it (Impact):**
> Each of your 50 microservices has to implement its own authentication, rate limiting, SSL handling, and logging. When you need to change the auth logic, you update 50 services. One service forgets to implement rate limiting — and a single bad actor can **take it down with a DDoS**. Clients must know internal service addresses, creating tight coupling. The API Gateway is the **firewall and traffic cop** of microservices.

A single entry point for all client-to-microservice communication.

```
Mobile App  ─┐
Web App     ─┤──▶ API Gateway ──▶ User Service
3rd Party   ─┘          │──▶ Order Service
                         │──▶ Payment Service
                         │──▶ Notification Service
```

### API Gateway Responsibilities
| Feature | Description |
|---------|-------------|
| **Routing** | Route `/users` → User Service |
| **Authentication** | Validate JWT/OAuth before forwarding |
| **Rate Limiting** | 100 req/min per user |
| **SSL Termination** | Handle HTTPS, pass HTTP internally |
| **Request Transform** | Modify request/response format |
| **Logging/Monitoring** | Central place for access logs |
| **Caching** | Cache common responses |

> **Examples:** Kong, AWS API Gateway, Nginx, Traefik

---

## 8. DNS (Domain Name System)

> 🔍 **What is it?**
> DNS is the "phone book of the internet" — it translates human-readable domain names like `www.google.com` into machine-readable IP addresses like `142.250.80.46` that computers use to connect to each other.

> 💡 **Why it matters?**
> DNS is involved in **every single internet request** your users make. It determines which server handles your traffic, enables CDN routing, powers blue-green deployments, and allows global traffic distribution. Understanding DNS is essential for running any internet-facing system.

> ⚠️ **Without understanding it (Impact):**
> DNS misconfiguration is one of the most common causes of major outages. Facebook's 6-hour outage in October 2021 was caused by a **bad DNS configuration** that made the entire Facebook infrastructure unreachable worldwide. Slow DNS means slow page loads even before your server handles the request. Ignoring DNS TTL during deployments causes users to be routed to old servers long after you've migrated.

Translates `www.google.com` → `142.250.80.46`

```
Browser requests www.google.com
    ↓
Local DNS cache? YES → use it
    ↓ NO
Recursive Resolver (ISP)
    ↓
Root Nameserver (knows .com servers)
    ↓
TLD Nameserver (knows google.com servers)
    ↓
Authoritative Nameserver (returns 142.250.80.46)
    ↓
Browser connects to 142.250.80.46
```

### DNS Record Types
| Record | Purpose | Example |
|--------|---------|---------|
| **A** | Domain → IPv4 | `api.example.com → 1.2.3.4` |
| **AAAA** | Domain → IPv6 | `api.example.com → ::1` |
| **CNAME** | Domain → Domain | `www → example.com` |
| **MX** | Mail server | `@example.com → mail.google.com` |
| **TXT** | Text/verification | SPF, DKIM records |
| **NS** | Nameserver | Which server handles domain |

### DNS Load Balancing
```
api.example.com → [1.2.3.4, 1.2.3.5, 1.2.3.6]  (round-robin)
```

---

## 9. Rate Limiting ⭐

> 🔍 **What is it?**
> Rate limiting is a technique to **control the number of requests a user/client can make to your API** within a time window. If they exceed the limit, the server rejects further requests with a `429 Too Many Requests` response.

> 💡 **Why it matters?**
> Rate limiting protects your system from: abuse (scrapers, spammers), **DDoS attacks** (flooding with requests), runaway clients (bugs making infinite loops of requests), and ensures **fair usage** for all users so one bad actor can't degrade service for everyone else.

> ⚠️ **Without it (Impact):**
> A single buggy client makes an infinite loop and sends 100,000 requests/minute to your API. Your servers are overwhelmed, legitimate users experience downtime. A competitor writes a scraper that downloads your entire product catalog. A malicious user tries all possible passwords on your login endpoint. Without rate limiting, your system is **wide open to all of these attacks** — and they WILL happen in production.

Protects your API from abuse and ensures fair usage.

### Rate Limiting Algorithms

#### Token Bucket (Most Common)
```
Bucket capacity: 100 tokens
Refill rate: 10 tokens/second

Request comes in → take 1 token
No tokens → reject with 429
```
✅ Allows bursts up to bucket size  
✅ Used by AWS, Stripe  

#### Leaky Bucket
```
Requests fill bucket, drains at constant rate
If bucket full → reject
```
✅ Smooth, consistent output rate  
❌ Old requests can delay new ones  

#### Fixed Window Counter
```
Counter resets every minute
If counter > limit → reject
```
✅ Simple  
❌ Edge case: 200 requests at 00:59 and 200 at 01:01 = 400 in 2 seconds  

#### Sliding Window Log
```
Track timestamp of every request
Count requests in last N seconds
```
✅ Accurate  
❌ Memory-intensive  

### Where to Store Rate Limit State
→ **Redis** with atomic `INCR` + `EXPIRE` operations

```python
# Redis rate limiting
key = f"rate:user:{user_id}"
count = redis.incr(key)
if count == 1:
    redis.expire(key, 60)  # First request, set 1-min window
if count > 100:
    raise RateLimitExceeded()
```

---

## ✅ Module 4 Summary Checklist

- [ ] Know REST principles and HTTP verbs/status codes
- [ ] Understand REST vs GraphQL vs gRPC trade-offs
- [ ] Know when to use WebSockets vs SSE vs Polling
- [ ] Can explain API Gateway and its features
- [ ] Know DNS resolution flow
- [ ] Understand rate limiting algorithms (Token Bucket especially)

---

**Next:** [Module 5 - Messaging & Queues →](../05-Messaging-Queues/README.md)
