# 🗄️ Module 2: Databases

> Choosing the right database is one of the most critical decisions in system design.

---

## 1. Relational Databases (SQL)

> 🔍 **What is it?**
> A relational database stores data in **structured tables** made of rows and columns, with relationships between tables defined by **foreign keys**. You query them using SQL (Structured Query Language). They fully support ACID transactions.

> 💡 **Why it matters?**
> SQL databases are the **default, battle-tested choice** for most applications. They enforce data integrity, support complex multi-table queries and joins, and guarantee your data is always in a consistent state. They're the backbone of banking, e-commerce, and enterprise systems.

> ⚠️ **Without it (Impact):**
> If you use a less structured DB for relational data (e.g., orders linked to users to products), you lose the ability to do complex queries and must write manual join logic in application code — which is buggy, slow, and hard to maintain. Without ACID, partial writes (like charging a card but not creating the order) can silently corrupt your data.

### How They Work
- Data stored in **tables** with rows and columns
- Relationships via **foreign keys**
- Query using **SQL**
- Support **ACID** transactions

### Popular Databases
| Database | Best For |
|---------|---------|
| **PostgreSQL** | Complex queries, JSON support, default choice |
| **MySQL** | Web apps, read-heavy workloads |
| **Oracle** | Enterprise, banking |
| **SQLite** | Embedded, mobile apps |

### Indexing ⭐
Indexes speed up **reads** but slow down **writes**.

```
Without index: Full table scan O(n)
With index:    B-Tree lookup  O(log n)
```

**Types of Indexes:**
| Type | Use Case |
|------|---------|
| **B-Tree** (default) | Range queries, =, <, >, ORDER BY |
| **Hash** | Exact match (=) only |
| **Composite** | Multiple columns: `INDEX(last_name, first_name)` |
| **Partial** | Index subset of rows: `WHERE active = true` |
| **Full-Text** | Text search: `MATCH AGAINST` |

> ⚠️ **Don't over-index!** Every index costs write performance and disk space.

### When to use SQL?
- Complex relationships (joins)
- ACID transactions required (payments, orders)
- Data is structured and schema is stable
- Reporting and analytics

---

## 2. NoSQL Databases

> 🔍 **What is it?**
> NoSQL ("Not Only SQL") databases are a broad class of databases that **do NOT use the traditional table/row/column model**. They sacrifice some ACID guarantees in exchange for massive horizontal scalability, flexible schemas, and specialized data models.

> 💡 **Why it matters?**
> When you have billions of records, thousands of writes per second, or data that doesn't fit neatly into tables (e.g., JSON documents, graphs, time-series), NoSQL databases can handle what relational databases physically cannot. They are how companies like Facebook, Twitter, and Netflix scale.

> ⚠️ **Without it (Impact):**
> Trying to store 500 million tweets per day in a single MySQL instance = impossible. The DB would run out of write capacity, disk space, and connection limits. You'd have to rewrite your storage layer from scratch under live traffic — one of the most painful engineering experiences imaginable. NoSQL is not optional at internet scale.

### 4 Types of NoSQL

#### 📄 Document Store
- Store JSON-like documents
- Flexible schema
- **Examples:** MongoDB, CouchDB, Firestore

```json
{
  "_id": "user_123",
  "name": "Abhishek",
  "address": { "city": "Mumbai", "zip": "400001" },
  "tags": ["developer", "architect"]
}
```
**Use when:** Content management, catalogs, user profiles

---

#### 🔑 Key-Value Store
- Simplest NoSQL: just key → value
- Extremely fast (O(1) lookups)
- **Examples:** Redis, DynamoDB, Memcached

```
"session:abc123" → { userId: 1, expiry: ... }
"cart:user_1"   → [item1, item2, item3]
```
**Use when:** Caching, sessions, leaderboards, shopping carts

---

#### 📊 Wide-Column Store
- Data stored in rows + dynamic columns
- Optimized for large-scale writes
- **Examples:** Apache Cassandra, HBase, Google Bigtable

```
Row Key: user_123
  Columns: email, city, last_login, preferences...
  (Each row can have DIFFERENT columns)
```
**Use when:** Time-series data, IoT, write-heavy at scale, geographically distributed

---

#### 🕸️ Graph Database
- Nodes (entities) + Edges (relationships)
- **Examples:** Neo4j, Amazon Neptune

```
(Abhishek) --[FOLLOWS]--> (Rahul)
(Abhishek) --[LIKES]----> (Post #42)
```
**Use when:** Social networks, fraud detection, recommendation engines

---

## 3. Database Replication ⭐

> 🔍 **What is it?**
> Replication means **keeping synchronized copies of your database** on multiple servers. One server acts as the Primary (accepts writes) and one or more Replicas/Secondaries receive a copy of all changes automatically.

> 💡 **Why it matters?**
> Replication serves two critical purposes:
> 1. **High Availability:** If the Primary crashes, promote a Replica — system keeps running.
> 2. **Read Scaling:** Spread read traffic across many Replicas — dramatically reduces load on the Primary.

> ⚠️ **Without it (Impact):**
> Your single database server is both a **capacity bottleneck** and a **single point of failure**. If it goes down — for any reason (hardware failure, bad deployment, disk full) — your **entire application is offline** until you manually restore it. At scale, without replicas your one DB gets hammered with both reads and writes until it buckles. This is a career-defining outage waiting to happen.

Keeping copies of data across multiple servers for **availability** and **read scaling**.

### Master-Slave (Primary-Replica)
```
         Write
Clients ──────▶ Primary DB ──replicates──▶ Replica 1
         Read ◀──────────────────────────▶ Replica 2
                                           Replica 3
```
- All **writes** go to Primary
- **Reads** distributed across Replicas
- If Primary fails → promote a Replica

✅ Good for read-heavy systems  
❌ Replication lag can cause stale reads  
❌ Primary is still a write bottleneck  

### Master-Master (Multi-Primary)
```
Clients ──Write/Read──▶ Primary 1 ◀──sync──▶ Primary 2
```
- Both nodes accept reads AND writes
- ✅ No write bottleneck, high availability
- ❌ Conflict resolution is complex (same record updated on both)

---

## 4. Database Sharding ⭐

> 🔍 **What is it?**
> Sharding is the practice of **horizontally splitting your database** into multiple smaller databases called "shards", each holding a subset of the data. For example, users with IDs 1–1M go to Shard 1, IDs 1M–2M go to Shard 2, etc.

> 💡 **Why it matters?**
> Even with replication, a single primary DB has a **hard limit** on how many writes per second it can handle and how much data it can store on one machine. Sharding breaks through this ceiling and allows you to scale writes and storage **horizontally across many machines**.

> ⚠️ **Without it (Impact):**
> Your database fills up its disk. Your single primary can't handle 100,000 write operations per second. Your only option is to either buy a more expensive server (vertical scaling has limits) or face **database-level data loss and crashes**. Instagram, for example, had to shard PostgreSQL when their user base exploded — without sharding they would have hit a hard wall.

**Problem:** Even with replication, a single database has a write/storage limit.  
**Solution:** Split data across multiple databases (shards).

```
User IDs 1-1M    → Shard 1 (DB Server 1)
User IDs 1M-2M   → Shard 2 (DB Server 2)
User IDs 2M-3M   → Shard 3 (DB Server 3)
```

### Sharding Strategies

| Strategy | How | Pros | Cons |
|----------|-----|------|------|
| **Range-based** | By value range (IDs 1-1M) | Simple | Hot spots if range isn't uniform |
| **Hash-based** | `hash(key) % N` | Even distribution | Hard to range query |
| **Directory-based** | Lookup table maps key→shard | Flexible | Lookup table = SPOF |
| **Geo-based** | By geography/region | Low latency for users | Uneven if regions differ in size |

### Sharding Problems
- **Cross-shard joins** are expensive/impossible
- **Resharding** is painful (data moves)
- **Hot spots** — one shard gets disproportionate traffic
- Transactions spanning shards are complex

> 💡 **Interview Tip:** Shard by the most common query key. For a social app, shard by `user_id`.

---

## 5. Database Normalization vs Denormalization

> 🔍 **What is it?**
> - **Normalization:** Organizing data to **eliminate redundancy** by splitting into multiple related tables (3NF, 2NF, etc.).
> - **Denormalization:** **Deliberately duplicating data** across tables to avoid expensive JOINs at query time.

> 💡 **Why it matters?**
> Normalization keeps your data **clean and consistent** — update one place, it's updated everywhere. Denormalization trades storage for **read performance** — you copy data so you never need to JOIN 5 tables to render a page.

> ⚠️ **Without understanding this (Impact):**
> A fully normalized DB at scale requires 5-way JOINs for every page render — killing performance at millions of users. But a fully denormalized DB means updating a user's name requires updating 50 tables — causing **update anomalies and data inconsistency**. Instagram, Twitter, and Facebook all denormalize heavily for their feed systems because the read performance gain is critical.

### Normalization (SQL Best Practice)
- Eliminate data redundancy
- Break data into multiple related tables

```sql
-- Normalized
Users table:  (user_id, name, email)
Orders table: (order_id, user_id, product_id, quantity)
Products:     (product_id, name, price)
```
✅ Less storage, no update anomalies  
❌ Need JOINs → slower reads

### Denormalization (Scale Best Practice)
- Duplicate data to avoid expensive joins

```sql
-- Denormalized Orders table
(order_id, user_id, user_name, user_email, product_name, price, quantity)
```
✅ Fast reads (no joins needed)  
❌ Update anomalies, more storage

> **Rule:** Normalize first. Denormalize ONLY when you have proven performance problems.

---

## 6. Choosing the Right Database

> 🔍 **What is it?**
> A decision framework for selecting which type of database to use based on your data model, access patterns, scale requirements, and consistency needs.

> 💡 **Why it matters?**
> There is no "best" database — there is only the **best database for your specific use case**. The right choice makes your system fast, simple, and scalable. The wrong choice means constant workarounds, performance problems, and eventually a painful migration.

> ⚠️ **Without the right choice (Impact):**
> Engineers who default to "just use MySQL for everything" hit walls when building a graph social network, a real-time leaderboard, or a search feature. Switching databases in production (with live user data) is one of the **most dangerous and expensive** engineering operations you'll ever face. Getting it right upfront saves months of pain.
```
START
  │
  ├─ Need ACID transactions? ──YES──▶ SQL (PostgreSQL/MySQL)
  │
  ├─ Need flexible schema / huge scale?
  │     ├─ Key-value lookups?     ──▶ Redis / DynamoDB
  │     ├─ Documents (JSON)?      ──▶ MongoDB
  │     ├─ Write-heavy at scale?  ──▶ Cassandra
  │     └─ Graph relationships?   ──▶ Neo4j
  │
  └─ Time-series / analytics?     ──▶ InfluxDB / ClickHouse
```

---

## 7. SQL Optimization Tips (Interview Level)

> 🔍 **What is it?**
> A set of best practices for writing SQL queries that perform well at scale — proper indexing, avoiding N+1 queries, selecting only needed columns, using JOINs correctly.

> 💡 **Why it matters?**
> A single poorly written query can bring down a production database serving millions of users. Optimization is the difference between a page loading in 20ms vs 20 seconds.

> ⚠️ **Without it (Impact):**
> The infamous **N+1 query problem** can turn 1 API call into 1000 DB queries. `SELECT *` on a table with 50 columns when you need 3 wastes memory and I/O. Missing an index on a `WHERE` clause means **full table scans** on every request — at 10M rows, each query takes seconds instead of milliseconds. These are the most common causes of database-related production incidents.
```sql
-- ❌ BAD: SELECT * loads all columns
SELECT * FROM users WHERE city = 'Mumbai';

-- ✅ GOOD: Select only needed columns
SELECT id, name, email FROM users WHERE city = 'Mumbai';

-- ❌ BAD: N+1 Query Problem
for user in users:
    fetch orders for user  -- 1 query per user!

-- ✅ GOOD: Use JOIN or IN clause
SELECT u.name, o.total
FROM users u
JOIN orders o ON u.id = o.user_id;

-- ✅ Always add index on columns used in WHERE, JOIN, ORDER BY
CREATE INDEX idx_users_city ON users(city);
```

---

## 8. Database Patterns to Know

> 🔍 **What is it?**
> Proven architectural patterns for solving common database challenges at scale: Read Replicas, CQRS, Event Sourcing, Materialized Views, and Connection Pooling.

> 💡 **Why it matters?**
> These patterns are how large-scale systems like Netflix, LinkedIn, and Uber solve real database problems. Knowing them shows you can think beyond "just add more RAM" and apply the right solution to each problem.

> ⚠️ **Without them (Impact):**
> Without Read Replicas: your Primary DB gets hammered with reads and writes simultaneously. Without Connection Pooling: each API request opens a new DB connection — at 10,000 concurrent users, you try to open 10,000 DB connections and the database **crashes** (PostgreSQL max is ~100-500 by default). Without CQRS: your read and write workloads interfere with each other, making both slower.

| Pattern | Description | Use Case |
|---------|-------------|---------|
| **Read Replica** | Scale reads to replicas | Read-heavy apps |
| **CQRS** | Separate read/write models | Complex domains |
| **Event Sourcing** | Store events, not state | Audit trail, undo |
| **Materialized View** | Pre-computed query results | Analytics dashboards |
| **Connection Pooling** | Reuse DB connections | High concurrency (PgBouncer) |

---

## ✅ Module 2 Summary Checklist

- [ ] Know when to use SQL vs NoSQL (and why)
- [ ] Can explain 4 types of NoSQL with examples
- [ ] Can explain replication and its types
- [ ] Can explain sharding strategies and trade-offs
- [ ] Know what indexes do and when to use them
- [ ] Can explain CQRS pattern

---

**Next:** [Module 3 - Caching →](../03-Caching/README.md)
