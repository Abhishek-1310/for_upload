# 🏛️ Module 7: Real World System Designs

> Practice these designs. In interviews, you'll be asked to design systems like these.

---

## How to Approach Any Design ⭐

> 🔍 **What is it?**
> A structured, repeatable framework for breaking down any system design problem in an interview or real planning session. It ensures you cover all dimensions: requirements, scale, architecture, APIs, deep dives, and trade-offs.

> 💡 **Why it matters?**
> Interviewers don't just want an answer — they want to see **how you think**. A structured approach shows senior-level thinking: you clarify before designing, estimate before choosing databases, and discuss trade-offs rather than claiming your design is "perfect".

> ⚠️ **Without a framework (Impact):**
> Candidates who jump straight to drawing boxes on a whiteboard without clarifying requirements often design the **wrong system entirely**. Spending 30 minutes designing a highly consistent system when the interviewer wanted high availability = fail. A framework prevents this and keeps you focused throughout the 45-minute session.

Use this framework every time:

```
1. CLARIFY Requirements (5 min)
   - Functional: What features?
   - Non-Functional: Scale, latency, availability?

2. ESTIMATE Scale (3 min)
   - DAU, QPS (read/write), storage

3. HIGH-LEVEL Design (10 min)
   - Draw main components
   - Data flow

4. DEEP DIVE (15 min)
   - Database schema
   - API design
   - Critical components

5. DISCUSS Trade-offs (5 min)
   - What are the bottlenecks?
   - How do you scale further?
```

---

## Design 1: URL Shortener (bit.ly) ⭐

> 🔍 **What is it?**
> A service that converts a long URL (e.g., `https://www.example.com/very/long/path?with=params`) into a short one (e.g., `bit.ly/abc123`), and redirects users to the original URL when the short link is clicked.

> 💡 **Why this is a great interview question?**
> It seems simple but covers many system design concepts: **hashing, base encoding, caching, database schema, redirect mechanics (301 vs 302), read-heavy optimization, and scalability**. Interviewers use it to test foundational thinking.

> ⚠️ **Key challenges to think about:**
> - Generating unique short codes at high write volume without collisions
> - Redirecting 120,000 reads/sec with sub-10ms latency (requires Redis caching)
> - Storing 18TB of URL mappings across 5 years (requires DB sharding)
> - Handling custom aliases, expiry, analytics (301 vs 302 trade-off)

### Requirements
- **Functional:** Shorten URL, redirect to original URL
- **Non-Functional:** 100M URLs/day, reads >> writes (100:1 ratio), low latency reads

### Estimation
```
Write QPS: 100M / 86400 ≈ 1200/sec
Read QPS:  1200 × 100 = 120,000/sec
Storage:   100M/day × 365 × 5 years × 100 bytes = ~18 TB
```

### Short URL Generation
```
Option 1: hash(long_url) → take first 7 chars
  Problem: collisions possible

Option 2: Base62 encoding of auto-increment ID
  ID: 1000000 → Base62: "4c92"  ← 7 chars = 62^7 = 3.5 trillion URLs

Option 3: Random 7-char string (check DB for uniqueness)
```

### Architecture
```
Client ──▶ API Gateway ──▶ [POST /shorten] URL Service ──▶ DB (id, short, long, expiry)
                             [GET /{shortCode}]
                                │
                           Cache (Redis: shortCode → longURL)
                                │
                     Cache HIT ──▶ 301/302 Redirect to longURL
                     Cache MISS ──▶ DB lookup ──▶ Cache ──▶ Redirect
```

### Database Schema
```sql
CREATE TABLE urls (
  id          BIGINT PRIMARY KEY AUTO_INCREMENT,
  short_code  VARCHAR(7) UNIQUE NOT NULL,
  long_url    TEXT NOT NULL,
  user_id     BIGINT,
  created_at  TIMESTAMP DEFAULT NOW(),
  expires_at  TIMESTAMP,
  click_count BIGINT DEFAULT 0
);
```

### 301 vs 302 Redirect
| | 301 (Permanent) | 302 (Temporary) |
|--|----------------|-----------------|
| Browser caches? | ✅ Yes (no future requests to us) | ❌ No (hits our server each time) |
| Analytics? | ❌ Can't track (browser handles) | ✅ Can track every click |
| Server load | Lower | Higher |

> **Use 302 if you need analytics. Use 301 to save server load.**

---

## Design 2: Twitter / Social Feed ⭐

> 🔍 **What is it?**
> A social platform where users post short messages (tweets), follow other users, and see a personalized "home timeline" — a feed of recent tweets from people they follow.

> 💡 **Why this is a great interview question?**
> It's the **canonical system design question** because it covers: massive read/write scale, the critical fan-out problem, caching with Redis sorted sets, Cassandra for time-series data, Kafka for async fan-out, and the fundamental read vs write optimization trade-off.

> ⚠️ **Key challenges to think about:**
> - How do you generate a feed for a user following 1,000 people at <100ms? (pre-computed vs real-time)
> - A celebrity has 50M followers: writing to 50M caches per tweet = write amplification problem
> - Hybrid fan-out: different strategies for regular users vs celebrities
> - Storing 500M tweets/day efficiently (Cassandra, time-series optimized)

### Requirements
- Post tweets (280 chars)
- Follow/Unfollow users
- View home timeline (tweets from followed users)
- Scale: 300M DAU, 500M tweets/day

### Estimation
```
Write QPS: 500M / 86400 ≈ 5,800/sec
Read QPS:  5,800 × 100 = 580,000/sec (very read-heavy)
Tweet storage: 500M × 280 bytes ≈ 140 GB/day
```

### Timeline Generation: Fan-out on Write vs Fan-out on Read

#### Fan-out on Write (Push Model)
```
User tweets → Immediately write to all followers' timeline caches
```
✅ Super fast reads (pre-computed feed)  
❌ Celebrities with 50M followers → 50M writes per tweet!  

#### Fan-out on Read (Pull Model)
```
User requests feed → Merge tweets from all followed users at read time
```
✅ No write amplification  
❌ Slow reads for users following many people  

#### Hybrid (Twitter's Actual Approach)
```
Normal users (< 1M followers): Fan-out on Write
Celebrities (> 1M followers): Fan-out on Read
```

### Architecture
```
Tweet Write:
Client ──▶ Tweet Service ──▶ Tweets DB
                         ──▶ Message Queue ──▶ Fan-out Service ──▶ Timeline Cache (Redis)

Feed Read:
Client ──▶ Feed Service ──▶ Timeline Cache (Redis) ──▶ Return feed
                        (merge with celebrity tweets at read time)
```

### Database Design
```sql
-- Tweets (Cassandra - write heavy, time-series)
tweet_id (UUID), user_id, content, media_url, created_at

-- Users (PostgreSQL)
user_id, username, email, bio, follower_count, following_count

-- Follows (Graph-like, or separate table)
follower_id, followee_id, created_at

-- Timeline (Redis Sorted Set - score = timestamp)
Key: "timeline:{user_id}"
Value: [tweet_id, tweet_id, ...] sorted by timestamp
```

---

## Design 3: YouTube / Video Streaming ⭐

> 🔍 **What is it?**
> A platform for uploading, processing, storing, and streaming video content to billions of users worldwide. Users can upload videos, search for content, comment, like, and subscribe to channels.

> 💡 **Why this is a great interview question?**
> It introduces unique challenges: **video transcoding pipeline** (encoding to multiple resolutions), object storage (S3), CDN for global delivery, **adaptive bitrate streaming (HLS/DASH)**, metadata databases, and search indexing. It covers both data-intensive and compute-intensive system design.

> ⚠️ **Key challenges to think about:**
> - A raw 4K video upload must be transcoded to 360p/720p/1080p (compute-heavy, async pipeline)
> - Videos must be served globally with low latency (CDN is essential, not optional)
> - 500 hours of video uploaded per minute = massive async processing queue
> - How does adaptive bitrate streaming auto-switch quality based on user bandwidth?

### Requirements
- Upload videos
- Stream videos
- Search videos
- Scale: 2B users, 500 hours of video uploaded per minute

### Video Upload Pipeline
```
Client ──▶ Upload Service ──▶ Raw Video Storage (S3)
                          ──▶ Message Queue
                                    │
                              Transcoding Service
                              (converts to multiple resolutions: 360p, 720p, 1080p, 4K)
                                    │
                              Processed Video Storage (S3)
                                    │
                              CDN Distribution (videos served from edge)
```

### Video Streaming
```
Client ──▶ CDN Edge Server ──▶ [cache hit] ──▶ Stream video chunks
                          ──▶ [cache miss] ──▶ Origin S3 ──▶ Cache ──▶ Stream
```

**Adaptive Bitrate Streaming (HLS/DASH):**
```
Player detects bandwidth → switches quality automatically
Good internet → 1080p
Slow internet → 360p (no buffering)
```

### Database Schema
```sql
-- Videos metadata
video_id, uploader_id, title, description, thumbnail_url,
duration, view_count, like_count, status (processing/ready), created_at

-- Comments (Cassandra - write heavy)
comment_id, video_id, user_id, content, created_at

-- Search (Elasticsearch)
video_id, title, description, tags, transcript
```

---

## Design 4: WhatsApp / Chat App ⭐

> 🔍 **What is it?**
> A real-time messaging application supporting 1:1 messages, group chats, online/offline presence detection, read receipts (single tick, double tick, blue tick), and push notifications for offline users.

> 💡 **Why this is a great interview question?**
> It requires deep understanding of **WebSocket connections** for real-time delivery, **presence systems** using Redis TTL, **message storage at scale** (100B messages/day), push notifications for offline users, and the tricky ordering and delivery guarantees needed for a correct chat system.

> ⚠️ **Key challenges to think about:**
> - Maintaining persistent WebSocket connections for 2B users simultaneously
> - Online/offline presence detection without polling (Redis key expiry with heartbeat)
> - Delivery receipts: how does WhatsApp know you read a message? (client sends read receipt event)
> - Messages must be delivered in order and exactly once (message ID sequencing)
> - Group messages to 256 members: 256 fan-outs per message sent

### Requirements
- 1:1 messaging
- Group messaging (up to 256 members)
- Online/offline status
- Read receipts (single tick, double tick, blue tick)
- Scale: 2B users, 100B messages/day

### Core Architecture
```
Client A ──WebSocket──▶ Chat Server (stateful) ──▶ Message DB
Client B ◀─WebSocket── Chat Server               (store all messages)
                              │
                         Presence Service (who is online?)
                              │
                         Push Notification Service
                         (if user is offline)
```

### Message Flow
```
1. Client A sends message to Chat Server
2. Chat Server stores message in DB (status: SENT ✓)
3. Check if Client B is online:
   a. ONLINE → deliver via WebSocket (status: DELIVERED ✓✓)
   b. OFFLINE → push notification + store for later delivery
4. Client B reads message → send read receipt (status: READ 🔵🔵)
```

### Group Messages
```
Group of 256 members:
Message arrives ──▶ Fan-out to all 256 member WebSocket connections
                ──▶ For offline members: push notification
```

### Online Presence
```
User connects   → SET online:user_id 1 EX 60 (Redis)
User heartbeat  → Refresh TTL every 30s
User disconnects → Key expires, user is "offline"
```

---

## Design 5: Ride Sharing (Uber) ⭐

> 🔍 **What is it?**
> A real-time marketplace matching riders who need rides with nearby drivers. It requires live GPS tracking of drivers, geospatial queries to find nearby drivers, intelligent matching, and dynamic pricing.

> 💡 **Why this is a great interview question?**
> It introduces **geospatial data** (Redis Geo, QuadTree, Geohash), real-time location updates at high frequency (every 5 seconds from millions of drivers), **supply-demand matching algorithms**, surge pricing computation, and the challenge of real-time systems with strict latency requirements.

> ⚠️ **Key challenges to think about:**
> - Tracking millions of driver GPS positions updating every 5 seconds = massive write volume
> - Finding drivers within 5km radius in <100ms (geospatial indexing is critical)
> - Matching algorithm must be fair, fast, and minimize ETA
> - Surge pricing must react to supply/demand changes in near real-time per geographic zone
> - What happens if a driver accepts then cancels? (retry logic and timeout handling)

### Requirements
- Rider requests ride
- Match with nearby driver
- Real-time location tracking
- Pricing (surge pricing)

### Location Tracking
```
Driver app sends GPS every 5 seconds:
Driver ──▶ Location Service ──▶ Location Store (Redis Geo)

Redis Geo commands:
GEOADD drivers:locations long lat driver_id
GEORADIUS drivers:locations long lat 5 km  ← find drivers within 5km
```

### Matching Algorithm
```
Rider requests ride at (lat, lng)
  ↓
Find all drivers within radius (using Redis GEORADIUS)
  ↓
Filter: driver is available, no current ride
  ↓
Rank by: distance, rating, ETA
  ↓
Offer trip to top driver (timeout: 10s)
  ↓
If declined → offer to next driver
  ↓
Match found → notify rider + driver
```

### Surge Pricing
```
Detect supply/demand imbalance per geographic zone:
  Demand (rides requested) >> Supply (available drivers)
    → Apply surge multiplier (1.5x, 2x, ...)
```

---

## Design 6: Google Drive / Dropbox

> 🔍 **What is it?**
> A cloud file storage and sync service where users can upload files from any device, access them anywhere, share them with others, and have changes automatically synchronized across all their devices.

> 💡 **Why this is a great interview question?**
> It covers **file chunking** (splitting large files for parallel upload and delta sync), object storage (S3), metadata database design, real-time sync mechanisms, **conflict resolution** (what if two devices edit the same file?), and efficient delta transfers (only upload what changed).

> ⚠️ **Key challenges to think about:**
> - Large file uploads must survive network interruptions (chunking + resume support)
> - Sync across devices must be near real-time (WebSocket/SSE for change notifications)
> - Only changed chunks should be re-uploaded (delta sync = massive bandwidth savings)
> - Two users editing the same doc simultaneously = conflict resolution strategy
> - 1B users × average 5GB = 5 exabytes of storage to manage

### Requirements
- Upload/download files
- File sync across devices
- Share files/folders
- Scale: 1B users

### Architecture
```
Client ──▶ Upload Service ──▶ Chunk Storage (S3)
                          ──▶ Metadata DB (file info, chunks, versions)

Sync:
Client watches local folder changes
  → Detect change → Upload delta (only changed chunks)
  → Notify other clients via WebSocket/SSE
  → Other clients pull changes
```

### Chunking Strategy
```
Large file (e.g., 1 GB video):
Split into 4 MB chunks
Upload each chunk in parallel
Reassemble on download

Benefits:
- Resume from where upload failed
- Only upload CHANGED chunks (sync efficiency)
- Parallel upload = faster
```

---

## Design 7: Rate Limiter (System Design Deep Dive)

> 🔍 **What is it?**
> A component in your API infrastructure that **limits how many requests a user/client can make** within a time window to protect your backend services from being overwhelmed by excessive or malicious traffic.

> 💡 **Why this is a great interview question?**
> It's deceptively simple but involves: choosing the right **algorithm** (Token Bucket, Leaky Bucket, Sliding Window), **distributed state management** (using Redis atomically), handling **race conditions** in concurrent environments, and deciding where to enforce limits (gateway vs service level).

> ⚠️ **Key challenges to think about:**
> - Rate limits must be enforced across multiple API gateway instances (shared Redis state)
> - The Redis counter update must be **atomic** (INCR is atomic; GET + SET is not — race condition!)
> - Different limits for different users (free tier vs premium)
> - What to do when Redis is down? (fail-open vs fail-closed trade-off)
> - Fixed window edge case: 200 requests at 00:59 + 200 at 01:01 = 400 in 2 seconds despite 200/min limit

### Architecture
```
Client ──▶ API Gateway ──▶ Rate Limiter ──▶ Backend Service
                               │
                          Redis Counter
```

### Implementation
```python
def is_allowed(user_id: str, limit: int = 100) -> bool:
    key = f"rate:{user_id}:{current_minute()}"
    count = redis.incr(key)
    if count == 1:
        redis.expire(key, 60)
    return count <= limit
```

---

## ✅ Module 7 Summary Checklist

- [ ] Can design URL Shortener end-to-end
- [ ] Understand fan-out on write vs fan-out on read for feeds
- [ ] Know video upload/transcoding pipeline
- [ ] Can design real-time chat with WebSockets and presence
- [ ] Understand geospatial queries for location-based apps
- [ ] Can design file chunking and sync

---

**Next:** [Module 8 - Interview Cheatsheet →](../08-Interview-Cheatsheet/README.md)
