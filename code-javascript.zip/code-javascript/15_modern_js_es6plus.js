// ============================================================
// 🎬 CHAPTER 15: DESTRUCTURING, OPTIONAL CHAINING & MORE ES6+
// 📖 Story: Modern JS tools that make code 10x cleaner.
//           Every line of React/Node code uses these!
// ============================================================

// ╔══════════════════════════════════════════════════════════╗
// ║  ❓ WHY DO WE NEED THESE MODERN FEATURES?               ║
// ╠══════════════════════════════════════════════════════════╣
// ║                                                          ║
// ║  Without them: code is verbose, crash-prone, and messy  ║
// ║                                                          ║
// ║  // ❌ OLD WAY — extracting object data                 ║
// ║  const name = user.name;                                ║
// ║  const age  = user.age;                                 ║
// ║  const city = user.address && user.address.city; // ugh ║
// ║  if (!city) { throw "no city"; }                        ║
// ║                                                          ║
// ║  // ✅ MODERN WAY — clean, safe, concise                ║
// ║  const { name, age, address: { city } = {} } = user;   ║
// ║  const safeCity = user?.address?.city ?? "Unknown";     ║
// ║                                                          ║
// ║  🎯 WHAT THEY UNLOCK:                                   ║
// ║  → Less code, fewer bugs                                ║
// ║  → Crash-safe property access                           ║
// ║  → Used in EVERY modern JS/React codebase               ║
// ╚══════════════════════════════════════════════════════════╝

// ══════════════════════════════════════════
// PART 1: DESTRUCTURING
// ══════════════════════════════════════════

console.log("=== ARRAY DESTRUCTURING ===\n");

// ──────────────────────────────────────────
// 📦 Array Destructuring
// ──────────────────────────────────────────

const colors = ["red", "green", "blue", "yellow", "purple"];

// ❌ Old way:
const oldFirst = colors[0];
const oldSecond = colors[1];

// ✅ Destructuring:
const [first, second, third] = colors;
console.log(first, second, third); // red green blue

// Skip elements:
const [, , , fourth] = colors;
console.log("4th color:", fourth); // yellow

// Rest with arrays:
const [head, ...tail] = colors;
console.log("Head:", head);   // red
console.log("Tail:", tail);   // ['green', 'blue', 'yellow', 'purple']

// Default values:
const [a = "default-a", b = "default-b"] = ["only-a"];
console.log(a, b); // "only-a", "default-b"

// Swap variables! (Classic interview trick)
let x = 10, y = 20;
[x, y] = [y, x];
console.log("Swapped:", x, y); // 20, 10

// Destructure function return:
function getCoordinates() {
  return [28.6139, 77.2090]; // Delhi coordinates
}
const [latitude, longitude] = getCoordinates();
console.log(`📍 Lat: ${latitude}, Long: ${longitude}`);

// ──────────────────────────────────────────
console.log("\n=== OBJECT DESTRUCTURING ===\n");
// ──────────────────────────────────────────

const user = {
  name:    "Abhishek",
  age:     25,
  city:    "Mumbai",
  job:     "Developer",
  salary:  80000,
};

// Basic destructuring:
const { name, age, city } = user;
console.log(name, age, city); // Abhishek 25 Mumbai

// Rename while destructuring:
const { name: fullName, salary: monthlyPay } = user;
console.log(fullName, monthlyPay); // Abhishek 80000

// Default values:
const { country = "India", pincode = "400001" } = user;
console.log(country, pincode); // India 400001 (user doesn't have these!)

// Rest in objects:
const { name: personName, ...rest } = user;
console.log("Name:", personName);
console.log("Rest:", rest); // everything except name

// Nested object destructuring:
const employee = {
  id:      101,
  details: {
    name:    "Priya",
    skills:  ["JS", "React", "Node"],
    address: { city: "Delhi", state: "Delhi" },
  },
};

const {
  id,
  details: {
    name: empName,
    skills: [primarySkill, ...otherSkills],
    address: { city: empCity },
  },
} = employee;

console.log("\n🏢 Employee:", empName, "| ID:", id);
console.log("📍 City:", empCity);
console.log("💻 Primary skill:", primarySkill, "| Other:", otherSkills);

// Destructuring in function parameters:
function displayUser({ name, age, city = "Unknown" }) {
  console.log(`\n👤 ${name}, ${age}, from ${city}`);
}
displayUser(user);
displayUser({ name: "Raj", age: 30 }); // city defaults to "Unknown"

// ══════════════════════════════════════════
// PART 2: OPTIONAL CHAINING ?.
// "Access deep properties SAFELY without crashing"
// ══════════════════════════════════════════

console.log("\n\n=== OPTIONAL CHAINING (?.) ===\n");

const userProfile = {
  name: "Abhishek",
  address: {
    city: "Mumbai",
    // pincode missing!
  },
  getGreeting() {
    return `Hello, ${this.name}!`;
  },
};

const emptyUser = {};

// ❌ Old way — crashes if any property is missing:
// const pin = userProfile.address.pincode.toString(); // TypeError!

// ✅ Old safe way — very verbose:
const oldPin = userProfile && userProfile.address && userProfile.address.pincode;
console.log("Old safe:", oldPin); // undefined (no crash)

// ✅ Optional chaining — clean and safe:
const pin     = userProfile?.address?.pincode;         // undefined
const country2 = emptyUser?.address?.country;          // undefined (no crash!)
const greeting = userProfile?.getGreeting?.();         // calls method safely
const missing  = emptyUser?.getGreeting?.();           // undefined (no crash!)

console.log("Pin:      ", pin);       // undefined
console.log("Country:  ", country2);  // undefined
console.log("Greeting: ", greeting);  // "Hello, Abhishek!"
console.log("Missing:  ", missing);   // undefined

// Optional chaining with arrays:
const data = { users: [{ name: "Abhishek" }, { name: "Priya" }] };
const emptyData = {};

console.log(data?.users?.[0]?.name);       // "Abhishek"
console.log(emptyData?.users?.[0]?.name);  // undefined (safe!)

// ══════════════════════════════════════════
// PART 3: NULLISH COALESCING ??
// "Use default ONLY if value is null or undefined"
// ══════════════════════════════════════════

console.log("\n\n=== NULLISH COALESCING (??) ===\n");

// The Problem with || (OR):
const score = 0;
const oldDefault = score || 100; // ❌ returns 100! (0 is falsy)
console.log("|| problem:", oldDefault); // 100 — WRONG! 0 is a valid score!

// ?? only treats null and undefined as "missing":
const newDefault = score ?? 100; // ✅ returns 0! (0 is NOT null/undefined)
console.log("?? correct:", newDefault); // 0 — CORRECT!

// Real-life comparison:
const settings = {
  theme:         "dark",
  volume:        0,        // valid value!
  notifications: false,    // valid value!
  username:      null,     // truly missing
  timeout:       undefined // truly missing
};

// || would wrongly use defaults for 0 and false:
console.log("\n|| (OR) — has false-positive defaults:");
console.log("  volume:       ", settings.volume        || 50);   // ❌ 50 (wrong!)
console.log("  notifications:", settings.notifications || true); // ❌ true (wrong!)
console.log("  username:     ", settings.username      || "Guest"); // ✅ "Guest"

// ?? only uses defaults for null/undefined:
console.log("\n?? — only defaults for null/undefined:");
console.log("  volume:       ", settings.volume        ?? 50);   // ✅ 0
console.log("  notifications:", settings.notifications ?? true); // ✅ false
console.log("  username:     ", settings.username      ?? "Guest"); // ✅ "Guest"
console.log("  timeout:      ", settings.timeout       ?? 3000); // ✅ 3000

// Combine with optional chaining:
const config = null;
const port = config?.server?.port ?? 8080;
console.log("\nDefault port:", port); // 8080

// ══════════════════════════════════════════
// PART 4: LOGICAL ASSIGNMENT OPERATORS
// ══════════════════════════════════════════

console.log("\n\n=== LOGICAL ASSIGNMENT OPERATORS ===\n");

// ??= Nullish assignment (assign only if null or undefined)
let name2 = null;
name2 ??= "Default Name";
console.log("??=:", name2); // "Default Name"

let existingName = "Abhishek";
existingName ??= "Default Name";
console.log("??= (existing):", existingName); // "Abhishek" (unchanged!)

// ||= Logical OR assignment (assign if falsy)
let count = 0;
count ||= 10;
console.log("||=:", count); // 10 (0 is falsy)

// &&= Logical AND assignment (assign if truthy)
let isLoggedIn = true;
isLoggedIn &&= "yes";
console.log("&&=:", isLoggedIn); // "yes"

// ══════════════════════════════════════════
// PART 5: SET & MAP (Important data structures!)
// ══════════════════════════════════════════

console.log("\n\n=== SET (Unique values only) ===\n");

// Set — like array but NO DUPLICATES
const mySet = new Set([1, 2, 3, 2, 1, 4, 3]);
console.log("Set:", mySet);         // Set {1, 2, 3, 4}
console.log("Size:", mySet.size);   // 4

mySet.add(5);
mySet.delete(1);
console.log("Has 2?", mySet.has(2)); // true
console.log("Has 1?", mySet.has(1)); // false (deleted)

// Convert back to array:
const uniqueArr = [...mySet];
console.log("As array:", uniqueArr);

// 🔥 SUPER USEFUL: Remove duplicates from array!
const names = ["Abhishek", "Priya", "Raj", "Priya", "Abhishek", "Sneha"];
const uniqueNames = [...new Set(names)];
console.log("\nUnique names:", uniqueNames);

// Find intersection of two arrays:
const setA = new Set([1, 2, 3, 4, 5]);
const setB = new Set([3, 4, 5, 6, 7]);
const intersection = [...setA].filter(x => setB.has(x));
const union        = [...new Set([...setA, ...setB])];
console.log("Intersection:", intersection); // [3, 4, 5]
console.log("Union:       ", union);        // [1,2,3,4,5,6,7]

// ──────────────────────────────────────────
console.log("\n=== MAP (Key-Value pairs, any key type) ===\n");
// Map — like object but keys can be ANYTHING (not just strings)
// ──────────────────────────────────────────

const myMap = new Map();

// Keys can be anything!
myMap.set("name",   "Abhishek");  // string key
myMap.set(1,        "one");        // number key
myMap.set(true,     "boolean");   // boolean key
myMap.set({ id: 1 },"object key"); // object key!

console.log("Name:", myMap.get("name")); // "Abhishek"
console.log("Size:", myMap.size);         // 4

// Iterate Map:
console.log("\nAll entries:");
for (const [key, value] of myMap) {
  console.log(`  ${String(key)} → ${value}`);
}

// 🔥 REAL USE: Word frequency counter
const words = "the cat sat on the mat the cat sat".split(" ");
const frequency = new Map();

words.forEach(word => {
  frequency.set(word, (frequency.get(word) || 0) + 1);
});

console.log("\nWord frequency:");
[...frequency.entries()]
  .sort((a, b) => b[1] - a[1])
  .forEach(([word, count]) => console.log(`  "${word}": ${count}`));

// ══════════════════════════════════════════
// PART 6: SHORT CIRCUIT EVALUATION
// ══════════════════════════════════════════

console.log("\n\n=== SHORT CIRCUIT EVALUATION ===\n");

// && (AND) — returns first FALSY value, or last value if all truthy
console.log(0 && "hello");     // 0 (first falsy)
console.log("" && "hello");    // "" (first falsy)
console.log("hi" && "world");  // "world" (all truthy, returns last)
console.log(true && doSomething()); // calls doSomething only if true

function doSomething() {
  console.log("  doSomething() called!");
  return "done";
}

// || (OR) — returns first TRUTHY value
console.log(0 || "fallback");  // "fallback" (0 is falsy)
console.log("" || "default");  // "default"
console.log("value" || "default"); // "value" (first truthy)

// PRACTICAL: Conditional rendering (React pattern)
const isLoggedIn2 = true;
const username2   = "Abhishek";

// Only show welcome if logged in:
const welcomeMsg = isLoggedIn2 && `Welcome, ${username2}!`;
console.log("\nWelcome:", welcomeMsg); // "Welcome, Abhishek!"

// ══════════════════════════════════════════
// PART 7: TEMPLATE LITERALS (Advanced)
// ══════════════════════════════════════════

console.log("\n\n=== TEMPLATE LITERALS ===\n");

// Multi-line strings:
const multiLine = `
  Line 1
  Line 2
  Line 3
`.trim();
console.log(multiLine);

// Expressions inside:
const a2 = 10, b2 = 20;
console.log(`Sum: ${a2 + b2}, Product: ${a2 * b2}`);

// Conditional in template:
const temp = 35;
console.log(`Weather: ${temp > 30 ? "🔥 Hot" : "😊 Pleasant"}`);

// Function call in template:
const shout = (str) => str.toUpperCase() + "!!!";
console.log(`Greeting: ${shout("hello world")}`);

// Tagged template literals (advanced):
function highlight(strings, ...values) {
  return strings.reduce((result, str, i) => {
    return result + str + (values[i] ? `[${values[i]}]` : "");
  }, "");
}

const product = "Laptop";
const price   = 45000;
console.log(highlight`The ${product} costs ₹${price} today.`);
// "The [Laptop] costs ₹[45000] today."

// ============================================================
// 🧪 YOUR CODING CHALLENGES - TRY THESE!
// ============================================================

// 🟡 CHALLENGE 1 (Easy — Destructuring):
// Given:
// const order = {
//   id: "ORD-001",
//   customer: { name: "Abhishek", phone: "9876543210" },
//   items: [
//     { product: "Phone", price: 15000, qty: 1 },
//     { product: "Case",  price: 500,   qty: 2 },
//   ],
//   status: "delivered",
//   address: { city: "Mumbai", pincode: "400001" },
// };
// Destructure to get: id, customerName, firstProduct, city
// All in ONE destructuring statement!

// 🟠 CHALLENGE 2 (Medium):
// Build a `getConfig(userConfig)` function:
// - Has default config: { theme: "light", lang: "en", fontSize: 14 }
// - User config overrides defaults (use spread)
// - Safely access nested: userConfig?.notifications?.email ?? true
// - Use ?? to default any missing numeric values to 0
// - Return final merged config object

// 🔴 CHALLENGE 3 (Hard — Set + Map):
// Build a `ContactBook` using Map and Set:
// - addContact(name, phone, tags[])  → adds to Map, tags to Set
// - findByTag(tag)                   → returns all contacts with that tag
// - getAllTags()                      → returns all unique tags (Set)
// - removeDuplicatePhones()          → finds and logs duplicate phone numbers
// - exportContacts()                 → returns array of all contacts
// Add 5 contacts with overlapping tags and test all methods!
