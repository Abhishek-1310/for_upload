// ============================================================
// 🎬 CHAPTER 4: CLOSURES
// 📖 Story: A SECRET LOCKER 🔐
//           The locker (inner function) remembers the combination
//           (outer variable) even after the locker shop is closed!
// ============================================================

// ╔══════════════════════════════════════════════════════════╗
// ║  ❓ WHY DO WE NEED CLOSURES?                             ║
// ╠══════════════════════════════════════════════════════════╣
// ║                                                          ║
// ║  🔴 THE PROBLEM (without closures):                      ║
// ║  In JS, all variables declared with var/let/const are    ║
// ║  either GLOBAL (anyone can read/change them) or          ║
// ║  LOCAL (destroyed after function ends).                  ║
// ║                                                          ║
// ║  Without closures you CANNOT:                            ║
// ║  → Keep data PRIVATE (no true private variables)         ║
// ║  → Preserve state between function calls                 ║
// ║  → Create independent instances with their own data      ║
// ║                                                          ║
// ║  // ❌ WITHOUT CLOSURES — data is global, anyone changes it
// ║  let balance = 1000; // ⚠️ anyone can do: balance = 0!   ║
// ║  function deposit(amt) { balance += amt; }               ║
// ║  balance = 0; // ❌ Hacked! No protection at all.        ║
// ║                                                          ║
// ║  ✅ THE SOLUTION (with closures):                        ║
// ║  // ✅ balance is PRIVATE — only deposit/withdraw touch it
// ║  function createAccount() {                              ║
// ║    let balance = 1000; // locked inside closure!         ║
// ║    return {                                              ║
// ║      deposit: (amt) => balance += amt,                   ║
// ║      getBalance: () => balance,                          ║
// ║    };                                                    ║
// ║  }                                                       ║
// ║  // balance = 0; ❌ Can't! It doesn't exist outside.    ║
// ║                                                          ║
// ║  🎯 WHAT CLOSURES UNLOCK:                                ║
// ║  → PRIVATE variables & methods (data encapsulation)      ║
// ║  → State that PERSISTS between calls (counters, caches)  ║
// ║  → FACTORY functions — create independent instances      ║
// ║  → Memoization — cache expensive results                 ║
// ║  → Module pattern — organize code like a mini app        ║
// ║  → Foundation of React Hooks (useState uses closures!)   ║
// ╚══════════════════════════════════════════════════════════╝

// A CLOSURE = inner function + it REMEMBERS the outer function's variables
//             even after the outer function has finished executing!

// ──────────────────────────────────────────
// 🔰 BASIC CLOSURE
// ──────────────────────────────────────────

function outerFunction() {
  const secret = "🔐 I am the secret!"; // outer variable

  function innerFunction() {
    console.log(secret); // inner function REMEMBERS secret
  }

  return innerFunction; // returning the function (not calling it!)
}

const mySecret = outerFunction(); // outerFunction is DONE now
mySecret(); // but innerFunction still REMEMBERS secret!  ← This is CLOSURE!

// ──────────────────────────────────────────
// 🏧 REAL LIFE: Bank Account (Private Balance)
// Story: Your bank balance is PRIVATE. Only deposit/withdraw can access it!
// ──────────────────────────────────────────

function createBankAccount(initialBalance) {
  let balance = initialBalance; // 🔒 PRIVATE — no one can access directly!

  return {
    deposit: function (amount) {
      balance += amount;
      console.log(`💰 Deposited ₹${amount}. New Balance: ₹${balance}`);
    },
    withdraw: function (amount) {
      if (amount > balance) {
        console.log("❌ Insufficient funds!");
      } else {
        balance -= amount;
        console.log(`💸 Withdrew ₹${amount}. New Balance: ₹${balance}`);
      }
    },
    getBalance: function () {
      console.log(`💳 Current Balance: ₹${balance}`);
      return balance;
    },
  };
}

const myAccount = createBankAccount(1000);
myAccount.deposit(500);    // ₹1500
myAccount.withdraw(200);   // ₹1300
myAccount.getBalance();    // ₹1300
// console.log(myAccount.balance); // undefined — PRIVATE! 🔒

// ──────────────────────────────────────────
// 🏭 FACTORY FUNCTION with Closure
// Story: A counter machine — each machine has its OWN count
// ──────────────────────────────────────────

function makeCounter(startFrom = 0) {
  let count = startFrom;

  return {
    increment: () => ++count,
    decrement: () => --count,
    reset:     () => { count = startFrom; },
    getCount:  () => count,
  };
}

const counter1 = makeCounter(0);
const counter2 = makeCounter(10);

console.log("\n🔢 Counter 1:", counter1.increment()); // 1
console.log("🔢 Counter 1:", counter1.increment()); // 2
console.log("🔢 Counter 2:", counter2.increment()); // 11
console.log("🔢 Counter 2:", counter2.increment()); // 12
console.log("↩️  Counter 1 reset:", counter1.reset() || counter1.getCount()); // 0
// Each counter has its OWN private 'count'! Completely independent!

// ──────────────────────────────────────────
// ⚠️ CLASSIC CLOSURE TRAP (Interview Favorite!)
// Story: Setting timers in a loop
// ──────────────────────────────────────────

console.log("\n❌ WRONG (var — all print 3):");
for (var i = 0; i < 3; i++) {
  setTimeout(function () {
    console.log("  var i =", i); // prints 3, 3, 3  ← BUG!
  }, 100);
}

console.log("\n✅ FIXED with let (block scope):");
for (let j = 0; j < 3; j++) {
  setTimeout(function () {
    console.log("  let j =", j); // prints 0, 1, 2  ← CORRECT!
  }, 200);
}

console.log("\n✅ FIXED with IIFE (old way):");
for (var k = 0; k < 3; k++) {
  (function (k) {
    setTimeout(function () {
      console.log("  IIFE k =", k); // prints 0, 1, 2  ← CORRECT!
    }, 300);
  })(k);
}

// ──────────────────────────────────────────
// 🎯 MEMOIZATION using Closure
// Story: A calculator that REMEMBERS previous results (cache)
// ──────────────────────────────────────────

function memoize(fn) {
  const cache = {}; // 📦 stored in closure!

  return function (...args) {
    const key = JSON.stringify(args);

    if (cache[key]) {
      console.log(`⚡ Cache hit for (${args})! Result: ${cache[key]}`);
      return cache[key];
    }

    console.log(`🔄 Computing for (${args})...`);
    const result = fn(...args);
    cache[key] = result;
    return result;
  };
}

function slowSquare(n) {
  // Imagine this is a heavy calculation
  return n * n;
}

const fastSquare = memoize(slowSquare);

console.log("\n📊 Memoization Demo:");
fastSquare(5);  // 🔄 Computing...
fastSquare(5);  // ⚡ Cache hit!
fastSquare(6);  // 🔄 Computing...
fastSquare(6);  // ⚡ Cache hit!

// ──────────────────────────────────────────
// 🔒 MODULE PATTERN using Closure
// Story: A Todo App with private data
// ──────────────────────────────────────────

const TodoApp = (function () {
  let todos = []; // 🔒 PRIVATE!
  let nextId = 1;

  return {
    addTodo: function (task) {
      const todo = { id: nextId++, task, done: false };
      todos.push(todo);
      console.log(`\n✅ Added: "${task}" (ID: ${todo.id})`);
    },
    completeTodo: function (id) {
      const todo = todos.find((t) => t.id === id);
      if (todo) {
        todo.done = true;
        console.log(`☑️  Completed: "${todo.task}"`);
      }
    },
    listTodos: function () {
      console.log("\n📋 Todo List:");
      todos.forEach((t) =>
        console.log(`  ${t.done ? "☑️ " : "⬜"} [${t.id}] ${t.task}`)
      );
    },
  };
})(); // IIFE — runs immediately!

TodoApp.addTodo("Learn Closures");
TodoApp.addTodo("Practice Promises");
TodoApp.addTodo("Build a Project");
TodoApp.completeTodo(1);
TodoApp.listTodos();

// ============================================================
// 🧪 YOUR CODING CHALLENGES - TRY THESE!
// ============================================================

// 🟡 CHALLENGE 1 (Easy):
// Create a function `makeGreeter(greeting)` using closure.
// It should return a function that takes a name and prints:
// "[greeting], [name]!"
// const sayHello = makeGreeter("Hello");
// sayHello("Abhishek") → "Hello, Abhishek!"
// sayHello("Priya")    → "Hello, Priya!"

// 🟠 CHALLENGE 2 (Medium):
// Build a `createWallet(initialAmount)` using closure with:
//   - add(amount)     → add money
//   - spend(amount)   → spend money (check if enough balance)
//   - history()       → show all transactions
//   - balance()       → show current balance
// The wallet's internal data should be PRIVATE!

// 🔴 CHALLENGE 3 (Hard):
// Build a Rate Limiter using closure:
// `createRateLimiter(limit, windowMs)`
// Returns a function. If called more than `limit` times
// within `windowMs` milliseconds, it should say "Rate limit exceeded!"
// Otherwise process the request.
// (Hint: store call timestamps in closure!)
