// ============================================================
// 🎬 CHAPTER 16: DESIGN PATTERNS
// 📖 Story: You're an ARCHITECT 🏗️
//           You don't design a building from scratch every time.
//           You use PROVEN BLUEPRINTS that solve known problems.
//           Design patterns are those blueprints for code!
// ============================================================

// ╔══════════════════════════════════════════════════════════╗
// ║  ❓ WHY DO WE NEED DESIGN PATTERNS?                     ║
// ╠══════════════════════════════════════════════════════════╣
// ║                                                          ║
// ║  🔴 THE PROBLEM (without patterns):                     ║
// ║  As your app grows, code becomes spaghetti:             ║
// ║  → Same problems solved differently every time          ║
// ║  → No common language between developers                ║
// ║  → Changing one thing breaks 10 others                  ║
// ║  → Hard to test, maintain, or extend                    ║
// ║                                                          ║
// ║  // ❌ WITHOUT patterns — tight coupling, messy         ║
// ║  function placeOrder(item) {                            ║
// ║    const db = new Database();   // hardcoded!           ║
// ║    const email = new Email();   // hardcoded!           ║
// ║    const log = new Logger();    // hardcoded!           ║
// ║    // changing Database breaks this entire function!    ║
// ║  }                                                       ║
// ║                                                          ║
// ║  🎯 WHAT DESIGN PATTERNS UNLOCK:                        ║
// ║  → Proven solutions to common problems                  ║
// ║  → Common vocabulary ("use Observer here")              ║
// ║  → Loosely coupled, easy to change code                 ║
// ║  → Code that's easy to test and extend                  ║
// ║  → Separates Junior from Mid/Senior developers          ║
// ║  → Asked in Mid/Senior level interviews!                ║
// ╚══════════════════════════════════════════════════════════╝

// ============================================================
// 3 CATEGORIES OF DESIGN PATTERNS:
//
//  1. CREATIONAL  → How objects are CREATED
//     (Singleton, Factory, Builder, Prototype)
//
//  2. STRUCTURAL  → How objects are COMPOSED/STRUCTURED
//     (Module, Decorator, Facade, Proxy, Adapter)
//
//  3. BEHAVIORAL  → How objects COMMUNICATE
//     (Observer, Strategy, Command, Iterator, Template)
// ============================================================

// ══════════════════════════════════════════════════════════════
// 🏭 CREATIONAL PATTERNS
// ══════════════════════════════════════════════════════════════

// ─────────────────────────────────────────────────────────────
// 1️⃣  SINGLETON PATTERN
// 📖 Story: Your app has ONE settings panel.
//           No matter how many times you open it,
//           it's always THE SAME panel — same instance!
//
// WHY: Ensure only ONE instance of something exists globally.
// USE: Config managers, DB connections, App-wide state, Logger
// ─────────────────────────────────────────────────────────────

console.log("1️⃣  SINGLETON PATTERN\n");

class AppConfig {
  static #instance = null; // private static field

  #settings = {
    theme:    "dark",
    language: "en",
    version:  "1.0.0",
  };

  constructor() {
    if (AppConfig.#instance) {
      return AppConfig.#instance; // return existing instance!
    }
    AppConfig.#instance = this;
  }

  get(key)        { return this.#settings[key]; }
  set(key, value) { this.#settings[key] = value; }
  getAll()        { return { ...this.#settings }; }
}

const config1 = new AppConfig();
const config2 = new AppConfig();

config1.set("theme", "light");

console.log("config1 theme:", config1.get("theme")); // "light"
console.log("config2 theme:", config2.get("theme")); // "light" — SAME instance!
console.log("Same instance?", config1 === config2);  // true ✅

// Real-life: Database connection pool
class DatabaseConnection {
  static #instance = null;
  #connectionCount = 0;

  constructor(connectionString) {
    if (DatabaseConnection.#instance) {
      console.log("  ♻️  Reusing existing DB connection");
      return DatabaseConnection.#instance;
    }
    this.connectionString = connectionString;
    this.#connectionCount++;
    console.log("  🔌 New DB connection created:", connectionString);
    DatabaseConnection.#instance = this;
  }

  query(sql) {
    console.log(`  📊 Running: ${sql}`);
  }
}

const db1 = new DatabaseConnection("mongodb://localhost:27017/myapp");
const db2 = new DatabaseConnection("mongodb://localhost:27017/myapp");
db1.query("SELECT * FROM users");
console.log("db1 === db2:", db1 === db2); // true ✅

// ─────────────────────────────────────────────────────────────
// 2️⃣  FACTORY PATTERN
// 📖 Story: A VEHICLE FACTORY 🏭
//           You say "I want a Car" or "I want a Bike".
//           The factory creates the RIGHT object for you.
//           You don't care HOW it's made — just WHAT you get!
//
// WHY: Create objects without specifying exact class.
//      Centralizes object creation logic.
// USE: When you don't know what type to create until runtime
// ─────────────────────────────────────────────────────────────

console.log("\n\n2️⃣  FACTORY PATTERN\n");

class Car {
  constructor(model, price) {
    this.type  = "Car";
    this.model = model;
    this.price = price;
    this.wheels = 4;
  }
  describe() {
    console.log(`  🚗 Car: ${this.model} | ₹${this.price} | ${this.wheels} wheels`);
  }
}

class Bike {
  constructor(model, price) {
    this.type  = "Bike";
    this.model = model;
    this.price = price;
    this.wheels = 2;
  }
  describe() {
    console.log(`  🏍️  Bike: ${this.model} | ₹${this.price} | ${this.wheels} wheels`);
  }
}

class Truck {
  constructor(model, price) {
    this.type  = "Truck";
    this.model = model;
    this.price = price;
    this.wheels = 18;
  }
  describe() {
    console.log(`  🚛 Truck: ${this.model} | ₹${this.price} | ${this.wheels} wheels`);
  }
}

// The FACTORY — one function to create any vehicle
class VehicleFactory {
  static create(type, model, price) {
    switch (type.toLowerCase()) {
      case "car":   return new Car(model, price);
      case "bike":  return new Bike(model, price);
      case "truck": return new Truck(model, price);
      default: throw new Error(`Unknown vehicle type: ${type}`);
    }
  }
}

// Client code doesn't care about Car/Bike/Truck constructors!
const vehicles = [
  VehicleFactory.create("car",   "Toyota Camry",  1500000),
  VehicleFactory.create("bike",  "Royal Enfield",  200000),
  VehicleFactory.create("truck", "Tata Ace",        600000),
];

vehicles.forEach(v => v.describe());

// Real-life: Notification Factory
class EmailNotification {
  send(to, message) { console.log(`  📧 Email to ${to}: ${message}`); }
}
class SMSNotification {
  send(to, message) { console.log(`  📱 SMS to ${to}: ${message}`); }
}
class PushNotification {
  send(to, message) { console.log(`  🔔 Push to ${to}: ${message}`); }
}

class NotificationFactory {
  static create(type) {
    const types = { email: EmailNotification, sms: SMSNotification, push: PushNotification };
    const NotifClass = types[type.toLowerCase()];
    if (!NotifClass) throw new Error(`Unknown notification type: ${type}`);
    return new NotifClass();
  }
}

console.log("\n📨 Notification Factory:");
const notif1 = NotificationFactory.create("email");
const notif2 = NotificationFactory.create("sms");
const notif3 = NotificationFactory.create("push");

notif1.send("abhishek@gmail.com", "Your order is confirmed!");
notif2.send("+91 9876543210",     "OTP: 4521");
notif3.send("user-device-id",    "New message received!");

// ─────────────────────────────────────────────────────────────
// 3️⃣  BUILDER PATTERN
// 📖 Story: Building a CUSTOM BURGER 🍔
//           You add ingredients step by step.
//           The BUILDER handles construction, YOU control steps.
//
// WHY: Build complex objects step-by-step.
//      Avoids constructors with 10+ parameters!
// USE: SQL query builders, form builders, config builders
// ─────────────────────────────────────────────────────────────

console.log("\n\n3️⃣  BUILDER PATTERN\n");

class QueryBuilder {
  #query = { table: "", conditions: [], fields: ["*"], limit: null, orderBy: null };

  from(table) {
    this.#query.table = table;
    return this; // ← return `this` for CHAINING!
  }

  select(...fields) {
    this.#query.fields = fields;
    return this;
  }

  where(condition) {
    this.#query.conditions.push(condition);
    return this;
  }

  orderBy(field, direction = "ASC") {
    this.#query.orderBy = `${field} ${direction}`;
    return this;
  }

  limit(n) {
    this.#query.limit = n;
    return this;
  }

  build() {
    const { table, fields, conditions, orderBy, limit } = this.#query;
    if (!table) throw new Error("Table is required!");

    let query = `SELECT ${fields.join(", ")} FROM ${table}`;
    if (conditions.length) query += ` WHERE ${conditions.join(" AND ")}`;
    if (orderBy)           query += ` ORDER BY ${orderBy}`;
    if (limit)             query += ` LIMIT ${limit}`;

    return query + ";";
  }
}

// ❌ Without builder — impossible to read:
// executeQuery("users", ["name","email"], ["age > 18", "city='Mumbai'"], "name ASC", 10);

// ✅ With builder — reads like plain English!
const query1 = new QueryBuilder()
  .from("users")
  .select("name", "email", "age")
  .where("age > 18")
  .where("city = 'Mumbai'")
  .orderBy("name")
  .limit(10)
  .build();

const query2 = new QueryBuilder()
  .from("products")
  .where("price < 5000")
  .where("inStock = true")
  .orderBy("price", "DESC")
  .limit(5)
  .build();

console.log("Query 1:", query1);
console.log("Query 2:", query2);

// ══════════════════════════════════════════════════════════════
// 🏛️  STRUCTURAL PATTERNS
// ══════════════════════════════════════════════════════════════

// ─────────────────────────────────────────────────────────────
// 4️⃣  MODULE PATTERN
// 📖 Story: A TOOLBOX 🧰
//           You only EXPOSE the tools others need.
//           Internal wrenches and screws stay PRIVATE inside.
//
// WHY: Encapsulate private data, expose only a clean API.
// USE: Libraries, utility modules, feature modules
// ─────────────────────────────────────────────────────────────

console.log("\n\n4️⃣  MODULE PATTERN\n");

const ShoppingCart = (() => {
  // 🔒 PRIVATE — not accessible from outside!
  let items   = [];
  let discount = 0;

  function calcSubtotal() {
    return items.reduce((sum, item) => sum + item.price * item.qty, 0);
  }

  // ✅ PUBLIC — returned and accessible!
  return {
    addItem(name, price, qty = 1) {
      const existing = items.find(i => i.name === name);
      if (existing) {
        existing.qty += qty;
      } else {
        items.push({ name, price, qty });
      }
      console.log(`  ➕ Added: ${name} x${qty} @ ₹${price}`);
      return this;
    },

    removeItem(name) {
      items = items.filter(i => i.name !== name);
      console.log(`  ➖ Removed: ${name}`);
      return this;
    },

    applyDiscount(percent) {
      discount = percent;
      console.log(`  🏷️  Discount applied: ${percent}%`);
      return this;
    },

    checkout() {
      const subtotal = calcSubtotal();
      const savings  = (subtotal * discount) / 100;
      const total    = subtotal - savings;
      console.log(`\n  🧾 --- Receipt ---`);
      items.forEach(i =>
        console.log(`    ${i.name.padEnd(12)} x${i.qty}  ₹${i.price * i.qty}`)
      );
      console.log(`  Subtotal: ₹${subtotal}`);
      if (discount) console.log(`  Discount: -₹${savings} (${discount}% off)`);
      console.log(`  TOTAL:    ₹${total}`);
      return total;
    },

    getItemCount() { return items.reduce((sum, i) => sum + i.qty, 0); }
  };
})();

// Method chaining with module pattern!
ShoppingCart
  .addItem("Phone",   15000, 1)
  .addItem("Earbuds", 2000,  2)
  .addItem("Case",    500,   1)
  .applyDiscount(10)
  .checkout();

console.log(`\n  Total items: ${ShoppingCart.getItemCount()}`);
// console.log(ShoppingCart.items);    // ❌ undefined — PRIVATE!
// console.log(ShoppingCart.discount); // ❌ undefined — PRIVATE!

// ─────────────────────────────────────────────────────────────
// 5️⃣  DECORATOR PATTERN
// 📖 Story: CUSTOMIZING A COFFEE ☕
//           Start with basic espresso.
//           Add milk → Latte. Add chocolate → Mocha.
//           Each addition WRAPS the original and ADDS behavior!
//
// WHY: Add new behavior to objects WITHOUT modifying original.
//      Open/Closed Principle — open for extension, closed for modification.
// USE: Logging wrappers, auth wrappers, caching wrappers
// ─────────────────────────────────────────────────────────────

console.log("\n\n5️⃣  DECORATOR PATTERN\n");

// Base coffee class
class Coffee {
  cost()        { return 50; }
  description() { return "Espresso"; }
}

// Decorators — each wraps the original and ADDS to it
class MilkDecorator {
  constructor(coffee) { this.coffee = coffee; }
  cost()        { return this.coffee.cost() + 20; }
  description() { return this.coffee.description() + " + Milk"; }
}

class ChocolateDecorator {
  constructor(coffee) { this.coffee = coffee; }
  cost()        { return this.coffee.cost() + 30; }
  description() { return this.coffee.description() + " + Chocolate"; }
}

class WhipDecorator {
  constructor(coffee) { this.coffee = coffee; }
  cost()        { return this.coffee.cost() + 15; }
  description() { return this.coffee.description() + " + Whip"; }
}

// Build any combination at runtime!
let myCoffee = new Coffee();
console.log(`  ${myCoffee.description()} → ₹${myCoffee.cost()}`);

myCoffee = new MilkDecorator(myCoffee);
console.log(`  ${myCoffee.description()} → ₹${myCoffee.cost()}`);

myCoffee = new ChocolateDecorator(myCoffee);
console.log(`  ${myCoffee.description()} → ₹${myCoffee.cost()}`);

myCoffee = new WhipDecorator(myCoffee);
console.log(`  ${myCoffee.description()} → ₹${myCoffee.cost()}`);

// Real-life: Function decorator for logging & timing
function withLogging(fn, fnName) {
  return function (...args) {
    console.log(`\n  📋 [LOG] Calling ${fnName}(${args.join(", ")})`);
    const start  = Date.now();
    const result = fn.apply(this, args);
    const time   = Date.now() - start;
    console.log(`  ✅ [LOG] ${fnName} returned: ${result} (took ${time}ms)`);
    return result;
  };
}

function withErrorHandling(fn, fnName) {
  return function (...args) {
    try {
      return fn.apply(this, args);
    } catch (err) {
      console.log(`  ❌ [ERROR] ${fnName} failed: ${err.message}`);
    }
  };
}

function divide(a, b) {
  if (b === 0) throw new Error("Division by zero!");
  return a / b;
}

const safeDivide = withErrorHandling(withLogging(divide, "divide"), "divide");
safeDivide(10, 2);
safeDivide(10, 0);

// ─────────────────────────────────────────────────────────────
// 6️⃣  FACADE PATTERN
// 📖 Story: A SMART HOME APP 🏠📱
//           You press ONE button: "Good Night"
//           Behind the scenes: lights off, AC to 22°C,
//           alarm set, TV off, doors locked.
//           The app is the FACADE — simple interface hiding complexity!
//
// WHY: Simplify a complex system with a clean simple interface.
// USE: Library wrappers, API clients, complex initialization
// ─────────────────────────────────────────────────────────────

console.log("\n\n6️⃣  FACADE PATTERN\n");

// Complex subsystems (normally very complicated):
class LightSystem {
  turnOff() { console.log("  💡 Lights turned off"); }
  turnOn()  { console.log("  💡 Lights turned on"); }
  dim(level){ console.log(`  💡 Lights dimmed to ${level}%`); }
}

class ACSystem {
  setTemperature(temp) { console.log(`  ❄️  AC set to ${temp}°C`); }
  turnOff()            { console.log("  ❄️  AC turned off"); }
}

class SecuritySystem {
  armAlarm()  { console.log("  🔒 Alarm armed"); }
  disarm()    { console.log("  🔓 Alarm disarmed"); }
  lockDoors() { console.log("  🚪 All doors locked"); }
}

class TVSystem {
  turnOff() { console.log("  📺 TV turned off"); }
  turnOn()  { console.log("  📺 TV turned on"); }
}

// THE FACADE — simple interface for the whole smart home
class SmartHomeFacade {
  constructor() {
    this.lights   = new LightSystem();
    this.ac       = new ACSystem();
    this.security = new SecuritySystem();
    this.tv       = new TVSystem();
  }

  goodNightMode() {
    console.log("  🌙 Activating Good Night Mode...");
    this.lights.turnOff();
    this.ac.setTemperature(22);
    this.security.armAlarm();
    this.security.lockDoors();
    this.tv.turnOff();
    console.log("  😴 Good night!");
  }

  morningMode() {
    console.log("  ☀️  Activating Morning Mode...");
    this.lights.turnOn();
    this.lights.dim(70);
    this.ac.setTemperature(24);
    this.security.disarm();
    this.tv.turnOn();
    console.log("  🌅 Good morning!");
  }

  movieMode() {
    console.log("  🎬 Activating Movie Mode...");
    this.lights.dim(20);
    this.ac.setTemperature(23);
    this.tv.turnOn();
    console.log("  🍿 Enjoy the movie!");
  }
}

const myHome = new SmartHomeFacade();
myHome.goodNightMode();
console.log("");
myHome.morningMode();

// ══════════════════════════════════════════════════════════════
// 🎭 BEHAVIORAL PATTERNS
// ══════════════════════════════════════════════════════════════

// ─────────────────────────────────────────────────────────────
// 7️⃣  OBSERVER PATTERN (Publisher / Subscriber)
// 📖 Story: A YOUTUBE CHANNEL 📺
//           Subscribers get notified when a new video drops.
//           Channel (Subject) doesn't know WHO subscribes — just notifies all!
//
// WHY: One-to-many dependency. When one changes, many get notified.
//      Decouples sender from receivers completely.
// USE: Event systems, Redux/state management, real-time updates,
//      DOM events, Node.js EventEmitter
// ─────────────────────────────────────────────────────────────

console.log("\n\n7️⃣  OBSERVER PATTERN\n");

class EventEmitter {
  #events = {};

  on(event, listener) {
    if (!this.#events[event]) this.#events[event] = [];
    this.#events[event].push(listener);
    return this; // chainable
  }

  off(event, listener) {
    if (!this.#events[event]) return;
    this.#events[event] = this.#events[event].filter(l => l !== listener);
    return this;
  }

  emit(event, ...args) {
    (this.#events[event] || []).forEach(listener => listener(...args));
    return this;
  }

  once(event, listener) {
    const wrapper = (...args) => {
      listener(...args);
      this.off(event, wrapper); // auto-remove after first call
    };
    this.on(event, wrapper);
    return this;
  }
}

// Real-life: Order Management System
class OrderSystem extends EventEmitter {
  #orders = [];

  placeOrder(item, price, customer) {
    const order = {
      id:       `ORD-${Date.now()}`,
      item,
      price,
      customer,
      status:   "placed",
      time:     new Date().toLocaleTimeString(),
    };
    this.#orders.push(order);
    this.emit("orderPlaced", order);   // 🔔 notify all listeners!
    return order;
  }

  shipOrder(orderId) {
    const order = this.#orders.find(o => o.id === orderId);
    if (order) {
      order.status = "shipped";
      this.emit("orderShipped", order); // 🔔 notify!
    }
  }
}

const orderSystem = new OrderSystem();

// Multiple independent listeners — all get notified!
orderSystem
  .on("orderPlaced", (order) => {
    console.log(`  📧 Email to ${order.customer}: Order ${order.id} confirmed!`);
  })
  .on("orderPlaced", (order) => {
    console.log(`  📊 Analytics: New order for ${order.item} @ ₹${order.price}`);
  })
  .on("orderPlaced", (order) => {
    console.log(`  📦 Warehouse: Prepare ${order.item} for shipping`);
  })
  .on("orderShipped", (order) => {
    console.log(`  📱 SMS to ${order.customer}: Your ${order.item} has shipped!`);
  });

// One event → notifies all 3 listeners!
const newOrder = orderSystem.placeOrder("Laptop", 55000, "Abhishek");
console.log("");
orderSystem.shipOrder(newOrder.id);

// ─────────────────────────────────────────────────────────────
// 8️⃣  STRATEGY PATTERN
// 📖 Story: A NAVIGATION APP 🗺️ (like Google Maps)
//           You choose your STRATEGY: by car, by bike, by walking.
//           The app uses DIFFERENT algorithms for each.
//           You can SWAP the strategy at any time!
//
// WHY: Define a family of algorithms, make them interchangeable.
//      Eliminates huge if/else or switch chains.
// USE: Payment methods, sorting algorithms, compression, auth strategies
// ─────────────────────────────────────────────────────────────

console.log("\n\n8️⃣  STRATEGY PATTERN\n");

// Strategies — each implements the same "interface" (process method)
const paymentStrategies = {
  upi: {
    name: "UPI",
    process(amount, details) {
      console.log(`  📱 Processing ₹${amount} via UPI (${details.upiId})`);
      return { success: true, transactionId: "UPI" + Date.now() };
    },
  },
  card: {
    name: "Credit/Debit Card",
    process(amount, details) {
      const maskedCard = "*".repeat(12) + details.cardNumber.slice(-4);
      console.log(`  💳 Processing ₹${amount} via Card (${maskedCard})`);
      return { success: true, transactionId: "CARD" + Date.now() };
    },
  },
  wallet: {
    name: "Digital Wallet",
    process(amount, details) {
      console.log(`  👛 Processing ₹${amount} from ${details.walletName} wallet`);
      return { success: true, transactionId: "WLLT" + Date.now() };
    },
  },
  cod: {
    name: "Cash on Delivery",
    process(amount) {
      console.log(`  💵 COD: ₹${amount} to be collected on delivery`);
      return { success: true, transactionId: "COD" + Date.now() };
    },
  },
};

// Context — uses whichever strategy is set
class Checkout {
  #strategy = null;

  setStrategy(strategyName) {
    const strategy = paymentStrategies[strategyName];
    if (!strategy) throw new Error(`Unknown payment strategy: ${strategyName}`);
    this.#strategy = strategy;
    console.log(`  💰 Payment method set to: ${strategy.name}`);
    return this;
  }

  pay(amount, details = {}) {
    if (!this.#strategy) throw new Error("No payment strategy selected!");
    const result = this.#strategy.process(amount, details);
    if (result.success)
      console.log(`  ✅ Payment successful! Txn ID: ${result.transactionId}`);
    return result;
  }
}

const checkout = new Checkout();

checkout.setStrategy("upi").pay(1500, { upiId: "abhishek@paytm" });
console.log("");
checkout.setStrategy("card").pay(5000, { cardNumber: "1234567890123456" });
console.log("");
checkout.setStrategy("cod").pay(800);

// Strategy also eliminates if/else sorting:
const sortStrategies = {
  bubble: (arr) => {
    const a = [...arr];
    for (let i = 0; i < a.length; i++)
      for (let j = 0; j < a.length - i - 1; j++)
        if (a[j] > a[j+1]) [a[j], a[j+1]] = [a[j+1], a[j]];
    return a;
  },
  quick: (arr) => {
    if (arr.length <= 1) return arr;
    const pivot = arr[Math.floor(arr.length / 2)];
    const left  = arr.filter(x => x < pivot);
    const mid   = arr.filter(x => x === pivot);
    const right = arr.filter(x => x > pivot);
    return [...sortStrategies.quick(left), ...mid, ...sortStrategies.quick(right)];
  },
  builtin: (arr) => [...arr].sort((a, b) => a - b),
};

const nums = [64, 34, 25, 12, 22, 11, 90];
console.log("\n  📊 Sorting strategies:");
console.log("  Bubble: ", sortStrategies.bubble(nums));
console.log("  Quick:  ", sortStrategies.quick(nums));
console.log("  Built-in:", sortStrategies.builtin(nums));

// ─────────────────────────────────────────────────────────────
// 9️⃣  COMMAND PATTERN
// 📖 Story: A TEXT EDITOR with UNDO/REDO ↩️↪️
//           Every action (type, delete, format) is a COMMAND object.
//           Undo = run the reverse command. Redo = run it again!
//
// WHY: Encapsulate actions as objects. Enables undo/redo, queuing, logging.
// USE: Text editors, game actions, transaction systems, task queues
// ─────────────────────────────────────────────────────────────

console.log("\n\n9️⃣  COMMAND PATTERN (Undo/Redo)\n");

class TextEditor {
  #content   = "";
  #undoStack = [];
  #redoStack = [];

  execute(command) {
    command.execute(this);
    this.#undoStack.push(command);
    this.#redoStack = []; // clear redo stack on new action
    console.log(`  📄 Content: "${this.#content}"`);
  }

  undo() {
    if (!this.#undoStack.length) return console.log("  ⚠️  Nothing to undo!");
    const command = this.#undoStack.pop();
    command.undo(this);
    this.#redoStack.push(command);
    console.log(`  ↩️  After undo: "${this.#content}"`);
  }

  redo() {
    if (!this.#redoStack.length) return console.log("  ⚠️  Nothing to redo!");
    const command = this.#redoStack.pop();
    command.execute(this);
    this.#undoStack.push(command);
    console.log(`  ↪️  After redo: "${this.#content}"`);
  }

  getContent()       { return this.#content; }
  setContent(text)   { this.#content = text; }
}

// Commands — each knows how to DO and UNDO itself
class TypeCommand {
  constructor(text) { this.text = text; }
  execute(editor) { editor.setContent(editor.getContent() + this.text); }
  undo(editor)    { editor.setContent(editor.getContent().slice(0, -this.text.length)); }
}

class DeleteCommand {
  constructor(chars) { this.chars = chars; this.deleted = ""; }
  execute(editor) {
    this.deleted = editor.getContent().slice(-this.chars);
    editor.setContent(editor.getContent().slice(0, -this.chars));
  }
  undo(editor) { editor.setContent(editor.getContent() + this.deleted); }
}

class ReplaceCommand {
  constructor(find, replace) { this.find = find; this.replace = replace; this.original = ""; }
  execute(editor) {
    this.original = editor.getContent();
    editor.setContent(editor.getContent().replace(this.find, this.replace));
  }
  undo(editor) { editor.setContent(this.original); }
}

const editor = new TextEditor();

console.log("  Typing...");
editor.execute(new TypeCommand("Hello"));
editor.execute(new TypeCommand(", World"));
editor.execute(new TypeCommand("!"));

console.log("\n  Replacing 'World' with 'Abhishek'...");
editor.execute(new ReplaceCommand("World", "Abhishek"));

console.log("\n  Deleting 1 character...");
editor.execute(new DeleteCommand(1));

console.log("\n  Undoing 3 times...");
editor.undo();
editor.undo();
editor.undo();

console.log("\n  Redoing...");
editor.redo();

// ─────────────────────────────────────────────────────────────
// 🔟  PROXY PATTERN
// 📖 Story: A SECURITY GUARD 🛡️ at a building entrance.
//           Everyone must go THROUGH the guard.
//           Guard can validate, log, block, or cache requests!
//
// WHY: Control access to an object. Add logic before/after operations.
// USE: Validation, caching, logging, access control, lazy loading
// ─────────────────────────────────────────────────────────────

console.log("\n\n🔟 PROXY PATTERN\n");

// Using JS built-in Proxy object!
function createValidatedUser(data) {
  const validators = {
    name:  (v) => typeof v === "string" && v.length >= 2,
    age:   (v) => Number.isInteger(v)   && v >= 0 && v <= 150,
    email: (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v),
  };

  return new Proxy(data, {
    set(target, prop, value) {
      if (validators[prop] && !validators[prop](value)) {
        throw new Error(`❌ Invalid value for ${prop}: "${value}"`);
      }
      console.log(`  ✅ Setting ${prop} = "${value}"`);
      target[prop] = value;
      return true;
    },
    get(target, prop) {
      console.log(`  🔍 Getting ${prop}`);
      return target[prop];
    },
  });
}

const userData = createValidatedUser({ name: "Abhishek", age: 25 });
userData.name  = "Priya";    // ✅ valid
userData.age   = 30;          // ✅ valid
userData.email = "priya@gmail.com"; // ✅ valid

try {
  userData.age = -5;           // ❌ throws!
} catch (e) {
  console.log("  " + e.message);
}

try {
  userData.email = "notanemail"; // ❌ throws!
} catch (e) {
  console.log("  " + e.message);
}

// Proxy for API caching:
function createCachedAPI(api) {
  const cache = {};
  return new Proxy(api, {
    get(target, method) {
      return async function (endpoint) {
        if (cache[endpoint]) {
          console.log(`  ⚡ Cache HIT for: ${endpoint}`);
          return cache[endpoint];
        }
        console.log(`  🌐 Cache MISS — fetching: ${endpoint}`);
        const result = await target[method](endpoint);
        cache[endpoint] = result;
        return result;
      };
    },
  });
}

// ──────────────────────────────────────────
// 📊 DESIGN PATTERNS SUMMARY
// ──────────────────────────────────────────

console.log(`
╔══════════════════════════════════════════════════════════════╗
║                DESIGN PATTERNS SUMMARY                       ║
╠══════════╦═══════════╦══════════════════════════════════════╣
║ Category ║ Pattern   ║ Use When...                          ║
╠══════════╬═══════════╬══════════════════════════════════════╣
║          ║ Singleton ║ Need exactly ONE global instance     ║
║CREATIONAL║ Factory   ║ Create objects without knowing type  ║
║          ║ Builder   ║ Build complex objects step by step   ║
╠══════════╬═══════════╬══════════════════════════════════════╣
║          ║ Module    ║ Encapsulate private state + API      ║
║STRUCTURAL║ Decorator ║ Add behavior without modifying class ║
║          ║ Facade    ║ Simplify complex subsystem           ║
║          ║ Proxy     ║ Control access / add cross-cutting   ║
╠══════════╬═══════════╬══════════════════════════════════════╣
║          ║ Observer  ║ Notify many when one thing changes   ║
║BEHAVIORAL║ Strategy  ║ Swap algorithms/behavior at runtime  ║
║          ║ Command   ║ Encapsulate actions (undo/redo/queue)║
╚══════════╩═══════════╩══════════════════════════════════════╝
`);

// ============================================================
// 🧪 YOUR CODING CHALLENGES - TRY THESE!
// ============================================================

// 🟡 CHALLENGE 1 (Easy — Singleton):
// Build a `Logger` Singleton with:
//   - log(message, level)  → stores log with timestamp
//   - getLogs(level?)      → returns all logs (or filtered by level)
//   - clear()              → clears all logs
// Verify: create Logger in 3 different places → all same instance.
// Prove it by adding a log in one place and reading it in another.

// 🟠 CHALLENGE 2 (Medium — Observer):
// Build a `StockMarket` using Observer pattern:
// - Companies can list their stock (subjects)
// - Investors can subscribe to specific company stocks (observers)
// - When price changes → only subscribed investors get notified
// - Investors can subscribe/unsubscribe at any time
// Test: 3 investors, 2 companies, mixed subscriptions, price changes.

// 🔴 CHALLENGE 3 (Hard — Combine patterns):
// Build a mini "Task Management System" combining:
// → FACTORY to create different task types (Bug, Feature, Story)
// → OBSERVER to notify team members on task status change
// → COMMAND for undo/redo of task assignments
// → SINGLETON for the TaskRegistry (one global task store)
// → FACADE for a simple API: taskManager.assign(), taskManager.complete(), taskManager.undo()
