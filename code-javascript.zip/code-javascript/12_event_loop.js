// ============================================================
// 🎬 CHAPTER 12: THE EVENT LOOP
// 📖 Story: A RESTAURANT with ONE WAITER 🍽️
//           The waiter (JS) can only do ONE thing at a time.
//           But the kitchen (Web APIs) works in the background!
//           The event loop is the MANAGER deciding what the
//           waiter does next!
// ============================================================

// ╔══════════════════════════════════════════════════════════╗
// ║  ❓ WHY DO WE NEED TO UNDERSTAND THE EVENT LOOP?        ║
// ╠══════════════════════════════════════════════════════════╣
// ║                                                          ║
// ║  🔴 THE PROBLEM (without knowing this):                 ║
// ║  You write async code and the OUTPUT ORDER surprises    ║
// ║  you every time. You can't predict or explain WHY       ║
// ║  certain things run before or after others.             ║
// ║                                                          ║
// ║  // Can you predict the output? Most people can't!      ║
// ║  console.log("1");                                      ║
// ║  setTimeout(() => console.log("2"), 0);                 ║
// ║  Promise.resolve().then(() => console.log("3"));        ║
// ║  console.log("4");                                      ║
// ║  // Answer: 1, 4, 3, 2  ← NOT 1, 2, 3, 4 !            ║
// ║  // If you don't know WHY → you'll fail interviews!     ║
// ║                                                          ║
// ║  🎯 WHAT UNDERSTANDING EVENT LOOP UNLOCKS:              ║
// ║  → Predict async code output (asked in every interview) ║
// ║  → Avoid UI freezing / blocking the main thread         ║
// ║  → Understand WHY Promises run before setTimeout        ║
// ║  → Debug weird timing bugs in your code                 ║
// ║  → Understand Node.js performance deeply                ║
// ╚══════════════════════════════════════════════════════════╝

// ──────────────────────────────────────────
// 🏗️  HOW JS WORKS UNDER THE HOOD
// ──────────────────────────────────────────

/*
  JavaScript Engine has:

  ┌─────────────────────────────────────────────────┐
  │              JAVASCRIPT ENGINE                   │
  │                                                  │
  │  ┌──────────────┐    ┌─────────────────────┐    │
  │  │  CALL STACK  │    │      HEAP           │    │
  │  │  (executes   │    │   (memory storage   │    │
  │  │   your code) │    │    for objects)     │    │
  │  └──────────────┘    └─────────────────────┘    │
  └─────────────────────────────────────────────────┘

  Outside the engine (Browser / Node.js provides):

  ┌─────────────────┐    ┌─────────────────────┐
  │    WEB APIs     │    │   MICROTASK QUEUE   │
  │  (setTimeout,   │    │  (Promise.then,     │
  │   fetch,        │    │   queueMicrotask,   │
  │   DOM events)   │    │   MutationObserver) │
  └─────────────────┘    └─────────────────────┘
                         ┌─────────────────────┐
                         │   MACROTASK QUEUE   │
                         │  (setTimeout,       │
                         │   setInterval,      │
                         │   I/O callbacks)    │
                         └─────────────────────┘

  THE EVENT LOOP watches:
  → If Call Stack is EMPTY:
      First: Run ALL microtasks (Promise.then)
      Then:  Run ONE macrotask (setTimeout)
      Repeat forever!
*/

// ──────────────────────────────────────────
// 🔰 CALL STACK — Understading execution order
// ──────────────────────────────────────────

console.log("=== CALL STACK DEMO ===\n");

function greet(name) {
  const message = buildMessage(name); // pushes buildMessage to stack
  console.log(message);               // then pops it
}

function buildMessage(name) {
  return `Hello, ${name}!`; // pushed onto stack, then popped
}

// Call Stack at moment of greet("Abhishek"):
// [ greet ] → [ greet, buildMessage ] → [ greet ] → [ ]
greet("Abhishek");

// ──────────────────────────────────────────
// ⏰ MACROTASK QUEUE — setTimeout, setInterval
// These wait for the Call Stack to be EMPTY, then run
// ──────────────────────────────────────────

console.log("\n=== MACROTASK (setTimeout) DEMO ===\n");

console.log("1️⃣  Start");                           // runs immediately (Call Stack)

setTimeout(function () {
  console.log("3️⃣  setTimeout 0ms");                // runs LAST (Macrotask Queue)
}, 0);

console.log("2️⃣  End");                             // runs immediately (Call Stack)

// OUTPUT: 1, 2, 3  ← NOT 1, 3, 2 even though setTimeout is 0ms!
// Why? setTimeout is sent to Web API → Macrotask Queue
// The main code finishes FIRST, then event loop picks up setTimeout.

// ──────────────────────────────────────────
// ⚡ MICROTASK QUEUE — Promises, queueMicrotask
// ALWAYS runs BEFORE macrotasks, AFTER current code
// ──────────────────────────────────────────

console.log("\n=== MICROTASK (Promise) DEMO ===\n");

console.log("🔵 1 - Sync start");

setTimeout(() => console.log("🔴 4 - setTimeout (macrotask)"), 0);

Promise.resolve()
  .then(() => console.log("🟢 3 - Promise.then (microtask)"))
  .then(() => console.log("🟢 3b - Chained .then (also microtask)"));

console.log("🔵 2 - Sync end");

// OUTPUT ORDER: 1, 2, 3, 3b, 4
// Rule: Sync → Microtasks (ALL of them) → ONE Macrotask → Microtasks → ...

// ──────────────────────────────────────────
// 🎯 THE GOLDEN RULE — Priority Order
// ──────────────────────────────────────────

console.log("\n=== PRIORITY ORDER DEMO ===\n");

// 🏆 PRIORITY:
// 1st: Synchronous code (Call Stack)
// 2nd: Microtasks (Promise.then, queueMicrotask)
// 3rd: Macrotasks (setTimeout, setInterval, I/O)

console.log("Step 1: Sync");

setTimeout(() => console.log("Step 5: setTimeout 0ms"),   0);
setTimeout(() => console.log("Step 6: setTimeout 100ms"), 100);

Promise.resolve().then(() => {
  console.log("Step 3: Promise 1");
  // Adding a microtask INSIDE a microtask:
  Promise.resolve().then(() => console.log("Step 4: Nested Promise"));
});

queueMicrotask(() => console.log("Step 3b: queueMicrotask"));

console.log("Step 2: Sync end");

// Expected output: 1, 2, 3, 3b, 4, 5, 6

// ──────────────────────────────────────────
// 🔥 CLASSIC INTERVIEW QUESTIONS
// ──────────────────────────────────────────

console.log("\n\n=== INTERVIEW QUESTION 1 ===");
// Q: What is the output?

for (var i = 0; i < 3; i++) {
  setTimeout(() => console.log("var i:", i), 0);
}
// Answer: 3, 3, 3 (NOT 0, 1, 2)
// Why? var is function-scoped. By the time setTimeout runs,
// the loop is DONE and i = 3. All 3 callbacks share same `i`.

console.log("\n=== INTERVIEW QUESTION 2 ===");
// Q: What is the output?

for (let j = 0; j < 3; j++) {
  setTimeout(() => console.log("let j:", j), 0);
}
// Answer: 0, 1, 2 ✅
// Why? let is block-scoped. Each iteration gets its OWN `j`.

console.log("\n=== INTERVIEW QUESTION 3 ===");
// Q: What is the output?

async function fetchData() {
  console.log("A - async fn start");
  const result = await Promise.resolve("data!");
  console.log("C - after await:", result); // runs after B!
}

console.log("X - before calling fetchData");
fetchData();
console.log("B - after calling fetchData");

// Output: X, A, B, C
// await splits the async function — code AFTER await
// goes to microtask queue! The rest of the sync code (B) runs first.

// ──────────────────────────────────────────
// 🚫 BLOCKING THE EVENT LOOP (Bad practice!)
// Story: The waiter gets stuck doing one huge task — restaurant stops!
// ──────────────────────────────────────────

console.log("\n\n=== BLOCKING THE EVENT LOOP ===\n");

// ❌ BAD — This FREEZES everything for ~1 second!
function blockingOperation() {
  console.log("⏳ Starting heavy sync operation...");
  const start = Date.now();
  while (Date.now() - start < 100) {
    // Busy-waiting — NOTHING ELSE CAN RUN during this!
    // In a browser: UI freezes, clicks don't work
    // In Node.js: no other requests can be handled
  }
  console.log("✅ Heavy sync operation done!");
}

// ✅ GOOD — Break heavy work into chunks using setTimeout
function nonBlockingOperation(items, index = 0) {
  if (index >= items.length) {
    console.log("✅ All items processed (non-blocking)!");
    return;
  }
  // Process one item
  console.log(`  Processing item ${index + 1}: ${items[index]}`);

  // Schedule the rest — gives event loop a chance to breathe!
  setTimeout(() => nonBlockingOperation(items, index + 1), 0);
}

blockingOperation(); // still short enough to demo
nonBlockingOperation(["Task A", "Task B", "Task C"]);

// ──────────────────────────────────────────
// 🔄 setInterval — Repeated Macrotasks
// ──────────────────────────────────────────

console.log("\n\n=== setInterval DEMO ===\n");

let count = 0;
const timer = setInterval(function () {
  count++;
  console.log(`⏱️  Tick #${count}`);
  if (count === 3) {
    clearInterval(timer); // STOP the interval
    console.log("⏹️  Timer stopped!");
  }
}, 200);

// ──────────────────────────────────────────
// 🌐 REAL LIFE: How a web server handles requests (Node.js)
// This is WHY Node.js is fast despite being single-threaded!
// ──────────────────────────────────────────

console.log("\n\n=== NODE.JS SINGLE THREAD MAGIC ===\n");

function simulateDBQuery(queryName, delay) {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(`📊 ${queryName} result ready`);
    }, delay);
  });
}

async function handleRequest(requestId) {
  console.log(`📨 Request ${requestId} received`);

  // These DB queries happen in background (Web API / libuv)
  // Node.js is FREE to handle other requests while waiting!
  const result = await simulateDBQuery(`Query for req ${requestId}`, 300);
  console.log(`📤 Request ${requestId} responded: ${result}`);
}

// Simulate 3 requests coming in at same time
// Node.js handles ALL of them concurrently (not parallel!)
handleRequest(1);
handleRequest(2);
handleRequest(3);
// All 3 start immediately. Results come in order of completion.

// ──────────────────────────────────────────
// 📊 SUMMARY TABLE
// ──────────────────────────────────────────

console.log(`
┌─────────────────────────────────────────────────────────┐
│                 EVENT LOOP SUMMARY                       │
├──────────────────┬──────────────────────────────────────┤
│  Sync Code       │  Runs immediately, blocks everything  │
├──────────────────┼──────────────────────────────────────┤
│  Microtask Queue │  Promise.then, queueMicrotask         │
│  (HIGH priority) │  Runs BEFORE any macrotask            │
│                  │  ALL microtasks drain before next step│
├──────────────────┼──────────────────────────────────────┤
│  Macrotask Queue │  setTimeout, setInterval, I/O         │
│  (LOW priority)  │  ONE task per event loop tick         │
│                  │  Runs AFTER all microtasks            │
└──────────────────┴──────────────────────────────────────┘

  ORDER: Sync → Microtasks (all) → Macrotask (one) → repeat
`);

// ============================================================
// 🧪 YOUR CODING CHALLENGES - TRY THESE!
// ============================================================

// 🟡 CHALLENGE 1 (Easy — predict the output):
// Write down the output ORDER before running:
//
// console.log("A");
// setTimeout(() => console.log("B"), 0);
// Promise.resolve().then(() => console.log("C"));
// setTimeout(() => console.log("D"), 100);
// Promise.resolve().then(() => {
//   console.log("E");
//   Promise.resolve().then(() => console.log("F"));
// });
// console.log("G");
//
// Answer: A, G, C, E, F, B, D — did you get it right?

// 🟠 CHALLENGE 2 (Medium):
// Fix this code so it prints 0, 1, 2 instead of 3, 3, 3:
// for (var i = 0; i < 3; i++) {
//   setTimeout(() => console.log(i), 1000);
// }
// Solve it 3 different ways:
//   a) Using let
//   b) Using IIFE
//   c) Using bind()

// 🔴 CHALLENGE 3 (Hard):
// Build a `TaskScheduler` that:
// - addTask(name, type, delay) → type is "micro" or "macro"
// - micro tasks use: queueMicrotask()
// - macro tasks use: setTimeout(fn, delay)
// - run() → executes all tasks and logs order they complete
// Add 3 micro and 3 macro tasks in mixed order.
// Verify that ALL micro tasks complete before ANY macro task.
