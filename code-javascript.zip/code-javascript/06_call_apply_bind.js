// ============================================================
// 🎬 CHAPTER 6: CALL, APPLY, BIND
// 📖 Story: A chef can cook anywhere — in your kitchen, 
//           restaurant, or hotel. You just BORROW the chef 
//           and tell him WHERE to cook (which `this` to use)!
// ============================================================

// ╔══════════════════════════════════════════════════════════╗
// ║  ❓ WHY DO WE NEED CALL / APPLY / BIND?                  ║
// ╠══════════════════════════════════════════════════════════╣
// ║                                                          ║
// ║  🔴 THE PROBLEM (without them):                          ║
// ║  In JS, `this` is dynamic — it changes depending on      ║
// ║  HOW a function is called, not WHERE it is defined.      ║
// ║  When you borrow a method or pass it as callback,        ║
// ║  `this` becomes undefined or points to the wrong object! ║
// ║                                                          ║
// ║  // ❌ `this` is LOST when method is borrowed            ║
// ║  const user = { name: "Abhishek", greet() {              ║
// ║    console.log("Hello", this.name);                      ║
// ║  }};                                                     ║
// ║  const fn = user.greet;                                  ║
// ║  fn(); // ❌ "Hello undefined" — this is lost!           ║
// ║                                                          ║
// ║  // ❌ `this` lost in setTimeout                         ║
// ║  setTimeout(user.greet, 1000); // ❌ undefined again!    ║
// ║                                                          ║
// ║  Without call/apply/bind you CANNOT:                     ║
// ║  → Reuse a method from one object on another object      ║
// ║  → Borrow parent class constructor in inheritance        ║
// ║  → Fix `this` in callbacks and event handlers            ║
// ║  → Do partial application (pre-fill some arguments)      ║
// ║                                                          ║
// ║  ✅ THE SOLUTION:                                        ║
// ║  call()  → call NOW, pass args one by one                ║
// ║  apply() → call NOW, pass args as an array               ║
// ║  bind()  → create a NEW function with fixed `this`       ║
// ║                                                          ║
// ║  🎯 WHAT THEY UNLOCK:                                    ║
// ║  → Method borrowing — reuse logic across objects         ║
// ║  → Inheritance — call parent constructor from child      ║
// ║  → Fix event handler context in classes                  ║
// ║  → Partial application — create specialized functions    ║
// ║  → Math.max/min with dynamic arrays (apply trick)        ║
// ╚══════════════════════════════════════════════════════════╝

// The Problem: "this" loses context when a function is borrowed
// Solution: call(), apply(), bind() let us control "this" manually

// ──────────────────────────────────────────
// 🔰 THE PROBLEM — "this" loses context
// ──────────────────────────────────────────

const restaurant = {
  name: "Spice Garden",
  greet: function () {
    console.log(`Welcome to ${this.name}!`);
  },
};

restaurant.greet(); // ✅ "Welcome to Spice Garden!"

const greetFn = restaurant.greet;
// greetFn(); // ❌ "Welcome to undefined!" — lost context!

// ──────────────────────────────────────────
// 📞 CALL — Borrow a function, pass args ONE BY ONE
// Syntax: fn.call(thisContext, arg1, arg2, ...)
// ──────────────────────────────────────────

console.log("📞 CALL EXAMPLES:\n");

const chef = {
  name: "Ramsey",
  cook: function (dish, cuisine) {
    console.log(`👨‍🍳 ${this.name} is cooking ${dish} (${cuisine} style)`);
  },
};

const homeKitchen = { name: "Home Cook Priya" };
const hotel       = { name: "Taj Hotel Chef" };

chef.cook("Biryani", "Mughlai");                         // chef cooks
chef.cook.call(homeKitchen, "Dal Tadka", "North Indian"); // Priya borrows chef's skill
chef.cook.call(hotel, "Pasta", "Italian");                // Hotel borrows chef's skill

// Real-Life Use: Inheritance (calling parent constructor)
function Person(name, age) {
  this.name = name;
  this.age  = age;
}

function Student(name, age, grade) {
  Person.call(this, name, age); // 🔥 Borrow Person's constructor!
  this.grade = grade;
}

const student1 = new Student("Abhishek", 20, "A");
console.log("\n🎓 Student:", student1);

// ──────────────────────────────────────────
// 📋 APPLY — Same as call, but args as ARRAY
// Syntax: fn.apply(thisContext, [arg1, arg2, ...])
// ──────────────────────────────────────────

console.log("\n\n📋 APPLY EXAMPLES:\n");

chef.cook.apply(homeKitchen, ["Samosa", "Street Food"]);

// 🎯 Best use case: Math.max/min with arrays
const scores = [85, 92, 78, 95, 67, 88];

// Old way with apply:
const highestScore = Math.max.apply(null, scores);
const lowestScore  = Math.min.apply(null, scores);
console.log("Highest score:", highestScore); // 95
console.log("Lowest score:", lowestScore);   // 67

// Modern way (spread operator — we'll learn this soon):
console.log("Max (spread):", Math.max(...scores)); // 95

// apply is useful when args are already in an array
function introduce(greeting, punctuation) {
  console.log(`${greeting}, I'm ${this.name}${punctuation}`);
}

const person = { name: "Abhishek" };
const args = ["Namaste", "! 🙏"]; // args already in array
introduce.apply(person, args);

// ──────────────────────────────────────────
// 🔗 BIND — Returns a NEW function with fixed "this"
// Syntax: const newFn = fn.bind(thisContext, arg1, arg2, ...)
// ──────────────────────────────────────────

console.log("\n\n🔗 BIND EXAMPLES:\n");

// bind does NOT call immediately — it returns a new function!
const cookForPriya = chef.cook.bind(homeKitchen);
cookForPriya("Khichdi", "Simple");  // Call whenever you want!
cookForPriya("Roti", "Traditional");

// PARTIAL APPLICATION with bind (preset some arguments)
function multiply(a, b) {
  return a * b;
}

const double = multiply.bind(null, 2);   // a is fixed to 2
const triple = multiply.bind(null, 3);   // a is fixed to 3

console.log("\n🔢 Double 5:", double(5));  // 10
console.log("🔢 Triple 5:", triple(5));  // 15
console.log("🔢 Double 8:", double(8));  // 16

// Real-Life: Event handlers losing 'this' (common React/DOM problem)
const button = {
  label: "Submit",
  handleClick: function () {
    console.log(`\n🖱️  Button "${this.label}" was clicked!`);
  },
};

// Without bind (setTimeout loses 'this'):
// setTimeout(button.handleClick, 100); // ❌ "Button undefined was clicked"

// With bind (fixes 'this'):
setTimeout(button.handleClick.bind(button), 100); // ✅ "Button Submit was clicked"

// ──────────────────────────────────────────
// 🆚 CALL vs APPLY vs BIND — Summary Table
// ──────────────────────────────────────────

console.log(`
╔═══════════╦══════════════════════════╦═════════════════╗
║  Method   ║  How it's called         ║  Returns        ║
╠═══════════╬══════════════════════════╬═════════════════╣
║  call()   ║  fn.call(ctx, a, b)      ║  Result directly║
║  apply()  ║  fn.apply(ctx, [a, b])   ║  Result directly║
║  bind()   ║  fn.bind(ctx, a, b)      ║  New function   ║
╚═══════════╩══════════════════════════╩═════════════════╝
`);

// ──────────────────────────────────────────
// 🔥 ADVANCED: Implementing our own call, apply, bind
// (Interview Favorite!)
// ──────────────────────────────────────────

// Custom myCall
Function.prototype.myCall = function (context, ...args) {
  context = context || globalThis;
  context._fn = this; // attach function to context temporarily
  const result = context._fn(...args);
  delete context._fn;
  return result;
};

// Custom myBind
Function.prototype.myBind = function (context, ...preArgs) {
  const fn = this;
  return function (...args) {
    return fn.myCall(context, ...preArgs, ...args);
  };
};

function sayHi(city, country) {
  console.log(`\n👋 Hi! I'm ${this.name} from ${city}, ${country}`);
}

sayHi.myCall({ name: "Abhishek" }, "Mumbai", "India");

const boundSayHi = sayHi.myBind({ name: "Priya" }, "Delhi");
boundSayHi("India");

// ============================================================
// 🧪 YOUR CODING CHALLENGES - TRY THESE!
// ============================================================

// 🟡 CHALLENGE 1 (Easy):
// Create two objects: `dog` and `cat`, each with a `name` property.
// Create a function `introduce()` that says: "I am [this.name] and I say [this.sound]"
// Use call() to make both dog and cat introduce themselves.

// 🟠 CHALLENGE 2 (Medium):
// You have a `Calculator` object with methods: add, subtract, multiply.
// Create another object `scientificCalc` WITHOUT those methods.
// Use call() and apply() to borrow Calculator's methods for scientificCalc.
// Example: Calculator.add.call(scientificCalc, 10, 20) → 30

// 🔴 CHALLENGE 3 (Hard):
// Create a `Logger` class with:
//   - prefix property (like "INFO:", "ERROR:", "WARN:")
//   - log(message) method that prints "[prefix] message"
// Use bind() to create specialized loggers:
//   const infoLog  = logger.log.bind({ prefix: "ℹ️  INFO:" });
//   const errorLog = logger.log.bind({ prefix: "❌ ERROR:" });
//   const warnLog  = logger.log.bind({ prefix: "⚠️  WARN:" });
// Then use these throughout your "app" to log messages.
