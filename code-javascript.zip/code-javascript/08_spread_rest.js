// ============================================================
// 🎬 CHAPTER 8: SPREAD & REST OPERATORS (...)
// 📖 Story: 
//   SPREAD  = Opening a gift box and spreading all items out 🎁
//   REST    = Collecting all remaining items into one bag 🎒
// Both use ... but in DIFFERENT contexts!
// ============================================================

// ╔══════════════════════════════════════════════════════════╗
// ║  ❓ WHY DO WE NEED SPREAD & REST?                        ║
// ╠══════════════════════════════════════════════════════════╣
// ║                                                          ║
// ║  🔴 THE PROBLEM (without spread & rest):                 ║
// ║                                                          ║
// ║  WITHOUT REST — functions with variable args are messy:  ║
// ║  // ❌ Old way — ugly `arguments` object                 ║
// ║  function sum() {                                        ║
// ║    let total = 0;                                        ║
// ║    for(let i=0; i<arguments.length; i++)                 ║
// ║      total += arguments[i]; // not a real array! 😤      ║
// ║    return total;                                         ║
// ║  }                                                       ║
// ║  // arguments has no .map(), .filter() etc. Painful!     ║
// ║                                                          ║
// ║  WITHOUT SPREAD — copying/merging arrays & objects       ║
// ║  required verbose workarounds:                           ║
// ║  // ❌ Copying array (old way — reference bug!)          ║
// ║  const copy = original; // SAME reference, not a copy!  ║
// ║  copy.push(99); // also modifies `original`! Bug! 🐛     ║
// ║                                                          ║
// ║  // ❌ Merging objects (old way — verbose)               ║
// ║  const merged = Object.assign({}, obj1, obj2);           ║
// ║                                                          ║
// ║  ✅ THE SOLUTION:                                        ║
// ║  // ✅ REST — clean variable arguments                   ║
// ║  function sum(...nums) { return nums.reduce(..); }       ║
// ║  // nums is a REAL array with all array methods!         ║
// ║                                                          ║
// ║  // ✅ SPREAD — copy arrays/objects safely               ║
// ║  const copy   = [...original];   // true copy!           ║
// ║  const merged = {...obj1, ...obj2}; // clean merge!      ║
// ║                                                          ║
// ║  🎯 WHAT THEY UNLOCK:                                    ║
// ║  → Write functions that accept ANY number of arguments   ║
// ║  → Copy arrays/objects WITHOUT reference bugs            ║
// ║  → Merge arrays and objects in one line                  ║
// ║  → IMMUTABLE state updates (essential for React/Redux)   ║
// ║  → Cleaner destructuring to extract + collect data       ║
// ╚══════════════════════════════════════════════════════════╝

// ──────────────────────────────────────────
// 📦 REST OPERATOR — Collect remaining args into an array
// "Pack everything into one bag"
// Used in FUNCTION PARAMETERS
// ──────────────────────────────────────────

console.log("🎒 REST OPERATOR EXAMPLES:\n");

// Example 1: Sum any number of arguments
function sum(...numbers) {
  // `numbers` is an array of ALL arguments passed!
  return numbers.reduce((total, n) => total + n, 0);
}

console.log(sum(1, 2, 3));            // 6
console.log(sum(1, 2, 3, 4, 5));      // 15
console.log(sum(10, 20));             // 30
console.log(sum(5));                  // 5

// Example 2: First arg fixed, rest collected
function orderFood(mainDish, ...sides) {
  console.log(`\n🍽️  Main Dish: ${mainDish}`);
  console.log(`🥗 Side dishes: ${sides.join(", ")}`);
  console.log(`Total items: ${1 + sides.length}`);
}

orderFood("Biryani", "Raita", "Salad", "Papad");
orderFood("Pizza");  // sides will be empty array []

// Example 3: REST in destructuring
const [first, second, ...remaining] = [10, 20, 30, 40, 50];
console.log("\n🔢 Destructuring with rest:");
console.log("First:", first);        // 10
console.log("Second:", second);      // 20
console.log("Remaining:", remaining); // [30, 40, 50]

// Example 4: REST in object destructuring
const { name, age, ...otherDetails } = {
  name: "Abhishek",
  age: 25,
  city: "Mumbai",
  job: "Developer",
  hobby: "Coding",
};

console.log("\n👤 Object rest destructuring:");
console.log("Name:", name);
console.log("Age:", age);
console.log("Other:", otherDetails); // { city, job, hobby }

// ──────────────────────────────────────────
// 🎁 SPREAD OPERATOR — Expand/Unpack an array or object
// "Unbox everything and spread it out"
// Used when CALLING functions or creating arrays/objects
// ──────────────────────────────────────────

console.log("\n\n🎁 SPREAD OPERATOR EXAMPLES:\n");

// Example 1: Spread array into function arguments
const scores = [88, 92, 67, 95, 78];

console.log("Max score:", Math.max(...scores));  // same as Math.max(88, 92, 67, 95, 78)
console.log("Min score:", Math.min(...scores));

// Example 2: Merge/combine arrays
const veggies = ["🥕 Carrot", "🥦 Broccoli", "🌽 Corn"];
const fruits  = ["🍎 Apple", "🍌 Banana", "🍊 Orange"];
const proteins = ["🥚 Eggs", "🍗 Chicken"];

const fullMenu = [...veggies, ...fruits, ...proteins]; // Merge!
console.log("\n🍱 Full Menu:", fullMenu);

// Add items while spreading
const updatedMenu = ["🥗 Salad", ...veggies, "🧆 Falafel", ...proteins];
console.log("Updated Menu:", updatedMenu);

// Example 3: Copy array (without reference!)
const original = [1, 2, 3, 4, 5];
const copy = [...original]; // Creates a NEW array (not a reference!)

copy.push(99);
console.log("\n📋 Original:", original); // [1,2,3,4,5] — unchanged!
console.log("Copy:      ", copy);       // [1,2,3,4,5,99]

// vs shallow copy problem without spread:
const badCopy = original; // This is SAME reference!
badCopy.push(100);
console.log("Original after badCopy push:", original); // [1,2,3,4,5,100] — CHANGED! ❌

// Example 4: Spread with OBJECTS
const baseProfile = {
  username: "abhishek_dev",
  role: "user",
  theme: "dark",
};

const adminProfile = {
  ...baseProfile,       // spread base
  role: "admin",        // override role
  permissions: ["read", "write", "delete"],
};

console.log("\n👤 Base Profile:", baseProfile);
console.log("👑 Admin Profile:", adminProfile);

// Example 5: Copy object and update (immutable update pattern)
const user = { name: "Abhishek", age: 25, city: "Mumbai" };

// Update city without mutating original (like Redux!)
const updatedUser = { ...user, city: "Pune", age: 26 };

console.log("\n📝 Immutable Update:");
console.log("Original user:", user);       // unchanged!
console.log("Updated user: ", updatedUser); // new object with changes

// Example 6: Merge objects
const personalInfo = { name: "Abhishek", age: 25 };
const workInfo     = { job: "Developer", company: "TechCorp" };
const contactInfo  = { email: "abhi@email.com", phone: "9876543210" };

const fullProfile = { ...personalInfo, ...workInfo, ...contactInfo };
console.log("\n🗂️  Full Profile:", fullProfile);

// ──────────────────────────────────────────
// 🆚 REST vs SPREAD — Key Difference
// ──────────────────────────────────────────

console.log(`
┌─────────────────────────────────────────────────────────┐
│              REST vs SPREAD                             │
├───────────────┬─────────────────────────────────────────┤
│  REST (...)   │ COLLECTS multiple values INTO an array   │
│               │ Used in: function params, destructuring  │
│               │ Example: function f(...args) {}          │
├───────────────┼─────────────────────────────────────────┤
│  SPREAD (...) │ EXPANDS array/object INTO individual     │
│               │ Used in: function calls, array/obj       │
│               │ Example: Math.max(...arr)                │
└───────────────┴─────────────────────────────────────────┘
`);

// ──────────────────────────────────────────
// 🔥 PRACTICAL: Cart Management (like React state)
// ──────────────────────────────────────────

let cart = [];

function addItem(cart, newItem) {
  return [...cart, newItem]; // Returns NEW array (immutable!)
}

function removeItem(cart, itemId) {
  return cart.filter((item) => item.id !== itemId);
}

function updateQty(cart, itemId, qty) {
  return cart.map((item) =>
    item.id === itemId ? { ...item, qty } : item
  );
}

cart = addItem(cart, { id: 1, name: "Phone",  price: 15000, qty: 1 });
cart = addItem(cart, { id: 2, name: "Laptop", price: 55000, qty: 1 });
cart = addItem(cart, { id: 3, name: "Watch",  price: 3000,  qty: 1 });

console.log("\n🛒 Cart after adding items:");
cart.forEach((item) => console.log(`  [${item.id}] ${item.name} - ₹${item.price} x${item.qty}`));

cart = updateQty(cart, 1, 2); // Buy 2 phones
cart = removeItem(cart, 2);   // Remove laptop

console.log("\n🛒 Cart after updates:");
cart.forEach((item) => console.log(`  [${item.id}] ${item.name} - ₹${item.price} x${item.qty}`));

const totalBill = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
console.log(`💳 Total: ₹${totalBill}`);

// ============================================================
// 🧪 YOUR CODING CHALLENGES - TRY THESE!
// ============================================================

// 🟡 CHALLENGE 1 (Easy):
// a) Write a function `average(...nums)` using REST that calculates average
// b) Write a function `mergeArrays` that takes any number of arrays and merges them
//    using SPREAD: mergeArrays([1,2], [3,4], [5,6]) → [1,2,3,4,5,6]

// 🟠 CHALLENGE 2 (Medium):
// You have a `settings` object:
// const defaultSettings = { theme: "light", lang: "en", fontSize: 14, notifications: true }
// a) Create `userSettings` that overrides theme="dark" and fontSize=16
// b) Create a `resetSetting(settings, key)` function that removes a key
//    using spread/destructuring WITHOUT mutating original
// c) Create `mergeSettings(default, user)` that merges with user settings taking priority

// 🔴 CHALLENGE 3 (Hard):
// Build a `createEventEmitter()` function using spread/rest:
// - on(event, ...handlers)    → register one or more handlers for an event
// - emit(event, ...args)      → trigger all handlers for event with args
// - off(event, handler)       → remove a specific handler
// Use closures + spread/rest to build this mini event system!
