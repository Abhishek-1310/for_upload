// ============================================================
// 🎬 CHAPTER 11: REGULAR EXPRESSIONS (REGEX)
// 📖 Story: You're a DETECTIVE 🕵️
//           You get a big messy document and need to FIND clues,
//           VERIFY patterns, and EXTRACT information.
//           Regex is your magnifying glass! 🔍
// ============================================================

// ╔══════════════════════════════════════════════════════════╗
// ║  ❓ WHY DO WE NEED REGEX?                               ║
// ╠══════════════════════════════════════════════════════════╣
// ║                                                          ║
// ║  🔴 THE PROBLEM (without regex):                        ║
// ║  Validating, searching, or extracting text patterns     ║
// ║  without regex requires massive, fragile code.          ║
// ║                                                          ║
// ║  // ❌ WITHOUT regex — validate an email (nightmare!)   ║
// ║  function isEmail(str) {                                ║
// ║    const atIndex  = str.indexOf("@");                   ║
// ║    const dotIndex = str.lastIndexOf(".");               ║
// ║    if (atIndex < 1) return false;                       ║
// ║    if (dotIndex < atIndex + 2) return false;            ║
// ║    if (dotIndex === str.length - 1) return false;       ║
// ║    // ... still doesn't handle 50 edge cases!           ║
// ║  }                                                       ║
// ║                                                          ║
// ║  // ✅ WITH regex — one line, handles everything!       ║
// ║  const isEmail = (s) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s);
// ║                                                          ║
// ║  Without regex you CANNOT easily:                       ║
// ║  → Validate emails, phone numbers, passwords, URLs      ║
// ║  → Search for patterns inside strings                   ║
// ║  → Extract specific parts (dates, prices, codes)        ║
// ║  → Replace/clean up text (remove spaces, format data)   ║
// ║  → Parse logs, CSVs, or any structured text             ║
// ║                                                          ║
// ║  🎯 WHAT REGEX UNLOCKS:                                 ║
// ║  → Form validation in one line                          ║
// ║  → Search & replace with patterns (not just fixed text) ║
// ║  → Data extraction from messy strings                   ║
// ║  → Input sanitization & security checks                 ║
// ║  → Used in every language: JS, Python, Java, SQL...     ║
// ╚══════════════════════════════════════════════════════════╝

// ──────────────────────────────────────────
// 🔰 CREATING A REGEX
// Two ways to write regex in JavaScript:
// ──────────────────────────────────────────

// Way 1: Literal syntax (preferred — faster, cleaner)
const pattern1 = /hello/;

// Way 2: Constructor (use when pattern is dynamic)
const pattern2 = new RegExp("hello");
const word      = "world";
const pattern3  = new RegExp(word); // dynamic pattern!

// ──────────────────────────────────────────
// 🚩 FLAGS — Modify how regex behaves
// ──────────────────────────────────────────

// i  → case-Insensitive  (/hello/i matches "Hello", "HELLO", "hElLo")
// g  → Global            (find ALL matches, not just first)
// m  → Multiline         (^ and $ match start/end of each line)
// s  → Dotall            (. also matches newlines)

console.log("🚩 FLAGS:\n");
console.log(/hello/i.test("HELLO WORLD"));   // true (case insensitive)
console.log(/hello/i.test("Hello World"));   // true
console.log("hello world hello".match(/hello/g));  // ['hello', 'hello'] (global)

// ──────────────────────────────────────────
// 🔤 REGEX BUILDING BLOCKS
// ──────────────────────────────────────────

console.log("\n\n🔤 CHARACTER CLASSES:\n");

// .     → Any character EXCEPT newline
// \d    → Any digit        [0-9]
// \D    → NOT a digit      [^0-9]
// \w    → Word character   [a-zA-Z0-9_]
// \W    → NOT word char
// \s    → Whitespace       (space, tab, newline)
// \S    → NOT whitespace
// [abc] → Any of a, b, c
// [a-z] → Any lowercase letter
// [A-Z] → Any uppercase letter
// [0-9] → Any digit
// [^abc]→ NOT a, b, or c

console.log("\\d (digit):",       /\d/.test("Room 42"));         // true
console.log("\\d (digit):",       /\d/.test("No numbers here")); // false
console.log("\\w (word char):",   /\w/.test("Hello!"));          // true
console.log("[aeiou] (vowel):",   /[aeiou]/.test("rhythm"));     // false
console.log("[a-zA-Z] (letter):", /[a-zA-Z]/.test("123abc"));    // true

// ──────────────────────────────────────────
// 🔢 QUANTIFIERS — How many times?
// ──────────────────────────────────────────

console.log("\n\n🔢 QUANTIFIERS:\n");

// *     → 0 or more
// +     → 1 or more
// ?     → 0 or 1 (optional)
// {n}   → Exactly n times
// {n,}  → n or more times
// {n,m} → Between n and m times

console.log("+ (1 or more digits):", /\d+/.test("abc123"));    // true
console.log("+ (1 or more digits):", /\d+/.test("abcdef"));    // false
console.log("? (optional s):",       /colou?r/.test("color")); // true (u is optional)
console.log("? (optional s):",       /colou?r/.test("colour")); // true
console.log("{3} (exactly 3):",      /\d{3}/.test("12"));      // false
console.log("{3} (exactly 3):",      /\d{3}/.test("123"));     // true
console.log("{2,4} (2 to 4):",       /\d{2,4}/.test("12345")); // true (found 2-4 digits)

// ──────────────────────────────────────────
// ⚓ ANCHORS — Position in string
// ──────────────────────────────────────────

console.log("\n\n⚓ ANCHORS:\n");

// ^  → Start of string
// $  → End of string
// \b → Word boundary

console.log("^ (starts with Hi):",    /^Hi/.test("Hi there!"));       // true
console.log("^ (starts with Hi):",    /^Hi/.test("Say Hi there!"));   // false
console.log("$ (ends with .js):",     /\.js$/.test("index.js"));      // true
console.log("$ (ends with .js):",     /\.js$/.test("index.json"));    // false
console.log("\\b (word boundary):",   /\bcat\b/.test("cat"));         // true
console.log("\\b (word boundary):",   /\bcat\b/.test("concatenate")); // false

// ──────────────────────────────────────────
// 🔧 REGEX METHODS
// ──────────────────────────────────────────

console.log("\n\n🔧 REGEX METHODS:\n");

const sentence = "The price is ₹250 and ₹500 for the combo!";

// 1️⃣  test() → returns true/false
console.log("1️⃣  test():");
console.log(/\d+/.test(sentence)); // true

// 2️⃣  match() → returns array of matches (or null)
console.log("\n2️⃣  match():");
console.log(sentence.match(/\d+/));   // first match only: ['250']
console.log(sentence.match(/\d+/g));  // all matches: ['250', '500']

// 3️⃣  matchAll() → returns iterator of ALL matches with full detail
console.log("\n3️⃣  matchAll():");
const matches = [...sentence.matchAll(/\d+/g)];
matches.forEach(m => console.log(`  Found: ${m[0]} at index ${m.index}`));

// 4️⃣  replace() → replace matched text
console.log("\n4️⃣  replace():");
const censored = "bad word and another bad word".replace(/bad/g, "***");
console.log(censored); // "*** word and another *** word"

// 5️⃣  replaceAll() → replace all (simpler than replace+g flag)
console.log("\n5️⃣  replaceAll():");
const cleaned = "  too   many   spaces  ".replace(/\s+/g, " ").trim();
console.log(`"${cleaned}"`); // "too many spaces"

// 6️⃣  split() → split string by pattern
console.log("\n6️⃣  split():");
const csv = "Abhishek, 25,  Mumbai,  Developer";
const parts = csv.split(/,\s*/); // split on comma + optional spaces
console.log(parts); // ['Abhishek', '25', 'Mumbai', 'Developer']

// 7️⃣  search() → returns INDEX of first match (-1 if not found)
console.log("\n7️⃣  search():");
console.log("Hello World".search(/World/)); // 6
console.log("Hello World".search(/xyz/));   // -1

// ──────────────────────────────────────────
// 📦 GROUPS & CAPTURING
// ──────────────────────────────────────────

console.log("\n\n📦 GROUPS & CAPTURING:\n");

// ()   → Capturing group (captures the matched text)
// (?:) → Non-capturing group (groups without capturing)
// |    → OR

// Extract date parts from "2026-04-30"
const dateStr  = "Today is 2026-04-30, meeting at 2024-12-25";
const dateRegex = /(\d{4})-(\d{2})-(\d{2})/g;

const dateMatches = [...dateStr.matchAll(dateRegex)];
dateMatches.forEach(m => {
  console.log(`Full: ${m[0]} → Year: ${m[1]}, Month: ${m[2]}, Day: ${m[3]}`);
});

// Named groups (even cleaner!)
const namedDateRegex = /(?<year>\d{4})-(?<month>\d{2})-(?<day>\d{2})/;
const result = "2026-04-30".match(namedDateRegex);
const { year, month, day } = result.groups;
console.log(`\nNamed groups → Year: ${year}, Month: ${month}, Day: ${day}`);

// OR operator
console.log("\n| (OR):");
console.log(/cat|dog/.test("I have a cat")); // true
console.log(/cat|dog/.test("I have a dog")); // true
console.log(/cat|dog/.test("I have a fish")); // false

// ──────────────────────────────────────────
// 🌍 REAL LIFE: FORM VALIDATION
// Story: User signs up — validate everything!
// ──────────────────────────────────────────

console.log("\n\n🌍 REAL LIFE — FORM VALIDATION:\n");

const validators = {
  // Email: something@domain.extension
  email: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,

  // Phone: 10 digits (Indian), optional +91 prefix
  phone: /^(\+91[\s-]?)?[6-9]\d{9}$/,

  // Password: min 8 chars, 1 uppercase, 1 lowercase, 1 digit, 1 special char
  password: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,

  // Username: 3-20 chars, letters/numbers/underscore only
  username: /^[a-zA-Z0-9_]{3,20}$/,

  // URL: http or https
  url: /^https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_+.~#?&//=]*)$/,

  // Indian PIN code: 6 digits
  pincode: /^[1-9][0-9]{5}$/,
};

function validate(field, value) {
  const isValid = validators[field].test(value);
  console.log(`  ${field.padEnd(10)}: "${value}" → ${isValid ? "✅ Valid" : "❌ Invalid"}`);
}

console.log("📧 Email:");
validate("email", "abhishek@gmail.com");
validate("email", "notanemail");
validate("email", "missing@domain");

console.log("\n📱 Phone:");
validate("phone", "9876543210");
validate("phone", "+91 9876543210");
validate("phone", "12345");

console.log("\n🔑 Password:");
validate("password", "Abhi@1234");
validate("password", "weakpass");
validate("password", "NoSpecial1");

console.log("\n👤 Username:");
validate("username", "abhishek_dev");
validate("username", "ab");          // too short
validate("username", "user name!");  // spaces & special chars

// ──────────────────────────────────────────
// 🔍 REAL LIFE: DATA EXTRACTION
// Story: Parse messy log files like a detective!
// ──────────────────────────────────────────

console.log("\n\n🔍 REAL LIFE — DATA EXTRACTION:\n");

const serverLogs = `
[2026-04-30 09:15:23] ERROR   user@gmail.com failed login from 192.168.1.10
[2026-04-30 09:16:05] INFO    user2@yahoo.com logged in from 10.0.0.5
[2026-04-30 09:17:44] WARNING user3@hotmail.com suspicious activity from 172.16.0.1
[2026-04-30 09:18:12] ERROR   admin@company.com failed login from 192.168.1.10
`;

// Extract all ERROR lines
const errorLines = serverLogs.match(/.*ERROR.*/g);
console.log("🚨 ERROR lines:");
errorLines?.forEach(line => console.log(" ", line.trim()));

// Extract all email addresses
const emails = serverLogs.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g);
console.log("\n📧 All emails found:", emails);

// Extract all IP addresses
const ips = serverLogs.match(/\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/g);
console.log("\n🌐 All IPs found:", ips);

// Extract timestamps
const timestamps = serverLogs.match(/\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}/g);
console.log("\n⏰ Timestamps:", timestamps);

// ──────────────────────────────────────────
// ✏️ REAL LIFE: TEXT CLEANING & FORMATTING
// ──────────────────────────────────────────

console.log("\n\n✏️ REAL LIFE — TEXT CLEANING:\n");

// 1. Remove extra spaces
const messy = "  Hello    World   how  are   you  ";
console.log("Clean spaces:", messy.replace(/\s+/g, " ").trim());

// 2. Capitalize first letter of each word (Title Case)
const title = "the quick brown fox jumps over the lazy dog";
const titleCase = title.replace(/\b\w/g, c => c.toUpperCase());
console.log("Title case:", titleCase);

// 3. Remove all HTML tags from a string
const html = "<h1>Hello <b>World</b>!</h1> <p>This is <em>regex</em>.</p>";
const plainText = html.replace(/<[^>]*>/g, "");
console.log("Strip HTML:", plainText);

// 4. Mask credit card number (show only last 4 digits)
const card = "4532015112830366";
const masked = card.replace(/\d(?=\d{4})/g, "*");
console.log("Masked card:", masked); // ************0366

// 5. Format phone number
const rawPhone = "9876543210";
const formatted = rawPhone.replace(/(\d{3})(\d{3})(\d{4})/, "$1-$2-$3");
console.log("Formatted phone:", formatted); // 987-654-3210

// 6. Extract all hashtags from a tweet
const tweet = "Loving #JavaScript and #Regex! #coding is fun with #webdev";
const hashtags = tweet.match(/#\w+/g);
console.log("Hashtags:", hashtags);

// 7. Convert camelCase to kebab-case
const camel = "myVariableName";
const kebab = camel.replace(/([A-Z])/g, "-$1").toLowerCase();
console.log("kebab-case:", kebab); // my-variable-name

// ──────────────────────────────────────────
// 🔮 LOOKAHEAD & LOOKBEHIND (Advanced)
// "Find X only when it's next to Y"
// ──────────────────────────────────────────

console.log("\n\n🔮 LOOKAHEAD & LOOKBEHIND:\n");

// Positive Lookahead (?=...)  → match X only if followed by Y
// Negative Lookahead (?!...)  → match X only if NOT followed by Y
// Positive Lookbehind (?<=...) → match X only if preceded by Y
// Negative Lookbehind (?<!...) → match X only if NOT preceded by Y

// Find numbers followed by "px"
const css = "font-size: 16px; margin: 10px; opacity: 0.5; z-index: 100;";
const pxValues = css.match(/\d+(?=px)/g);
console.log("Pixel values:", pxValues); // ['16', '10', '100'] — not 0.5!

// Find ₹ amounts (numbers preceded by ₹)
const prices = "Items: ₹250, ₹500, discount: 10%, total: ₹675";
const amounts = prices.match(/(?<=₹)\d+/g);
console.log("Rupee amounts:", amounts); // ['250', '500', '675']

// Password strength using lookaheads
const strongPassRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%]).{8,}$/;
console.log("\nPassword strength:");
console.log("  'Abhi@123'  :", strongPassRegex.test("Abhi@123"));   // ✅
console.log("  'abcdefgh'  :", strongPassRegex.test("abcdefgh"));   // ❌
console.log("  'ABCD1234'  :", strongPassRegex.test("ABCD1234"));   // ❌

// ──────────────────────────────────────────
// 📋 REGEX CHEAT SHEET
// ──────────────────────────────────────────

console.log(`
╔══════════════════════════════════════════════════════════╗
║              REGEX QUICK CHEAT SHEET                     ║
╠══════════════╦═══════════════════════════════════════════╣
║  .           ║  Any character (except newline)           ║
║  \\d          ║  Digit [0-9]                              ║
║  \\D          ║  Not a digit                              ║
║  \\w          ║  Word char [a-zA-Z0-9_]                  ║
║  \\s          ║  Whitespace                               ║
║  [abc]       ║  a, b, or c                               ║
║  [^abc]      ║  NOT a, b, or c                           ║
╠══════════════╬═══════════════════════════════════════════╣
║  *           ║  0 or more                                ║
║  +           ║  1 or more                                ║
║  ?           ║  0 or 1 (optional)                        ║
║  {n}         ║  Exactly n                                ║
║  {n,m}       ║  Between n and m                          ║
╠══════════════╬═══════════════════════════════════════════╣
║  ^           ║  Start of string                          ║
║  $           ║  End of string                            ║
║  \\b          ║  Word boundary                            ║
╠══════════════╬═══════════════════════════════════════════╣
║  (abc)       ║  Capturing group                          ║
║  (?:abc)     ║  Non-capturing group                      ║
║  (?=abc)     ║  Lookahead (followed by)                  ║
║  (?<=abc)    ║  Lookbehind (preceded by)                 ║
║  a|b         ║  a OR b                                   ║
╠══════════════╬═══════════════════════════════════════════╣
║  i           ║  Flag: case insensitive                   ║
║  g           ║  Flag: global (all matches)               ║
║  m           ║  Flag: multiline                          ║
╚══════════════╩═══════════════════════════════════════════╝
`);

// ============================================================
// 🧪 YOUR CODING CHALLENGES - TRY THESE!
// ============================================================

// 🟡 CHALLENGE 1 (Easy):
// Write regex patterns to validate:
// a) A 6-digit OTP (only digits, exactly 6)
// b) A name (only letters and spaces, min 2 chars)
// c) A year between 1900 and 2099
// d) A hex color code like #FF5733 or #fff
// Test each with at least 2 valid and 2 invalid inputs.

// 🟠 CHALLENGE 2 (Medium):
// Given this messy string of product data:
// const data = "iPhone14:₹79999 | Samsung S23:₹69999 | Pixel7:₹59999 | OnePlus11:₹56999";
// a) Extract all product names (before the colon)
// b) Extract all prices (numbers after ₹)
// c) Find the most expensive product using the extracted data
// d) Replace all prices with "SALE PRICE" using replace()

// 🔴 CHALLENGE 3 (Hard):
// Build a `parseCSV(text)` function using regex that:
// - Handles fields separated by commas
// - Handles fields wrapped in quotes (which may contain commas inside)
// - Trims whitespace from each field
// - Returns an array of arrays (rows and columns)
// Example input:
//   "Abhishek, 25, \"Mumbai, Maharashtra\", Developer\nPriya, 22, Delhi, Designer"
// Expected output:
//   [["Abhishek","25","Mumbai, Maharashtra","Developer"],
//    ["Priya","22","Delhi","Designer"]]
//
// BONUS: Build a mini form validator class using regex:
// class FormValidator {
//   addRule(fieldName, regex, errorMessage)
//   validate(formData) → returns { valid: true } or { valid: false, errors: {...} }
// }
