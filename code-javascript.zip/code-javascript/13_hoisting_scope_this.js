// ============================================================
// 🎬 CHAPTER 13: HOISTING, SCOPE & THE `this` KEYWORD
// 📖 Story: A BUILDING with FLOORS 🏢
//           Each floor (scope) has its own rooms (variables).
//           Hoisting = JS reads all room labels BEFORE
//           you enter the building!
// ============================================================

// ╔══════════════════════════════════════════════════════════╗
// ║  ❓ WHY DO WE NEED TO UNDERSTAND HOISTING & SCOPE?      ║
// ╠══════════════════════════════════════════════════════════╣
// ║                                                          ║
// ║  🔴 THE PROBLEM (without knowing this):                 ║
// ║  Code that SHOULD fail mysteriously works (or vice      ║
// ║  versa). You get `undefined` when you expect a value.   ║
// ║  Your `this` points to wrong object. Bugs everywhere!   ║
// ║                                                          ║
// ║  console.log(name); // "undefined" — not an error!? 😱  ║
// ║  var name = "Abhishek";                                 ║
// ║                                                          ║
// ║  greet(); // Works!? The function isn't defined yet! 😱 ║
// ║  function greet() { console.log("Hello!"); }            ║
// ║                                                          ║
// ║  🎯 WHAT KNOWING THIS UNLOCKS:                          ║
// ║  → Predict code behavior before running it              ║
// ║  → Avoid subtle bugs with var/let/const                 ║
// ║  → Understand `this` in ANY situation                   ║
// ║  → Ace the most common interview questions              ║
// ╚══════════════════════════════════════════════════════════╝

// ══════════════════════════════════════════
// PART 1: HOISTING
// ══════════════════════════════════════════

// ──────────────────────────────────────────
// 🔰 WHAT IS HOISTING?
// JS engine does TWO passes over your code:
// Pass 1 (Creation Phase): Scans and REGISTERS all
//         var declarations and function declarations
// Pass 2 (Execution Phase): Runs code line by line
// ──────────────────────────────────────────

console.log("=== HOISTING DEMO ===\n");

// 🔴 var HOISTING — declaration hoisted, NOT initialization
console.log("Before declaration:", myVar); // undefined (NOT an error!)
var myVar = "Hello!";
console.log("After declaration:", myVar);  // "Hello!"

// What JS actually sees (internally):
// var myVar;              ← hoisted to top (declaration only)
// console.log(myVar);     ← undefined (declared but not initialized)
// myVar = "Hello!";       ← initialization stays here
// console.log(myVar);     ← "Hello!"

// ──────────────────────────────────────────
// 🟢 FUNCTION HOISTING — entire function body is hoisted!
// ──────────────────────────────────────────

// Call BEFORE definition — works! 🎉
const result = add(5, 3);
console.log("\nFunction hoisting:", result); // 8 — works perfectly!

function add(a, b) {
  return a + b;
}

// ──────────────────────────────────────────
// ⚠️  FUNCTION EXPRESSION — NOT hoisted like function declarations
// ──────────────────────────────────────────

// console.log(multiply(5, 3)); // ❌ TypeError: multiply is not a function
// Why? `multiply` is var-hoisted (undefined), not the function itself!

var multiply = function (a, b) {
  return a * b;
};

console.log("After definition:", multiply(5, 3)); // 15 ✅

// ──────────────────────────────────────────
// 🔴 let & const — HOISTED but in "Temporal Dead Zone" (TDZ)
// They exist in memory but CANNOT be accessed before declaration!
// ──────────────────────────────────────────

console.log("\n--- Temporal Dead Zone (TDZ) ---");

// console.log(myLet); // ❌ ReferenceError: Cannot access 'myLet' before initialization
let myLet = "I exist!";
console.log(myLet); // ✅ "I exist!"

// console.log(myConst); // ❌ ReferenceError (same as let)
const myConst = "Constant!";
console.log(myConst); // ✅ "Constant!"

// ──────────────────────────────────────────
// 📊 var vs let vs const COMPARISON
// ──────────────────────────────────────────

console.log(`
┌─────────────────────────────────────────────────────────────┐
│              var  vs  let  vs  const                        │
├─────────────────┬──────────┬──────────┬────────────────────┤
│  Feature        │   var    │   let    │      const         │
├─────────────────┼──────────┼──────────┼────────────────────┤
│  Scope          │ Function │  Block   │  Block             │
│  Hoisted        │ Yes(undef)│ Yes(TDZ)│  Yes(TDZ)          │
│  Re-declare     │   ✅ Yes  │  ❌ No   │  ❌ No             │
│  Re-assign      │   ✅ Yes  │  ✅ Yes  │  ❌ No             │
│  Global attach  │   ✅ Yes  │  ❌ No   │  ❌ No             │
└─────────────────┴──────────┴──────────┴────────────────────┘
`);

// ══════════════════════════════════════════
// PART 2: SCOPE
// ══════════════════════════════════════════

console.log("\n=== SCOPE DEMO ===\n");

// ──────────────────────────────────────────
// 🌍 1. GLOBAL SCOPE
// ──────────────────────────────────────────

const globalVar = "I'm global! 🌍";

function showGlobal() {
  console.log(globalVar); // ✅ Can access global from inside function
}
showGlobal();

// ──────────────────────────────────────────
// 🏠 2. FUNCTION SCOPE
// ──────────────────────────────────────────

function outer() {
  const functionVar = "I'm function-scoped 🏠";
  console.log(functionVar); // ✅
}
outer();
// console.log(functionVar); // ❌ ReferenceError — can't access outside!

// var is FUNCTION scoped (not block scoped!)
function varScope() {
  if (true) {
    var x = "I'm var inside if block";
    let y = "I'm let inside if block";
  }
  console.log(x); // ✅ var leaks out of the if block!
  // console.log(y); // ❌ ReferenceError — let is block scoped
}
varScope();

// ──────────────────────────────────────────
// 📦 3. BLOCK SCOPE (let & const)
// ──────────────────────────────────────────

{
  const blockVar = "I'm block-scoped 📦";
  let blockLet   = "Me too!";
  console.log(blockVar); // ✅
}
// console.log(blockVar); // ❌ ReferenceError

// ──────────────────────────────────────────
// 🔗 4. SCOPE CHAIN — Looking UP the chain
// ──────────────────────────────────────────

const level1 = "Level 1 (global)";

function outerFn() {
  const level2 = "Level 2 (outer)";

  function innerFn() {
    const level3 = "Level 3 (inner)";

    // Can access ALL outer levels!
    console.log("\n🔗 Scope Chain:");
    console.log("  " + level3); // own scope
    console.log("  " + level2); // parent scope
    console.log("  " + level1); // grandparent scope (global)
  }

  innerFn();
  // console.log(level3); // ❌ Can't access inner scope from outer!
}

outerFn();

// ──────────────────────────────────────────
// 🔍 5. LEXICAL SCOPE — Scope is determined WHERE function is DEFINED
//                       not where it is CALLED
// ──────────────────────────────────────────

const country = "India 🇮🇳";

function makeGreeter() {
  const city = "Mumbai";
  return function greet(name) {
    // `city` is accessible because greet is DEFINED inside makeGreeter
    // even when greet is called from outside!
    console.log(`\n👋 Hello ${name} from ${city}, ${country}!`);
  };
}

const greetFn = makeGreeter();
greetFn("Abhishek"); // Can still access `city` — this is lexical scope!

// ══════════════════════════════════════════
// PART 3: `this` KEYWORD
// ══════════════════════════════════════════

console.log("\n\n=== `this` KEYWORD DEMO ===\n");

// `this` = Who is calling the function?
// It's NOT about where the function is defined.
// It changes based on HOW the function is called!

// ──────────────────────────────────────────
// 1️⃣  `this` in Global Context
// ──────────────────────────────────────────

console.log("1️⃣  Global `this`:");
// In browser:  this = window object
// In Node.js:  this = module.exports (or {} in top-level)
console.log("  typeof this:", typeof this); // "object"

// ──────────────────────────────────────────
// 2️⃣  `this` in a Regular Function
// ──────────────────────────────────────────

console.log("\n2️⃣  Regular function `this`:");

function regularFn() {
  // In strict mode: this = undefined
  // In non-strict:  this = global object (window/global)
  console.log("  Regular fn this:", this === global ? "global" : this);
}
regularFn();

// ──────────────────────────────────────────
// 3️⃣  `this` in an Object Method
// ──────────────────────────────────────────

console.log("\n3️⃣  Object method `this`:");

const person = {
  name: "Abhishek",
  greet: function () {
    console.log(`  Hello! I am ${this.name}`); // `this` = person ✅
  },
  // Arrow function — NO own `this`! Takes from surrounding scope!
  greetArrow: () => {
    console.log(`  Arrow: I am ${this?.name ?? "undefined"}`); // `this` = global/undefined ❌
  },
};

person.greet();       // ✅ "Hello! I am Abhishek"
person.greetArrow();  // ❌ Arrow doesn't have its own `this`

// ──────────────────────────────────────────
// 4️⃣  `this` LOST when method is extracted
// ──────────────────────────────────────────

console.log("\n4️⃣  `this` loses context:");

const greetFnExtracted = person.greet;
// greetFnExtracted(); // ❌ `this` is now undefined or global, not `person`

// Fix with bind:
const boundGreet = person.greet.bind(person);
boundGreet(); // ✅ `this` is permanently bound to person

// ──────────────────────────────────────────
// 5️⃣  `this` in Arrow Functions
// Arrow functions do NOT have their own `this`!
// They INHERIT `this` from the surrounding lexical scope.
// ──────────────────────────────────────────

console.log("\n5️⃣  Arrow function `this`:");

const team = {
  name: "Dev Team",
  members: ["Abhishek", "Priya", "Raj"],

  // ❌ Regular function loses `this` in the callback!
  listMembersWrong: function () {
    this.members.forEach(function (member) {
      // `this` here is NOT team! It's global/undefined
      // console.log(`${this.name}: ${member}`); // ❌ broken
    });
  },

  // ✅ Arrow function INHERITS `this` from listMembers (which is team)
  listMembersRight: function () {
    this.members.forEach((member) => {
      console.log(`  ${this.name}: ${member}`); // ✅ `this` = team!
    });
  },
};

team.listMembersRight();

// ──────────────────────────────────────────
// 6️⃣  `this` in Classes
// ──────────────────────────────────────────

console.log("\n6️⃣  `this` in Classes:");

class Counter {
  constructor() {
    this.count = 0;
    // Fix `this` in methods that might lose context (e.g., event handlers)
    this.increment = this.increment.bind(this); // pre-bind in constructor
  }

  increment() {
    this.count++;
    console.log(`  Count: ${this.count}`);
  }

  // Arrow method — automatically bound to instance! (Modern approach)
  decrement = () => {
    this.count--;
    console.log(`  Count: ${this.count}`);
  };
}

const counter = new Counter();
counter.increment(); // 1
counter.increment(); // 2
counter.decrement(); // 1

// Even when extracted — works because of bind in constructor!
const { increment } = counter;
increment(); // ✅ Still works! Count: 2

// ──────────────────────────────────────────
// 7️⃣  `this` in new keyword
// ──────────────────────────────────────────

console.log("\n7️⃣  `this` with new:");

function Car(make, model) {
  // When called with `new`, `this` = brand new empty object {}
  this.make  = make;
  this.model = model;
  // `new` automatically returns `this` at the end!
}

const myCar = new Car("Toyota", "Camry");
console.log("  Car:", myCar); // { make: 'Toyota', model: 'Camry' }

// ──────────────────────────────────────────
// 📊 `this` SUMMARY TABLE
// ──────────────────────────────────────────

console.log(`
┌────────────────────────────────────────────────────────────┐
│                   \`this\` REFERENCE TABLE                    │
├──────────────────────────┬─────────────────────────────────┤
│  Context                 │  Value of \`this\`                 │
├──────────────────────────┼─────────────────────────────────┤
│  Global (non-strict)     │  window (browser) / global(Node)│
│  Global (strict mode)    │  undefined                      │
│  Regular function        │  Depends on caller              │
│  Arrow function          │  Inherited from outer scope     │
│  Object method           │  The object before the dot      │
│  Class method            │  The class instance             │
│  new Constructor()       │  The newly created object       │
│  call(ctx) / apply(ctx)  │  ctx (whatever you pass)        │
│  bind(ctx)               │  ctx (permanently fixed)        │
└──────────────────────────┴─────────────────────────────────┘
`);

// ============================================================
// 🧪 YOUR CODING CHALLENGES - TRY THESE!
// ============================================================

// 🟡 CHALLENGE 1 (Predict output — Easy):
// Write the output of this code BEFORE running it:
//
// console.log(a);
// var a = 5;
// console.log(a);
//
// console.log(b());
// function b() { return "I'm b!"; }
//
// console.log(typeof c);
// let c = 10;
//
// var x = 1;
// function test() {
//   console.log(x);
//   var x = 2;
//   console.log(x);
// }
// test();
// console.log(x);

// 🟠 CHALLENGE 2 (Medium — fix the bugs):
// Fix `this` in the following code so all logs show correct name:
//
// const user = {
//   name: "Abhishek",
//   friends: ["Priya", "Raj", "Sneha"],
//   
//   showFriends: function() {
//     this.friends.forEach(function(friend) {
//       console.log(this.name + " knows " + friend); // ❌ this.name is undefined
//     });
//   },
//
//   delayedGreet: function() {
//     setTimeout(function() {
//       console.log("Hello from " + this.name); // ❌ this.name is undefined
//     }, 100);
//   }
// };
// Fix showFriends and delayedGreet using 2 different methods each.

// 🔴 CHALLENGE 3 (Hard):
// Build a `createPerson(name, age)` function WITHOUT using class:
// - Uses closure to keep data private
// - Has methods: getName(), getAge(), birthday() (increment age)
// - `this` should always refer to the person object
// - birthday() should work even when extracted: const bday = person.birthday; bday();
// - Test: Create 2 people and call birthday() on each independently.
