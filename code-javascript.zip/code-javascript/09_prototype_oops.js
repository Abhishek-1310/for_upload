// ============================================================
// 🎬 CHAPTER 9: PROTOTYPE & PROTOTYPAL INHERITANCE
// 📖 Story: A FAMILY TREE 👨‍👩‍👧‍👦
//           Children inherit features from parents.
//           If a child doesn't have something, it looks UP
//           the family tree to find it!
//           That's the PROTOTYPE CHAIN!
// ============================================================

// ╔══════════════════════════════════════════════════════════╗
// ║  ❓ WHY DO WE NEED PROTOTYPE & INHERITANCE?              ║
// ╠══════════════════════════════════════════════════════════╣
// ║                                                          ║
// ║  🔴 THE PROBLEM (without prototypes):                    ║
// ║  If you create 1000 Dog objects, and each Dog has its    ║
// ║  OWN copy of bark(), eat(), sleep() methods — that's     ║
// ║  1000 × 3 = 3000 function copies in memory! 😱 WASTE!   ║
// ║                                                          ║
// ║  // ❌ WITHOUT prototype — method copied for every object
// ║  function Dog(name) {                                    ║
// ║    this.name = name;                                     ║
// ║    this.bark = function() { // ❌ NEW copy each time!    ║
// ║      console.log(this.name + " barks!");                 ║
// ║    };                                                    ║
// ║  }                                                       ║
// ║  const d1 = new Dog("Rex");                              ║
// ║  const d2 = new Dog("Max");                              ║
// ║  d1.bark === d2.bark // ❌ false! 2 separate functions!  ║
// ║                                                          ║
// ║  Also WITHOUT inheritance:                               ║
// ║  → Every class must REPEAT common logic                  ║
// ║  → No way to share behaviour between related objects     ║
// ║  → Fixing a bug in shared logic means editing EVERYWHERE ║
// ║                                                          ║
// ║  ✅ THE SOLUTION (with prototype):                       ║
// ║  // ✅ ONE shared method for ALL instances               ║
// ║  Dog.prototype.bark = function() { ... };                ║
// ║  d1.bark === d2.bark // ✅ true! Same function, 1 copy!  ║
// ║                                                          ║
// ║  🎯 WHAT PROTOTYPES UNLOCK:                              ║
// ║  → MEMORY EFFICIENCY — methods shared, not copied        ║
// ║  → INHERITANCE — child gets parent's methods for free    ║
// ║  → EXTENSION — add methods to built-in types (carefully!)║
// ║  → Understand HOW classes, `new`, `extends` work inside  ║
// ║  → Foundation of ALL JavaScript objects & arrays         ║
// ╚══════════════════════════════════════════════════════════╝

// ──────────────────────────────────────────
// 🔰 WHAT IS PROTOTYPE?
// Every object in JS has a hidden link to another object called its "prototype"
// When you access a property, JS first looks at the object,
// then climbs UP the prototype chain until it finds it (or hits null)
// ──────────────────────────────────────────

console.log("🔗 PROTOTYPE BASICS:\n");

// Every function has a `prototype` property (an object)
// Every object has a `__proto__` property pointing to its prototype

function Animal(name, sound) {
  this.name  = name;
  this.sound = sound;
}

// Adding methods to the PROTOTYPE (shared by ALL instances!)
Animal.prototype.speak = function () {
  console.log(`🐾 ${this.name} says: ${this.sound}!`);
};

Animal.prototype.eat = function (food) {
  console.log(`🍖 ${this.name} is eating ${food}`);
};

Animal.prototype.describe = function () {
  console.log(`📋 I am ${this.name}, a ${this.constructor.name}`);
};

const dog = new Animal("Buddy", "Woof");
const cat = new Animal("Whiskers", "Meow");

dog.speak();    // Uses prototype method
cat.speak();    // Same method, shared!
dog.eat("Bone");

// Both share the SAME speak method in memory (efficient!)
console.log("\nSame method?", dog.speak === cat.speak); // true ✅

// Prototype chain lookup
console.log("\n🔍 Prototype Chain:");
console.log(dog.hasOwnProperty("name"));     // true — OWN property
console.log(dog.hasOwnProperty("speak"));    // false — from prototype!
console.log("speak" in dog);                 // true — inherited!

// ──────────────────────────────────────────
// 👨‍👩‍👧 PROTOTYPAL INHERITANCE
// Story: Dog inherits from Animal, but adds its own tricks!
// ──────────────────────────────────────────

console.log("\n\n👨‍👩‍👧 INHERITANCE EXAMPLE:\n");

// Parent
function Vehicle(make, model, year) {
  this.make  = make;
  this.model = model;
  this.year  = year;
  this.speed = 0;
}

Vehicle.prototype.accelerate = function (amount) {
  this.speed += amount;
  console.log(`🚗 ${this.make} ${this.model} speed: ${this.speed} km/h`);
};

Vehicle.prototype.brake = function (amount) {
  this.speed = Math.max(0, this.speed - amount);
  console.log(`🛑 ${this.make} ${this.model} speed: ${this.speed} km/h`);
};

Vehicle.prototype.describe = function () {
  console.log(`🚘 ${this.year} ${this.make} ${this.model}`);
};

// Child: Car inherits from Vehicle
function Car(make, model, year, doors) {
  Vehicle.call(this, make, model, year); // 🔥 Call parent constructor!
  this.doors = doors;
}

// Set up prototype chain: Car → Vehicle → Object
Car.prototype = Object.create(Vehicle.prototype);
Car.prototype.constructor = Car; // Fix constructor reference

// Add Car-specific method
Car.prototype.honk = function () {
  console.log(`📯 ${this.make} goes BEEP BEEP!`);
};

// Child: ElectricCar inherits from Car
function ElectricCar(make, model, year, doors, batteryRange) {
  Car.call(this, make, model, year, doors); // Call Car constructor
  this.batteryRange = batteryRange;
  this.battery      = 100; // %
}

ElectricCar.prototype = Object.create(Car.prototype);
ElectricCar.prototype.constructor = ElectricCar;

// Override accelerate (method overriding!)
ElectricCar.prototype.accelerate = function (amount) {
  this.speed    += amount;
  this.battery  -= amount * 0.1;
  console.log(`⚡ ${this.make} speed: ${this.speed} km/h | Battery: ${this.battery.toFixed(1)}%`);
};

ElectricCar.prototype.charge = function () {
  this.battery = 100;
  console.log(`🔋 ${this.make} fully charged!`);
};

const myCar       = new Car("Toyota", "Camry", 2022, 4);
const myTesla     = new ElectricCar("Tesla", "Model 3", 2023, 4, 350);

myCar.describe();       // From Vehicle.prototype
myCar.accelerate(60);   // From Vehicle.prototype
myCar.honk();           // From Car.prototype

console.log("");
myTesla.describe();     // From Vehicle.prototype (inherited!)
myTesla.accelerate(80); // From ElectricCar.prototype (OVERRIDDEN!)
myTesla.honk();         // From Car.prototype (inherited!)
myTesla.charge();       // ElectricCar's own method

// Check the chain
console.log("\n🔗 instanceof checks:");
console.log("myTesla instanceof ElectricCar:", myTesla instanceof ElectricCar); // true
console.log("myTesla instanceof Car:        ", myTesla instanceof Car);         // true
console.log("myTesla instanceof Vehicle:    ", myTesla instanceof Vehicle);     // true

// ──────────────────────────────────────────
// 🏫 MODERN WAY: ES6 CLASSES (syntactic sugar over prototypes!)
// Same thing, cleaner syntax
// ──────────────────────────────────────────

console.log("\n\n🏫 ES6 CLASS SYNTAX (same prototype under the hood):\n");

class Person {
  constructor(name, age) {
    this.name = name;
    this.age  = age;
  }

  // Added to Person.prototype automatically
  greet() {
    console.log(`👋 Hi! I'm ${this.name}, ${this.age} years old.`);
  }

  // Static method (on the class itself, not instances)
  static create(name, age) {
    return new Person(name, age);
  }

  // Getter
  get info() {
    return `${this.name} (${this.age})`;
  }

  // Setter
  set birthday(year) {
    this.age = new Date().getFullYear() - year;
  }
}

class Employee extends Person {
  constructor(name, age, company, salary) {
    super(name, age); // Call parent constructor!
    this.company = company;
    this.salary  = salary;
  }

  // Override parent method
  greet() {
    super.greet(); // Call parent's greet first!
    console.log(`💼 I work at ${this.company}`);
  }

  introduce() {
    console.log(`🤝 ${this.name} | ${this.company} | ₹${this.salary}/month`);
  }
}

class Manager extends Employee {
  constructor(name, age, company, salary, team) {
    super(name, age, company, salary);
    this.team = team;
  }

  greet() {
    super.greet();
    console.log(`👥 I manage a team of ${this.team} people.`);
  }
}

const person1  = new Person("Raj", 30);
const emp1     = new Employee("Priya", 27, "Google", 150000);
const manager1 = new Manager("Abhishek", 32, "Microsoft", 250000, 8);

console.log("--- Person ---");
person1.greet();
console.log("Info getter:", person1.info);

console.log("\n--- Employee ---");
emp1.greet();
emp1.introduce();

console.log("\n--- Manager ---");
manager1.greet();

// Prove they're all prototypes under the hood:
console.log("\n🔬 Under the hood:");
console.log("emp1.greet === Employee.prototype.greet:", emp1.greet === Employee.prototype.greet);
console.log("emp1 instanceof Person:", emp1 instanceof Person);

// ──────────────────────────────────────────
// 🛠️ Object.create() — Direct prototype setting
// ──────────────────────────────────────────

const animalProto = {
  speak() {
    console.log(`\n🐾 ${this.name} says ${this.sound}`);
  },
  eat(food) {
    console.log(`🍖 ${this.name} eats ${food}`);
  },
};

const lion = Object.create(animalProto);
lion.name  = "Simba";
lion.sound = "ROAR";
lion.speak();
lion.eat("meat");

// ============================================================
// 🧪 YOUR CODING CHALLENGES - TRY THESE!
// ============================================================

// 🟡 CHALLENGE 1 (Easy):
// Create a `Shape` constructor with properties: color, filled
// Add to prototype: describe() → "A [color] [shape] that is [filled/not filled]"
// Create Circle (radius) and Rectangle (width, height) that inherit from Shape.
// Add area() to each.

// 🟠 CHALLENGE 2 (Medium):
// Using ES6 Classes, build:
// class BankAccount { constructor(owner, balance) }
//   - deposit(amount)
//   - withdraw(amount) — check balance
//   - getStatement()   — show transaction history
// class SavingsAccount extends BankAccount
//   - add interestRate property
//   - addInterest() — adds interest to balance
//   - Override getStatement() to also show interest earned

// 🔴 CHALLENGE 3 (Hard):
// Build an OOP-based School Management System:
// class Person { name, age, id }
// class Student extends Person { grade, subjects[], addSubject(), getReport() }
// class Teacher extends Person { subject, salary, teach(className) }
// class Classroom { teacher, students[], addStudent(), startClass() }
// class School { classrooms[], teachers[], enroll(student, className) }
// Create a school with 2 classrooms, 2 teachers, 5 students!
