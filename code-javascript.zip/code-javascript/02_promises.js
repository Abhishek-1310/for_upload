// ============================================================
// 🎬 CHAPTER 2: PROMISES
// 📖 Story: You book a cab. Driver PROMISES to arrive.
//           Either he ARRIVES ✅ or CANCELS ❌
// ============================================================

// ╔══════════════════════════════════════════════════════════╗
// ║  ❓ WHY DO WE NEED PROMISES?                             ║
// ╠══════════════════════════════════════════════════════════╣
// ║                                                          ║
// ║  🔴 THE PROBLEM (without promises — CALLBACK HELL):      ║
// ║  Callbacks work, BUT when you need to do multiple async  ║
// ║  operations ONE AFTER ANOTHER, the code becomes a        ║
// ║  deeply nested mess called "Callback Hell" 😱            ║
// ║                                                          ║
// ║  // ❌ WITHOUT PROMISES (callback hell — unreadable!)
// ║  login(user, function() {                                ║
// ║    fetchProfile(user, function() {                       ║
// ║      fetchPosts(user, function() {                       ║
// ║        fetchComments(posts, function() {                 ║
// ║          // 😱 Impossible to read, debug, or maintain!   ║
// ║        })                                                ║
// ║      })                                                  ║
// ║    })                                                    ║
// ║  })                                                      ║
// ║                                                          ║
// ║  Problems with callbacks:                                ║
// ║  → Error handling is messy (repeated in every callback)  ║
// ║  → Can't run multiple async tasks in parallel easily     ║
// ║  → Code reads bottom-to-top, not top-to-bottom           ║
// ║  → Hard to debug — stack traces are confusing            ║
// ║                                                          ║
// ║  ✅ THE SOLUTION (with promises):                        ║
// ║  // ✅ WITH PROMISES (clean chaining!)                   ║
// ║  login(user)                                             ║
// ║    .then(fetchProfile)                                   ║
// ║    .then(fetchPosts)                                     ║
// ║    .then(fetchComments)                                  ║
// ║    .catch(handleAllErrors) // ONE place for all errors!  ║
// ║                                                          ║
// ║  🎯 WHAT PROMISES UNLOCK:                                ║
// ║  → Clean, readable async code (top-to-bottom flow)       ║
// ║  → ONE .catch() handles ALL errors in the chain          ║
// ║  → Promise.all()  — run multiple tasks IN PARALLEL       ║
// ║  → Promise.race() — get the FASTEST result               ║
// ║  → Foundation for async/await (next chapter!)            ║
// ╚══════════════════════════════════════════════════════════╝

// A Promise has 3 states:
// ⏳ PENDING   → waiting for result
// ✅ FULFILLED → success (resolve)
// ❌ REJECTED  → failed (reject)

// ──────────────────────────────────────────
// 🔰 BASIC PROMISE
// ──────────────────────────────────────────

const cabBooking = new Promise(function (resolve, reject) {
  const driverFound = true; // Change to false to see rejection!

  if (driverFound) {
    resolve("🚗 Driver Raj is on his way! ETA: 5 mins");
  } else {
    reject("❌ No drivers available. Booking cancelled!");
  }
});

cabBooking
  .then(function (message) {
    console.log("✅ Success:", message);
  })
  .catch(function (error) {
    console.log("❌ Error:", error);
  })
  .finally(function () {
    console.log("🏁 Booking process completed (success or fail).");
  });

// ──────────────────────────────────────────
// 🔥 REAL LIFE: Fetch User Data from API
// ──────────────────────────────────────────

function getUserData(userId) {
  return new Promise(function (resolve, reject) {
    console.log(`\n🔍 Fetching user with ID: ${userId}...`);

    // Simulate DB call with setTimeout
    setTimeout(function () {
      const users = {
        1: { name: "Abhishek", age: 25, city: "Mumbai" },
        2: { name: "Priya", age: 22, city: "Delhi" },
      };

      const user = users[userId];
      if (user) {
        resolve(user); // ✅ Found!
      } else {
        reject(`User with ID ${userId} not found!`); // ❌ Not found!
      }
    }, 1500);
  });
}

getUserData(1)
  .then(function (user) {
    console.log("👤 User Found:", user);
    return user.name; // Chaining! Pass data to next .then()
  })
  .then(function (name) {
    console.log(`👋 Hello, ${name}!`);
  })
  .catch(function (err) {
    console.log("❌ Error:", err);
  });

getUserData(99) // Non-existent user
  .then((user) => console.log(user))
  .catch((err) => console.log("\n❌ Caught:", err));

// ──────────────────────────────────────────
// 🚀 PROMISE CHAINING
// Story: Order food → Pay bill → Get receipt (one after another)
// ──────────────────────────────────────────

function orderFood(item) {
  return new Promise((resolve) => {
    setTimeout(() => resolve(`🍽️  ${item} ordered!`), 1000);
  });
}

function payBill(amount) {
  return new Promise((resolve) => {
    setTimeout(() => resolve(`💳 Paid ₹${amount}!`), 1000);
  });
}

function getReceipt(info) {
  return new Promise((resolve) => {
    setTimeout(() => resolve(`🧾 Receipt: ${info}`), 500);
  });
}

orderFood("Biryani")
  .then((msg) => {
    console.log("\n" + msg);
    return payBill(250);
  })
  .then((msg) => {
    console.log(msg);
    return getReceipt("Biryani - ₹250");
  })
  .then((receipt) => {
    console.log(receipt);
    console.log("🎉 Done! Clean chaining vs callback hell!");
  });

// ──────────────────────────────────────────
// ⚡ Promise.all() — Run ALL promises TOGETHER
// Story: Order Pizza, Coke & Garlic Bread at same time!
// ──────────────────────────────────────────

const pizza = new Promise((resolve) =>
  setTimeout(() => resolve("🍕 Pizza Ready!"), 2000)
);
const coke = new Promise((resolve) =>
  setTimeout(() => resolve("🥤 Coke Ready!"), 1000)
);
const bread = new Promise((resolve) =>
  setTimeout(() => resolve("🥖 Garlic Bread Ready!"), 1500)
);

Promise.all([pizza, coke, bread]).then(function (results) {
  console.log("\n🎊 All items ready:", results);
  // Waits for ALL to finish, then gives all results together
});

// ──────────────────────────────────────────
// ⚡ Promise.race() — FIRST one wins!
// Story: Two drivers racing to reach you first!
// ──────────────────────────────────────────

const driver1 = new Promise((resolve) =>
  setTimeout(() => resolve("🚗 Driver1 arrived first!"), 2000)
);
const driver2 = new Promise((resolve) =>
  setTimeout(() => resolve("🏎️  Driver2 arrived first!"), 1000)
);

Promise.race([driver1, driver2]).then(function (winner) {
  console.log("\n🏆 Race winner:", winner); // Driver2 wins (1000ms < 2000ms)
});

// ──────────────────────────────────────────
// ⚡ Promise.allSettled() — Get ALL results (success OR fail)
// ──────────────────────────────────────────

const p1 = Promise.resolve("✅ Server 1 OK");
const p2 = Promise.reject("❌ Server 2 Failed");
const p3 = Promise.resolve("✅ Server 3 OK");

Promise.allSettled([p1, p2, p3]).then(function (results) {
  console.log("\n📊 All Server Status:");
  results.forEach((result) => {
    if (result.status === "fulfilled") {
      console.log("  ✅", result.value);
    } else {
      console.log("  ❌", result.reason);
    }
  });
});

// ============================================================
// 🧪 YOUR CODING CHALLENGES - TRY THESE!
// ============================================================

// 🟡 CHALLENGE 1 (Easy):
// Create a promise `loginUser(username, password)`
// Resolve if username="admin" and password="1234"
// Reject with "Invalid credentials" otherwise.

// 🟠 CHALLENGE 2 (Medium):
// Create 3 promises:
//   - fetchUserName() → resolves "Abhishek" after 1s
//   - fetchUserAge()  → resolves 25 after 2s
//   - fetchUserCity() → resolves "Mumbai" after 1.5s
// Use Promise.all() to get all data together and print the profile.

// 🔴 CHALLENGE 3 (Hard):
// Simulate an E-commerce order system using Promise chaining:
// 1. checkStock(item)      → resolve if in stock, reject if not
// 2. processPayment(price) → resolve if payment OK
// 3. shipOrder(address)    → resolve with tracking ID
// 4. Handle all errors with .catch()
