// ============================================================
// 🎬 CHAPTER 14: DEBOUNCE & THROTTLE
// 📖 Story:
//   DEBOUNCE  = You stop typing in a search box.
//               The search fires ONLY after you STOP for 500ms.
//               (Like a waiter who waits until you finish ordering!)
//
//   THROTTLE  = You scroll a page. The handler fires
//               at MOST once every 200ms, no matter how fast you scroll.
//               (Like a speed governor on a car — limits the rate!)
// ============================================================

// ╔══════════════════════════════════════════════════════════╗
// ║  ❓ WHY DO WE NEED DEBOUNCE & THROTTLE?                 ║
// ╠══════════════════════════════════════════════════════════╣
// ║                                                          ║
// ║  🔴 THE PROBLEM (without them):                         ║
// ║  Some events fire HUNDREDS of times per second:         ║
// ║  → Typing in a search box: 1 API call per keystroke!   ║
// ║  → Scrolling a page: 60 events/second                   ║
// ║  → Resizing window: fires continuously                  ║
// ║  → Mouse moving: fires on every pixel                   ║
// ║                                                          ║
// ║  // ❌ WITHOUT debounce — API called on EVERY keystroke ║
// ║  searchInput.addEventListener("input", () => {          ║
// ║    fetch(`/api/search?q=${input.value}`); // 🔥 spam!   ║
// ║  });                                                     ║
// ║  // Type "javascript" = 10 API calls! Expensive + slow  ║
// ║                                                          ║
// ║  🎯 WHAT THEY UNLOCK:                                   ║
// ║  → Performance: fewer API calls, less computation       ║
// ║  → Better UX: smooth scrolling, instant feel            ║
// ║  → Server protection: prevent accidental DDoS           ║
// ║  → Asked in 80% of frontend interviews — MUST KNOW!     ║
// ╚══════════════════════════════════════════════════════════╝

// ══════════════════════════════════════════
// PART 1: DEBOUNCE
// "Wait until things CALM DOWN, then act"
// ══════════════════════════════════════════

// ──────────────────────────────────────────
// 🔰 BUILD DEBOUNCE FROM SCRATCH
// ──────────────────────────────────────────

console.log("=== DEBOUNCE ===\n");

function debounce(fn, delay) {
  let timerId; // stored in CLOSURE!

  return function (...args) {
    // Every time the returned function is called:
    // 1. Cancel the previous pending timer
    clearTimeout(timerId);

    // 2. Set a new timer — only fires if no call happens in `delay` ms
    timerId = setTimeout(() => {
      fn.apply(this, args); // call original fn with correct `this` and args
    }, delay);
  };
}

// ──────────────────────────────────────────
// 🌍 REAL LIFE 1: Search Box
// Problem: API called on EVERY keystroke — expensive!
// Solution: Call API only when user STOPS typing for 500ms
// ──────────────────────────────────────────

function searchAPI(query) {
  console.log(`🔍 API Called with: "${query}" at ${new Date().toLocaleTimeString()}`);
}

const debouncedSearch = debounce(searchAPI, 500);

// Simulate typing "js" quickly:
console.log("⌨️  Simulating typing 'js' quickly...");
debouncedSearch("j");      // cancelled
debouncedSearch("js");     // this one fires after 500ms (last call wins!)

// Simulate typing "python" with pauses:
setTimeout(() => {
  console.log("\n⌨️  Simulating typing 'python' with pause...");
  debouncedSearch("p");      // cancelled by next keystroke
  debouncedSearch("py");     // cancelled
  debouncedSearch("pyt");    // cancelled
  // User paused! This one fires:
  setTimeout(() => debouncedSearch("python"), 600); // separate burst
}, 1000);

// ──────────────────────────────────────────
// 🌍 REAL LIFE 2: Form Validation
// Validate email ONLY after user finishes typing
// ──────────────────────────────────────────

function validateEmail(email) {
  const isValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  console.log(`📧 Validating "${email}": ${isValid ? "✅ Valid" : "❌ Invalid"}`);
}

const debouncedValidate = debounce(validateEmail, 400);

setTimeout(() => {
  console.log("\n📝 Simulating email input...");
  debouncedValidate("a");
  debouncedValidate("ab");
  debouncedValidate("abhi");
  debouncedValidate("abhi@");
  debouncedValidate("abhi@gmail");
  setTimeout(() => debouncedValidate("abhi@gmail.com"), 500); // fires!
}, 2200);

// ──────────────────────────────────────────
// 🔥 DEBOUNCE WITH IMMEDIATE (Leading Edge)
// Fire IMMEDIATELY on first call, then debounce
// Use case: Submit button — prevent double-click
// ──────────────────────────────────────────

function debounceImmediate(fn, delay, immediate = false) {
  let timerId;

  return function (...args) {
    const callNow = immediate && !timerId; // first call when immediate=true

    clearTimeout(timerId);

    timerId = setTimeout(() => {
      timerId = null; // reset so next call can fire immediately again
      if (!immediate) fn.apply(this, args);
    }, delay);

    if (callNow) fn.apply(this, args); // fire immediately on leading edge!
  };
}

const handleSubmit = debounceImmediate((data) => {
  console.log("\n🚀 Form submitted with:", data);
}, 1000, true); // immediate = true

setTimeout(() => {
  console.log("\n🖱️  Double-click simulation:");
  handleSubmit("Form Data 1"); // ✅ fires immediately!
  handleSubmit("Form Data 2"); // ❌ ignored (within 1000ms)
  handleSubmit("Form Data 3"); // ❌ ignored (within 1000ms)
}, 3500);

// ══════════════════════════════════════════
// PART 2: THROTTLE
// "Fire at most ONCE per time window"
// ══════════════════════════════════════════

console.log("\n\n=== THROTTLE ===\n");

// ──────────────────────────────────────────
// 🔰 BUILD THROTTLE FROM SCRATCH
// ──────────────────────────────────────────

function throttle(fn, limit) {
  let lastCall  = 0; // timestamp of last execution
  let timerId;

  return function (...args) {
    const now     = Date.now();
    const elapsed = now - lastCall;

    if (elapsed >= limit) {
      // Enough time has passed — call immediately!
      lastCall = now;
      fn.apply(this, args);
    } else {
      // Too soon — schedule for the remainder of the window
      clearTimeout(timerId);
      timerId = setTimeout(() => {
        lastCall = Date.now();
        fn.apply(this, args);
      }, limit - elapsed);
    }
  };
}

// ──────────────────────────────────────────
// 🌍 REAL LIFE 1: Window Scroll Handler
// Without throttle: fires 60 times/second!
// With throttle: fires at most once every 200ms
// ──────────────────────────────────────────

function handleScroll(position) {
  console.log(`📜 Scroll position: ${position}px at ${Date.now() % 10000}ms`);
}

const throttledScroll = throttle(handleScroll, 200);

// Simulate rapid scroll events:
setTimeout(() => {
  console.log("📜 Simulating rapid scroll (10 events in 500ms):");
  let pos = 0;
  const scrollSim = setInterval(() => {
    pos += 50;
    throttledScroll(pos); // fires at most every 200ms
    if (pos >= 500) clearInterval(scrollSim);
  }, 50); // 50ms between events = 20 events/sec
}, 4500);

// ──────────────────────────────────────────
// 🌍 REAL LIFE 2: API Rate Limiting
// Story: Stock price API allows max 1 call per second
// ──────────────────────────────────────────

function fetchStockPrice(symbol) {
  const fakePrice = (Math.random() * 1000 + 100).toFixed(2);
  console.log(`📈 ${symbol}: ₹${fakePrice} (fetched at ${new Date().toISOString().slice(11, 19)})`);
}

const throttledStockFetch = throttle(fetchStockPrice, 1000); // max 1/second

setTimeout(() => {
  console.log("\n📈 Stock price fetching (throttled to 1/second):");
  throttledStockFetch("RELIANCE");
  throttledStockFetch("TCS");        // ignored (too fast)
  throttledStockFetch("INFOSYS");    // ignored (too fast)

  setTimeout(() => throttledStockFetch("HDFC"), 1100);    // ✅ fires (after 1s)
  setTimeout(() => throttledStockFetch("WIPRO"), 1200);   // ❌ ignored
  setTimeout(() => throttledStockFetch("TATA"), 2200);    // ✅ fires (after 2s)
}, 6000);

// ──────────────────────────────────────────
// 🆚 DEBOUNCE vs THROTTLE — When to use which?
// ──────────────────────────────────────────

console.log(`
╔═════════════════════════════════════════════════════════════╗
║               DEBOUNCE  vs  THROTTLE                        ║
╠══════════════════╦══════════════════════════════════════════╣
║  DEBOUNCE        ║  THROTTLE                                ║
╠══════════════════╬══════════════════════════════════════════╣
║ Waits for quiet  ║ Fires at regular intervals               ║
║ period to end    ║                                          ║
╠══════════════════╬══════════════════════════════════════════╣
║ USE FOR:         ║ USE FOR:                                 ║
║ → Search input   ║ → Scroll events                         ║
║ → Form validate  ║ → Window resize                         ║
║ → Auto-save      ║ → Mouse move                            ║
║ → Button submit  ║ → API rate limiting                     ║
║ → Spell check    ║ → Game loop updates                     ║
╠══════════════════╬══════════════════════════════════════════╣
║ Result: Fires    ║ Result: Fires at most ONCE per           ║
║ ONCE after the   ║ time window, regardless of              ║
║ last event       ║ how many events happened                 ║
╚══════════════════╩══════════════════════════════════════════╝
`);

// ──────────────────────────────────────────
// 🎯 QUICK VISUAL COMPARISON
// ──────────────────────────────────────────

// Events:    |--1--|--2--|--3--|--4--|--5--|   (rapid events)
//
// DEBOUNCE:                              |*|  (fires ONCE at end)
//
// THROTTLE:  |*|         |*|         |*|     (fires at intervals)

// ══════════════════════════════════════════
// BONUS: Using lodash (production approach)
// ══════════════════════════════════════════

// In real projects you often use lodash:
// import { debounce, throttle } from 'lodash';
// const debouncedFn = debounce(myFn, 500);
// const throttledFn = throttle(myFn, 200);
// But interviews want you to BUILD it from scratch!

// ============================================================
// 🧪 YOUR CODING CHALLENGES - TRY THESE!
// ============================================================

// 🟡 CHALLENGE 1 (Easy):
// Create a debounced version of a `saveDocument(content)` function.
// It should only save when user STOPS typing for 800ms.
// Simulate typing by calling it 5 times quickly,
// then once after 1 second. Verify only 2 saves happen.

// 🟠 CHALLENGE 2 (Medium):
// Build a throttled `trackMousePosition(x, y)` function
// that logs mouse coordinates at most every 100ms.
// Simulate 20 rapid mouse events every 10ms.
// Count how many times the actual tracking function fired.
// It should be far fewer than 20!

// 🔴 CHALLENGE 3 (Hard):
// Build a complete `RateLimiter` class using throttle:
// class RateLimiter {
//   constructor(maxCalls, windowMs) { ... }
//   execute(fn, ...args) → runs fn if within rate limit
//                        → queues it if over limit
//   getStats() → returns { called, queued, dropped }
// }
// Test: maxCalls=3 per 1000ms, try to call 10 times rapidly.
// Verify: first 3 run immediately, next are queued or dropped.
