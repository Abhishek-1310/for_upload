// ============================================================
// 🎬 CHAPTER 7: CURRYING
// 📖 Story: A VENDING MACHINE 🍫
//           You don't put all coins at once.
//           You feed coins ONE AT A TIME until you get your snack!
//           That's CURRYING — one argument at a time!
// ============================================================

// ╔══════════════════════════════════════════════════════════╗
// ║  ❓ WHY DO WE NEED CURRYING?                             ║
// ╠══════════════════════════════════════════════════════════╣
// ║                                                          ║
// ║  🔴 THE PROBLEM (without currying):                      ║
// ║  Normal functions need ALL arguments every single time   ║
// ║  you call them — even when some args are always the same.║
// ║  This leads to repetition and tightly coupled code.      ║
// ║                                                          ║
// ║  // ❌ WITHOUT currying — repeat the same args every time
// ║  function calcPrice(discount, tax, price) {              ║
// ║    return price - (price*discount/100) + (price*tax/100);║
// ║  }                                                       ║
// ║  calcPrice(20, 18, 1000); // premium user                ║
// ║  calcPrice(20, 18, 2000); // discount & tax REPEATED!    ║
// ║  calcPrice(20, 18, 3000); // every. single. time. 😤     ║
// ║                                                          ║
// ║  // ❌ Also: can't reuse partial logic                   ║
// ║  // If you want a "20% off calculator" you have to       ║
// ║  // always pass 20 as first arg — NO way to lock it in.  ║
// ║                                                          ║
// ║  ✅ THE SOLUTION (with currying):                        ║
// ║  // ✅ Lock in discount & tax ONCE, reuse for any price  ║
// ║  const premiumCalc = calcPrice(20)(18); // locked in!    ║
// ║  premiumCalc(1000); // just pass price!                  ║
// ║  premiumCalc(2000); // clean & reusable                  ║
// ║  premiumCalc(3000); // no repetition 🎉                  ║
// ║                                                          ║
// ║  🎯 WHAT CURRYING UNLOCKS:                               ║
// ║  → PARTIAL APPLICATION — pre-fill some args, reuse later ║
// ║  → Create SPECIALIZED functions from generic ones        ║
// ║  → Build reusable PIPELINES (compose/pipe pattern)       ║
// ║  → Cleaner, DRY (Don't Repeat Yourself) code             ║
// ║  → Used heavily in functional programming & Redux        ║
// ║  → Makes code more TESTABLE — test one arg at a time     ║
// ╚══════════════════════════════════════════════════════════╝

// CURRYING = Converting a function with multiple args into
//            a sequence of functions each taking ONE argument.
// f(a, b, c) → f(a)(b)(c)

// ──────────────────────────────────────────
// 🔰 BASIC CURRYING
// ──────────────────────────────────────────

// Normal function
function add(a, b, c) {
  return a + b + c;
}
console.log("Normal add:", add(1, 2, 3)); // 6

// Curried version
function curriedAdd(a) {
  return function (b) {
    return function (c) {
      return a + b + c;
    };
  };
}
console.log("Curried add:", curriedAdd(1)(2)(3)); // 6

// Arrow function — cleaner curried version
const curriedAddArrow = (a) => (b) => (c) => a + b + c;
console.log("Arrow curried:", curriedAddArrow(1)(2)(3)); // 6

// ──────────────────────────────────────────
// 🍕 REAL LIFE: Pizza Order System
// Story: Select Size → then Crust → then Topping
// ──────────────────────────────────────────

const orderPizza = (size) => (crust) => (topping) =>
  `🍕 ${size} pizza with ${crust} crust and ${topping}!`;

// Full order at once
console.log("\n" + orderPizza("Large")("Thin")("Cheese"));

// PARTIAL APPLICATION — lock in some args, decide rest later!
const largePizza       = orderPizza("Large");          // size locked!
const largeThinPizza   = largePizza("Thin");            // crust locked!
const largeCheesePizza = largeThinPizza("Extra Cheese"); // final order!

console.log(largeCheesePizza);
console.log(largeThinPizza("Mushroom"));
console.log(largeThinPizza("Pepperoni"));

// ──────────────────────────────────────────
// 💼 REAL LIFE: Discount Calculator
// Story: Different users get different discount levels
// ──────────────────────────────────────────

const calculatePrice = (discount) => (tax) => (price) => {
  const afterDiscount = price - (price * discount) / 100;
  const finalPrice    = afterDiscount + (afterDiscount * tax) / 100;
  return Math.round(finalPrice);
};

// Create pre-configured calculators for different user types
const premiumMember = calculatePrice(20); // 20% discount
const regularMember = calculatePrice(10); // 10% discount
const newUser       = calculatePrice(5);  // 5% discount

// Apply GST (18%)
const premiumWithGST = premiumMember(18);
const regularWithGST = regularMember(18);

console.log("\n💰 Price Calculator:");
console.log("Original price: ₹1000");
console.log("  Premium member:", premiumWithGST(1000)); // 20% off + 18% tax
console.log("  Regular member:", regularWithGST(1000)); // 10% off + 18% tax
console.log("  New user:      ", newUser(18)(1000));     // 5% off + 18% tax

// ──────────────────────────────────────────
// 🛠️  GENERIC CURRY FUNCTION
// (Converts ANY function into curried form!)
// ──────────────────────────────────────────

function curry(fn) {
  return function curried(...args) {
    if (args.length >= fn.length) {
      // Got all required args — call the original function!
      return fn.apply(this, args);
    } else {
      // Need more args — return a function to collect more
      return function (...moreArgs) {
        return curried.apply(this, args.concat(moreArgs));
      };
    }
  };
}

// Now curry ANY function!
function multiply(a, b, c) {
  return a * b * c;
}

const curriedMultiply = curry(multiply);

console.log("\n🔢 Generic Curry:");
console.log(curriedMultiply(2)(3)(4));     // 24
console.log(curriedMultiply(2, 3)(4));     // 24 — can mix!
console.log(curriedMultiply(2)(3, 4));     // 24 — can mix!
console.log(curriedMultiply(2, 3, 4));     // 24 — all at once!

// ──────────────────────────────────────────
// 🎯 REAL LIFE: URL Builder
// Story: Build API URLs with reusable base parts
// ──────────────────────────────────────────

const buildURL = curry(function (baseURL, version, endpoint, id) {
  return `${baseURL}/${version}/${endpoint}/${id}`;
});

// Reusable URL factories
const apiV1 = buildURL("https://api.myapp.com")("v1");
const apiV2 = buildURL("https://api.myapp.com")("v2");

const userAPI   = apiV1("users");
const productAPI = apiV1("products");

console.log("\n🌐 URL Builder:");
console.log(userAPI(42));          // https://api.myapp.com/v1/users/42
console.log(userAPI(99));          // https://api.myapp.com/v1/users/99
console.log(productAPI(101));      // https://api.myapp.com/v1/products/101
console.log(apiV2("orders")(55));  // https://api.myapp.com/v2/orders/55

// ──────────────────────────────────────────
// 🔗 CURRYING + COMPOSE (ADVANCED)
// Story: Process data through a pipeline (like an assembly line!)
// ──────────────────────────────────────────

const pipe = (...fns) => (value) => fns.reduce((v, f) => f(v), value);

const double    = (x) => x * 2;
const addTen    = (x) => x + 10;
const square    = (x) => x * x;
const toString  = (x) => `Result: ${x}`;

const process = pipe(double, addTen, square, toString);

console.log("\n⚙️  Pipeline Processing:");
console.log(process(3)); // (3*2=6) → (6+10=16) → (16²=256) → "Result: 256"
console.log(process(5)); // (5*2=10) → (10+10=20) → (20²=400) → "Result: 400"

// ──────────────────────────────────────────
// 📧 REAL LIFE: Email Validator (curried)
// ──────────────────────────────────────────

const validate = (rule) => (errorMsg) => (value) =>
  rule(value) ? { valid: true, value } : { valid: false, error: errorMsg };

const isNotEmpty  = validate((v) => v.trim().length > 0)("Field cannot be empty!");
const isEmail     = validate((v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v))("Invalid email format!");
const isLongEnough = validate((v) => v.length >= 8)("Minimum 8 characters required!");

console.log("\n📧 Form Validation:");
console.log(isNotEmpty(""));
console.log(isNotEmpty("Abhishek"));
console.log(isEmail("notanemail"));
console.log(isEmail("abhishek@gmail.com"));
console.log(isLongEnough("hi"));
console.log(isLongEnough("mypassword123"));

// ============================================================
// 🧪 YOUR CODING CHALLENGES - TRY THESE!
// ============================================================

// 🟡 CHALLENGE 1 (Easy):
// Convert this function to curried form:
// function greet(greeting, name) { return `${greeting}, ${name}!`; }
// So that: greet("Hello")("Abhishek") → "Hello, Abhishek!"
// Also create: const sayNamaste = greet("Namaste");
// Use sayNamaste with 3 different names.

// 🟠 CHALLENGE 2 (Medium):
// Build a curried `logger` function:
// logger(level)(module)(message)
// Example: logger("INFO")("Auth")("User logged in") → "[INFO] [Auth]: User logged in"
// Create pre-built loggers:
//   const authLogger = logger("INFO")("Auth")
//   const dbLogger   = logger("ERROR")("Database")
// Use them to log 3 different messages each.

// 🔴 CHALLENGE 3 (Hard):
// Build a curried `queryBuilder` for SQL-like queries:
// query(table)(conditions)(fields)
// Example: query("users")({ age: 25, city: "Mumbai" })(["name", "email"])
// Should return: "SELECT name, email FROM users WHERE age=25 AND city=Mumbai"
// Handle multiple conditions and fields generically.
