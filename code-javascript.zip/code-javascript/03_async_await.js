// ============================================================
// 🎬 CHAPTER 3: ASYNC / AWAIT
// 📖 Story: You're a chef. You WAIT for ingredients before cooking.
//           async/await makes async code look like normal code!
// ============================================================

// ╔══════════════════════════════════════════════════════════╗
// ║  ❓ WHY DO WE NEED ASYNC / AWAIT?                        ║
// ╠══════════════════════════════════════════════════════════╣
// ║                                                          ║
// ║  🔴 THE PROBLEM (without async/await):                   ║
// ║  Promises are cleaner than callbacks, BUT chaining many  ║
// ║  .then() blocks still looks like "Promise Hell" and is   ║
// ║  hard to debug when errors happen mid-chain.             ║
// ║                                                          ║
// ║  // ❌ WITHOUT async/await (promise chain — OK but messy)
// ║  fetchUser(id)                                           ║
// ║    .then(user => fetchOrders(user.id))                   ║
// ║    .then(orders => fetchDetails(orders[0].id))           ║
// ║    .then(details => {                                    ║
// ║       // hard to access `user` here — it's out of scope! ║
// ║       console.log(details);                              ║
// ║    })                                                    ║
// ║    .catch(err => console.log(err));                      ║
// ║                                                          ║
// ║  Big problems with .then() chains:                       ║
// ║  → Variables from earlier .then() are OUT OF SCOPE later ║
// ║  → Conditional logic inside chains is very awkward       ║
// ║  → Stack traces in errors are hard to understand         ║
// ║  → Looks nothing like normal synchronous code            ║
// ║                                                          ║
// ║  ✅ THE SOLUTION (with async/await):                     ║
// ║  // ✅ WITH async/await (reads like normal code!)        ║
// ║  async function loadOrder(id) {                          ║
// ║    const user    = await fetchUser(id);     // readable! ║
// ║    const orders  = await fetchOrders(user.id);           ║
// ║    const details = await fetchDetails(orders[0].id);     ║
// ║    console.log(user, orders, details); // ALL in scope!  ║
// ║  }                                                       ║
// ║                                                          ║
// ║  🎯 WHAT ASYNC/AWAIT UNLOCKS:                            ║
// ║  → Async code that READS like synchronous code           ║
// ║  → All variables stay in the SAME scope                  ║
// ║  → Use normal try/catch for error handling               ║
// ║  → Easy to use loops (for...of) with async operations    ║
// ║  → Debugging is simple — breakpoints work normally       ║
// ║  → Industry standard for all modern JS/Node.js code      ║
// ╚══════════════════════════════════════════════════════════╝

// async  → marks a function as asynchronous (always returns a Promise)
// await  → PAUSES the function until the Promise resolves
//          (only works INSIDE an async function)

// ──────────────────────────────────────────
// 🔰 BASIC ASYNC/AWAIT
// ──────────────────────────────────────────

// Without async/await (Promise way)
function getIngredient_old() {
  return new Promise((resolve) => {
    setTimeout(() => resolve("🧅 Onions"), 1000);
  });
}

// WITH async/await (much cleaner!)
async function cookFood() {
  console.log("👨‍🍳 Chef started cooking...");

  const ingredient = await getIngredient_old(); // WAITS here!
  console.log("✅ Got ingredient:", ingredient);

  console.log("🍳 Cooking with", ingredient);
  console.log("🍜 Food is ready!");
}

cookFood();

// ──────────────────────────────────────────
// 🔥 REAL LIFE EXAMPLE: Login System
// ──────────────────────────────────────────

function fakeAPICall(data, delay) {
  return new Promise((resolve) => {
    setTimeout(() => resolve(data), delay);
  });
}

async function loginSystem() {
  try {
    console.log("\n🔐 Starting login process...");

    // Step 1: Validate user
    const user = await fakeAPICall(
      { id: 1, name: "Abhishek", role: "admin" },
      1000
    );
    console.log("👤 User validated:", user.name);

    // Step 2: Fetch permissions
    const permissions = await fakeAPICall(
      ["read", "write", "delete"],
      800
    );
    console.log("🔑 Permissions loaded:", permissions);

    // Step 3: Load dashboard
    const dashboard = await fakeAPICall(
      "Welcome to Admin Dashboard!",
      500
    );
    console.log("🖥️ ", dashboard);

    console.log("🎉 Login successful!");
  } catch (error) {
    console.log("❌ Login failed:", error);
  }
}

loginSystem();

// ──────────────────────────────────────────
// 🛑 ERROR HANDLING with try/catch
// Story: You order food online, but payment fails!
// ──────────────────────────────────────────

function processPayment(amount) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (amount > 0 && amount < 10000) {
        resolve(`✅ Payment of ₹${amount} successful!`);
      } else {
        reject(`❌ Payment of ₹${amount} failed! Invalid amount.`);
      }
    }, 1000);
  });
}

async function placeOrder(item, price) {
  console.log(`\n🛒 Placing order for ${item}...`);

  try {
    const paymentStatus = await processPayment(price);
    console.log(paymentStatus);
    console.log("📦 Order placed! Delivery in 3 days.");
  } catch (error) {
    console.log(error);
    console.log("🔄 Please try again with a valid amount.");
  }
}

placeOrder("Laptop", 45000);  // ❌ fails (>10000)
placeOrder("Book", 499);      // ✅ succeeds

// ──────────────────────────────────────────
// ⚡ PARALLEL EXECUTION with async/await
// Story: Order Pizza AND Coke at the SAME TIME (don't wait for pizza before ordering coke!)
// ──────────────────────────────────────────

async function orderItemSequential() {
  console.log("\n⏱️  Sequential (SLOW - waits for each):");
  console.time("sequential");
  
  const pizza = await fakeAPICall("🍕 Pizza", 2000);   // Waits 2s
  const coke  = await fakeAPICall("🥤 Coke", 1000);    // Then waits 1s
  
  console.log(pizza, "&", coke);
  console.timeEnd("sequential"); // ~3 seconds total
}

async function orderItemParallel() {
  console.log("\n⚡ Parallel (FAST - runs together):");
  console.time("parallel");
  
  const [pizza, coke] = await Promise.all([
    fakeAPICall("🍕 Pizza", 2000),
    fakeAPICall("🥤 Coke", 1000),
  ]);
  
  console.log(pizza, "&", coke);
  console.timeEnd("parallel"); // ~2 seconds total (max of the two)
}

orderItemSequential();
setTimeout(orderItemParallel, 4000); // Run after sequential finishes

// ──────────────────────────────────────────
// 🔁 async/await in LOOPS
// Story: Process 5 customer orders one by one
// ──────────────────────────────────────────

async function processAllOrders() {
  const orders = ["Order#1", "Order#2", "Order#3"];

  console.log("\n📋 Processing all orders...");

  for (const order of orders) {
    // Use for...of with await (NOT forEach!)
    const result = await fakeAPICall(`✅ ${order} processed`, 500);
    console.log(result);
  }

  console.log("🎊 All orders done!");
}

setTimeout(processAllOrders, 8000);

// ──────────────────────────────────────────
// 💡 async function ALWAYS returns a Promise
// ──────────────────────────────────────────

async function getName() {
  return "Abhishek"; // Automatically wrapped in Promise.resolve()
}

getName().then((name) => console.log("\n👋 My name is:", name));

// ============================================================
// 🧪 YOUR CODING CHALLENGES - TRY THESE!
// ============================================================

// 🟡 CHALLENGE 1 (Easy):
// Write an async function `getWeather(city)`
// It should simulate an API call (use setTimeout + Promise)
// and return weather info like { city: "Mumbai", temp: 32, condition: "Sunny" }
// Print the result using await.

// 🟠 CHALLENGE 2 (Medium):
// Write an async function `getUserProfile(userId)` that:
// Step 1: await fetchUser(userId)       → returns { name, email }
// Step 2: await fetchPosts(userId)      → returns array of posts
// Step 3: await fetchFollowers(userId)  → returns follower count
// Display the complete profile.
// Handle errors if userId is invalid.

// 🔴 CHALLENGE 3 (Hard):
// Build an async `bankTransfer(fromAcc, toAcc, amount)` function:
// Step 1: await checkBalance(fromAcc)   → reject if balance < amount
// Step 2: await debitAccount(fromAcc, amount)
// Step 3: await creditAccount(toAcc, amount)
// Step 4: await generateTransactionId()
// Step 5: Print success receipt OR handle failures at each step.
