// ============================================================
// 🎬 CHAPTER 1: CALLBACKS
// 📖 Story: You order a Pizza. The shop calls you back when ready!
// ============================================================

// ╔══════════════════════════════════════════════════════════╗
// ║  ❓ WHY DO WE NEED CALLBACKS?                            ║
// ╠══════════════════════════════════════════════════════════╣
// ║                                                          ║
// ║  🔴 THE PROBLEM (without callbacks):                     ║
// ║  JavaScript runs ONE line at a time (single-threaded).   ║
// ║  If you fetch data from a server, read a file, or set a  ║
// ║  timer — JS would FREEZE and wait! Nothing else works.   ║
// ║                                                          ║
// ║  Imagine: You call a pizza shop. Without callbacks,      ║
// ║  you'd STAND AT THE PHONE doing nothing for 30 mins      ║
// ║  waiting. You can't watch TV, eat, or talk. FROZEN! ❄️   ║
// ║                                                          ║
// ║  // ❌ WITHOUT CALLBACK (blocking — bad!)
// ║  const data = fetchDataFromServer(); // JS FREEZES here!  ║
// ║  console.log("This waits...");        // runs only after  ║
// ║                                                          ║
// ║  ✅ THE SOLUTION (with callbacks):                       ║
// ║  Pass a function to be called LATER when work is done.   ║
// ║  JS continues doing other things in the meantime!        ║
// ║                                                          ║
// ║  🎯 WHAT CALLBACKS UNLOCK:                               ║
// ║  → Handle async operations (API calls, file reads)       ║
// ║  → Event listeners (button clicks, keypresses)           ║
// ║  → setTimeout / setInterval (timers)                     ║
// ║  → Array methods (forEach, map, filter, reduce)          ║
// ║  → Foundation for Promises and async/await               ║
// ║                                                          ║
// ║  💡 Without callbacks, you literally CANNOT build any    ║
// ║     interactive or data-driven web application!          ║
// ╚══════════════════════════════════════════════════════════╝

// 🍕 You place an order. The shop says: "We'll CALL you BACK when ready"
// That's exactly what a CALLBACK is — a function passed to another function
// to be called later!

// ──────────────────────────────────────────
// 🔰 BASIC EXAMPLE
// ──────────────────────────────────────────

function orderPizza(flavor, callback) {
  console.log(`🍕 Ordering a ${flavor} pizza...`);
  // Simulating pizza being made
  callback(flavor); // "calling back" once pizza is ready
}

function pizzaReady(flavor) {
  console.log(`✅ Your ${flavor} pizza is ready! Enjoy! 🎉`);
}

orderPizza("Margherita", pizzaReady);

// ──────────────────────────────────────────
// 🔥 REAL LIFE: File Reading (like Node.js style)
// ──────────────────────────────────────────

function readFile(filename, callback) {
  console.log(`\n📂 Reading file: ${filename}...`);
  const fileContent = "Hello, this is the file content!";
  callback(null, fileContent); // null = no error, second arg = data
}

readFile("myFile.txt", function (error, data) {
  if (error) {
    console.log("❌ Error:", error);
  } else {
    console.log("📄 File Content:", data);
  }
});

// ──────────────────────────────────────────
// 😱 CALLBACK HELL (The Problem)
// Story: You want Pizza → then a Drink → then Dessert (one after another)
// ──────────────────────────────────────────

function orderFood(item, callback) {
  setTimeout(() => {
    console.log(`\n🍽️  ${item} is ready!`);
    callback();
  }, 1000);
}

// This is called "Callback Hell" or "Pyramid of Doom" 😱
orderFood("Pizza", function () {
  orderFood("Coke", function () {
    orderFood("Ice Cream", function () {
      console.log("🎊 Full meal done! (but code looks ugly)");
    });
  });
});

// ──────────────────────────────────────────
// ✅ SYNCHRONOUS vs ASYNCHRONOUS CALLBACK
// ──────────────────────────────────────────

// Synchronous callback (runs immediately)
const numbers = [1, 2, 3, 4, 5];
numbers.forEach(function (num) {
  console.log("\n🔢 Number:", num); // This is a synchronous callback
});

// Asynchronous callback (runs later)
setTimeout(function () {
  console.log("\n⏰ I run after 2 seconds! (async callback)");
}, 2000);

console.log("👆 This runs BEFORE the setTimeout callback!");

// ============================================================
// 🧪 YOUR CODING CHALLENGES - TRY THESE!
// ============================================================

// 🟡 CHALLENGE 1 (Easy):
// Create a function `greetUser(name, callback)`
// The callback should print: "Hello, [name]! Welcome!"
// Call greetUser with your name and the callback.

// 🟠 CHALLENGE 2 (Medium):
// Create a function `calculate(a, b, operation)`
// where operation is a callback.
// Call it with: addition, subtraction, multiplication callbacks.
// Example: calculate(10, 5, add) → 15

// 🔴 CHALLENGE 3 (Hard):
// Simulate an ATM machine using callbacks:
// Step 1: checkBalance(amount, callback)
// Step 2: deductAmount(amount, callback)
// Step 3: printReceipt(callback)
// Chain them using callbacks (experience the callback hell!)
