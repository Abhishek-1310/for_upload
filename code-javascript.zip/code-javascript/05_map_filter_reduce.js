// ============================================================
// 🎬 CHAPTER 5: MAP, FILTER, REDUCE
// 📖 Story: You're a CHEF working with ingredients (arrays)
//    MAP    → Transform each ingredient 🔄
//    FILTER → Keep only the good ones 🧹
//    REDUCE → Combine everything into ONE dish 🍲
// ============================================================

// ╔══════════════════════════════════════════════════════════╗
// ║  ❓ WHY DO WE NEED MAP / FILTER / REDUCE?                ║
// ╠══════════════════════════════════════════════════════════╣
// ║                                                          ║
// ║  🔴 THE PROBLEM (without them — using for loops):        ║
// ║  You CAN use for loops for everything, but they are:     ║
// ║  → Verbose — 5 lines to do what map does in 1 line       ║
// ║  → Mutation-prone — loops modify original arrays         ║
// ║  → Not chainable — can't combine operations cleanly      ║
// ║  → Hard to read — unclear WHAT the loop is doing         ║
// ║                                                          ║
// ║  // ❌ WITHOUT map (using for loop — verbose & mutates)  ║
// ║  const doubled = [];                                     ║
// ║  for (let i = 0; i < numbers.length; i++) {              ║
// ║    doubled.push(numbers[i] * 2); // 4 lines of ceremony  ║
// ║  }                                                       ║
// ║                                                          ║
// ║  // ✅ WITH map (1 line, clear intent, no mutation)      ║
// ║  const doubled = numbers.map(n => n * 2);                ║
// ║                                                          ║
// ║  // ❌ WITHOUT filter + reduce (loop soup — confusing)   ║
// ║  let total = 0;                                          ║
// ║  for (let i = 0; i < cart.length; i++) {                 ║
// ║    if (cart[i].inStock) total += cart[i].price;          ║
// ║  }                                                       ║
// ║                                                          ║
// ║  // ✅ WITH filter + reduce (reads like English!)        ║
// ║  const total = cart.filter(i=>i.inStock)                 ║
// ║                     .reduce((s,i)=>s+i.price, 0);        ║
// ║                                                          ║
// ║  🎯 WHAT THEY UNLOCK:                                    ║
// ║  → map    — Transform data without mutating original     ║
// ║  → filter — Search/query arrays declaratively            ║
// ║  → reduce — Aggregations, grouping, totals, flattening   ║
// ║  → CHAIN them — powerful data pipelines in one line      ║
// ║  → Used in EVERY React app for rendering lists/data      ║
// ║  → Used in every backend for processing data arrays      ║
// ╚══════════════════════════════════════════════════════════╝

const fruits = ["🍎 Apple", "🍌 Banana", "🍊 Orange", "🍇 Grapes", "🥭 Mango"];
const prices = [120, 40, 80, 200, 150]; // ₹ per kg
const quantities = [2, 5, 3, 1, 2];    // kg

// ──────────────────────────────────────────
// 🔄 MAP — Transform every element
// "For each ingredient, do something and give me a NEW array"
// ──────────────────────────────────────────

console.log("🔄 MAP EXAMPLES:");

// Example 1: Add "Fresh" to every fruit
const freshFruits = fruits.map((fruit) => `Fresh ${fruit}`);
console.log("Fresh fruits:", freshFruits);

// Example 2: Double all prices
const discountedPrices = prices.map((price) => price * 0.9); // 10% off
console.log("10% off prices:", discountedPrices);

// Example 3: Calculate total cost for each item
const totalCosts = prices.map((price, index) => price * quantities[index]);
console.log("Total cost per item:", totalCosts);

// Example 4: Transform objects
const students = [
  { name: "Abhishek", marks: 85 },
  { name: "Priya",    marks: 92 },
  { name: "Raj",      marks: 67 },
  { name: "Sneha",    marks: 78 },
];

const studentGrades = students.map((student) => ({
  name: student.name,
  marks: student.marks,
  grade: student.marks >= 90 ? "A" :
         student.marks >= 80 ? "B" :
         student.marks >= 70 ? "C" : "D",
  passed: student.marks >= 60,
}));

console.log("\n📊 Student Grades:");
studentGrades.forEach((s) =>
  console.log(`  ${s.name}: ${s.marks} → Grade ${s.grade} (${s.passed ? "✅ Pass" : "❌ Fail"})`)
);

// ──────────────────────────────────────────
// 🧹 FILTER — Keep only matching elements
// "Keep only the ingredients that pass the test"
// ──────────────────────────────────────────

console.log("\n\n🧹 FILTER EXAMPLES:");

const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

// Example 1: Only even numbers
const evens = numbers.filter((n) => n % 2 === 0);
console.log("Even numbers:", evens);

// Example 2: Only expensive fruits (price > 100)
const expensiveFruits = prices
  .map((price, i) => ({ fruit: fruits[i], price }))
  .filter((item) => item.price > 100);
console.log("Expensive fruits (>₹100):", expensiveFruits);

// Example 3: Pass/Fail filter
const passedStudents = students.filter((s) => s.marks >= 75);
const failedStudents = students.filter((s) => s.marks < 75);
console.log("\n✅ Passed:", passedStudents.map((s) => s.name));
console.log("❌ Failed:", failedStudents.map((s) => s.name));

// Example 4: Filter products in stock
const products = [
  { name: "Phone",  price: 15000, inStock: true  },
  { name: "Laptop", price: 55000, inStock: false },
  { name: "Watch",  price: 3000,  inStock: true  },
  { name: "Tablet", price: 25000, inStock: false },
  { name: "Earbuds",price: 2000,  inStock: true  },
];

const availableProducts = products.filter((p) => p.inStock);
const affordableInStock  = products.filter((p) => p.inStock && p.price < 10000);

console.log("\n🛒 Available products:", availableProducts.map((p) => p.name));
console.log("💰 Affordable & in stock:", affordableInStock.map((p) => p.name));

// ──────────────────────────────────────────
// 🍲 REDUCE — Combine all elements into ONE value
// "Take all ingredients, combine them into one dish"
// Syntax: array.reduce((accumulator, current) => ..., initialValue)
// ──────────────────────────────────────────

console.log("\n\n🍲 REDUCE EXAMPLES:");

// Example 1: Sum all numbers
const total = numbers.reduce((sum, num) => sum + num, 0);
console.log("Sum of 1-10:", total); // 55

// Example 2: Total shopping bill
const totalBill = prices.reduce((sum, price, i) => sum + price * quantities[i], 0);
console.log("Total shopping bill: ₹" + totalBill);

// Example 3: Find the MAX value
const highestPrice = prices.reduce((max, price) => (price > max ? price : max), 0);
console.log("Most expensive: ₹" + highestPrice);

// Example 4: Group students by grade (POWERFUL REDUCE!)
const groupedByGrade = students.reduce((groups, student) => {
  const grade = student.marks >= 80 ? "Top" : "Average";
  if (!groups[grade]) groups[grade] = [];
  groups[grade].push(student.name);
  return groups;
}, {});

console.log("\n📊 Students grouped by grade:", groupedByGrade);

// Example 5: Count occurrences (word frequency)
const words = ["apple", "banana", "apple", "cherry", "banana", "apple"];
const wordCount = words.reduce((count, word) => {
  count[word] = (count[word] || 0) + 1;
  return count;
}, {});
console.log("\n📝 Word frequency:", wordCount);

// Example 6: Flatten nested arrays
const nested = [[1, 2], [3, 4], [5, 6]];
const flat = nested.reduce((result, arr) => result.concat(arr), []);
console.log("Flattened:", flat); // [1, 2, 3, 4, 5, 6]

// ──────────────────────────────────────────
// 🚀 CHAINING: map + filter + reduce TOGETHER
// Story: Calculate total bill for expensive items that are in stock
// ──────────────────────────────────────────

const cart = [
  { item: "Phone",   price: 15000, qty: 1, inStock: true  },
  { item: "Laptop",  price: 55000, qty: 1, inStock: false },
  { item: "Earbuds", price: 2000,  qty: 2, inStock: true  },
  { item: "Watch",   price: 8000,  qty: 1, inStock: true  },
  { item: "Tablet",  price: 25000, qty: 1, inStock: false },
];

const finalBill = cart
  .filter((item) => item.inStock)                        // 🧹 only in-stock items
  .map((item) => ({ ...item, total: item.price * item.qty }))  // 🔄 add total field
  .reduce((sum, item) => sum + item.total, 0);            // 🍲 sum everything

console.log("\n\n🛒 CHAINING EXAMPLE:");
console.log("In-stock items with totals:");
cart
  .filter((item) => item.inStock)
  .map((item) => ({ ...item, total: item.price * item.qty }))
  .forEach((item) => console.log(`  ${item.item}: ₹${item.price} × ${item.qty} = ₹${item.total}`));

console.log(`💳 Final Bill (in-stock only): ₹${finalBill}`);

// ============================================================
// 🧪 YOUR CODING CHALLENGES - TRY THESE!
// ============================================================

// 🟡 CHALLENGE 1 (Easy):
// Given: const temps = [0, 15, 25, 30, 10, 20, 35, 5];
// a) Use MAP to convert all Celsius to Fahrenheit  (F = C * 9/5 + 32)
// b) Use FILTER to keep temps above 20°C
// c) Use REDUCE to find the average temperature

// 🟠 CHALLENGE 2 (Medium):
// Given an array of employees:
// const employees = [
//   { name: "Alice", dept: "IT",  salary: 60000, experience: 5 },
//   { name: "Bob",   dept: "HR",  salary: 45000, experience: 3 },
//   { name: "Carol", dept: "IT",  salary: 75000, experience: 8 },
//   { name: "Dave",  dept: "HR",  salary: 50000, experience: 6 },
//   { name: "Eve",   dept: "IT",  salary: 55000, experience: 4 },
// ];
// a) Get names of all IT employees with salary > 55000
// b) Give 20% raise to employees with experience > 5 years (use map)
// c) Calculate total salary bill per department (use reduce)

// 🔴 CHALLENGE 3 (Hard):
// Build a shopping cart system:
// const orders = [
//   { product: "Book",   price: 500,  qty: 3, category: "Education", coupon: true  },
//   { product: "Game",   price: 3000, qty: 1, category: "Gaming",    coupon: false },
//   { product: "Pen",    price: 50,   qty: 10,category: "Education", coupon: true  },
//   { product: "Chair",  price: 8000, qty: 1, category: "Furniture", coupon: false },
// ];
// a) Apply 15% discount on items with coupon=true (use map)
// b) Filter items where total (price*qty) > 1000
// c) Group filtered items by category (use reduce)
// d) Calculate grand total after discounts
