// ============================================================
// 🎬 CHAPTER 10: OBJECT-ORIENTED PROGRAMMING (OOP) 
//                — The FULL PICTURE
// 📖 Story: Building a COMPLETE GAME 🎮
//           Player, Enemy, Weapon — all real OOP!
// ============================================================

// ╔══════════════════════════════════════════════════════════╗
// ║  ❓ WHY DO WE NEED OOP?                                  ║
// ╠══════════════════════════════════════════════════════════╣
// ║                                                          ║
// ║  🔴 THE PROBLEM (without OOP — procedural/spaghetti):   ║
// ║  Imagine building a bank app WITHOUT OOP. You'd have:    ║
// ║                                                          ║
// ║  // ❌ WITHOUT OOP — scattered, unstructured mess        ║
// ║  let user1Name = "Abhishek", user1Balance = 5000;        ║
// ║  let user2Name = "Priya",    user2Balance = 3000;        ║
// ║  function deposit(userName, amount) { ... } // Which user?
// ║  function withdraw(userName, amount) { ... } // Fragile! ║
// ║  // Adding user3 means adding 5 more variables manually! ║
// ║  // Data and logic are SEPARATED — hard to manage        ║
// ║  // No protection — anyone can set user1Balance = -9999  ║
// ║                                                          ║
// ║  As the app grows, this becomes impossible to maintain:  ║
// ║  → 500 variables for 100 users 😱                        ║
// ║  → Can't figure out which function belongs to what       ║
// ║  → One change breaks 10 other things                     ║
// ║  → No reusability — copy-paste everywhere                ║
// ║                                                          ║
// ║  ✅ THE SOLUTION (with OOP):                             ║
// ║  // ✅ Data + behavior bundled together, protected!      ║
// ║  class BankAccount {                                     ║
// ║    #balance;  // private!                                ║
// ║    deposit(amt) { ... }  // logic lives WITH the data    ║
// ║    withdraw(amt) { ... } // clear, organized, safe       ║
// ║  }                                                       ║
// ║  const user1 = new BankAccount("Abhishek", 5000);        ║
// ║  const user2 = new BankAccount("Priya", 3000); // Easy!  ║
// ║                                                          ║
// ║  🎯 THE 4 PILLARS SOLVE REAL PROBLEMS:                   ║
// ║  ENCAPSULATION  → Private data, no accidental changes    ║
// ║  INHERITANCE    → Reuse code, don't repeat yourself      ║
// ║  POLYMORPHISM   → One interface, many behaviors          ║
// ║  ABSTRACTION    → Hide complexity, expose simple API     ║
// ║                                                          ║
// ║  🎯 WHAT OOP UNLOCKS:                                    ║
// ║  → Model real-world systems (users, products, orders)    ║
// ║  → Scalable code — add features without breaking things  ║
// ║  → Team collaboration — clear structure everyone follows ║
// ║  → Used in EVERY framework: React, Angular, Node.js      ║
// ╚══════════════════════════════════════════════════════════╝

// OOP Pillars:
// 1️⃣  ENCAPSULATION  — Bundle data + methods, hide internals
// 2️⃣  INHERITANCE    — Child class inherits from parent
// 3️⃣  POLYMORPHISM   — Same method, different behavior
// 4️⃣  ABSTRACTION    — Hide complexity, show only essentials

// ──────────────────────────────────────────
// 1️⃣  ENCAPSULATION — Protecting internal data
// ──────────────────────────────────────────

class BankAccount {
  #balance;       // 🔒 Private field (ES2022)
  #pin;
  #transactions;

  constructor(owner, initialBalance, pin) {
    this.owner        = owner;
    this.#balance     = initialBalance;
    this.#pin         = pin;
    this.#transactions = [];
  }

  // Private method
  #logTransaction(type, amount) {
    this.#transactions.push({
      type,
      amount,
      balance: this.#balance,
      time: new Date().toLocaleTimeString(),
    });
  }

  #validatePin(pin) {
    return this.#pin === pin;
  }

  deposit(amount) {
    if (amount <= 0) throw new Error("Amount must be positive!");
    this.#balance += amount;
    this.#logTransaction("DEPOSIT", amount);
    console.log(`💰 Deposited ₹${amount}. Balance: ₹${this.#balance}`);
  }

  withdraw(amount, pin) {
    if (!this.#validatePin(pin)) {
      console.log("❌ Wrong PIN!");
      return;
    }
    if (amount > this.#balance) {
      console.log("❌ Insufficient balance!");
      return;
    }
    this.#balance -= amount;
    this.#logTransaction("WITHDRAW", amount);
    console.log(`💸 Withdrew ₹${amount}. Balance: ₹${this.#balance}`);
  }

  getBalance(pin) {
    if (!this.#validatePin(pin)) return console.log("❌ Wrong PIN!");
    console.log(`💳 ${this.owner}'s Balance: ₹${this.#balance}`);
  }

  getStatement() {
    console.log(`\n📊 Statement for: ${this.owner}`);
    console.log("─".repeat(50));
    this.#transactions.forEach((t) =>
      console.log(`  ${t.time} | ${t.type.padEnd(8)} | ₹${t.amount} | Balance: ₹${t.balance}`)
    );
  }
}

const account = new BankAccount("Abhishek", 5000, 1234);
account.deposit(2000);
account.withdraw(1000, 1234);
account.withdraw(100,  9999); // Wrong PIN
account.getBalance(1234);
account.getStatement();
// console.log(account.#balance); // ❌ Error: private field!

// ──────────────────────────────────────────
// 2️⃣ INHERITANCE + 3️⃣ POLYMORPHISM 
// Story: Game characters!
// ──────────────────────────────────────────

console.log("\n\n🎮 GAME CHARACTERS:\n");

class GameCharacter {
  constructor(name, health, level) {
    this.name   = name;
    this.health = health;
    this.level  = level;
    this.alive  = true;
  }

  takeDamage(damage) {
    if (!this.alive) return console.log(`${this.name} is already defeated!`);
    this.health = Math.max(0, this.health - damage);
    if (this.health === 0) {
      this.alive = false;
      console.log(`💀 ${this.name} has been defeated!`);
    } else {
      console.log(`❤️  ${this.name} HP: ${this.health}`);
    }
  }

  // POLYMORPHIC method — each subclass overrides this differently
  attack(target) {
    console.log(`⚔️  ${this.name} attacks ${target.name}`);
  }

  status() {
    console.log(`📋 ${this.name} | HP: ${this.health} | Lvl: ${this.level} | ${this.alive ? "✅ Alive" : "💀 Dead"}`);
  }
}

class Warrior extends GameCharacter {
  constructor(name, health, level, weapon) {
    super(name, health, level);
    this.weapon    = weapon;
    this.rage      = 0;
  }

  // POLYMORPHISM — Warrior attacks differently
  attack(target) {
    const damage = 25 + this.level * 5 + this.rage;
    console.log(`⚔️  ${this.name} strikes ${target.name} with ${this.weapon} for ${damage} damage!`);
    target.takeDamage(damage);
    this.rage += 5; // builds rage with each attack
  }

  berserkerMode() {
    if (this.rage >= 20) {
      console.log(`🔥 ${this.name} enters BERSERKER MODE! Double damage!`);
      this.rage *= 2;
    } else {
      console.log(`😤 Not enough rage! (${this.rage}/20)`);
    }
  }
}

class Mage extends GameCharacter {
  constructor(name, health, level, mana) {
    super(name, health, level);
    this.mana      = mana;
    this.maxMana   = mana;
    this.spells    = ["Fireball", "Ice Bolt", "Lightning"];
  }

  // POLYMORPHISM — Mage attacks with spells
  attack(target) {
    if (this.mana < 20) {
      console.log(`🔵 ${this.name} is out of mana! Using staff hit.`);
      target.takeDamage(5);
      return;
    }
    const spell  = this.spells[Math.floor(Math.random() * this.spells.length)];
    const damage = 40 + this.level * 8;
    console.log(`✨ ${this.name} casts ${spell} on ${target.name} for ${damage} damage!`);
    target.takeDamage(damage);
    this.mana -= 20;
    console.log(`🔵 Mana: ${this.mana}/${this.maxMana}`);
  }

  meditate() {
    this.mana = Math.min(this.maxMana, this.mana + 30);
    console.log(`🧘 ${this.name} meditates. Mana: ${this.mana}/${this.maxMana}`);
  }
}

class Archer extends GameCharacter {
  constructor(name, health, level, arrows) {
    super(name, health, level);
    this.arrows = arrows;
  }

  attack(target) {
    if (this.arrows === 0) {
      console.log(`🏹 ${this.name} has no arrows! Using dagger.`);
      target.takeDamage(10);
      return;
    }
    const damage = 20 + this.level * 6;
    console.log(`🏹 ${this.name} shoots ${target.name} for ${damage} damage!`);
    target.takeDamage(damage);
    this.arrows--;
    console.log(`🏹 Arrows left: ${this.arrows}`);
  }
}

// Create characters
const hero    = new Warrior("Arjun",  200, 5, "Sword of Dawn");
const wizard  = new Mage("Merlin",    120, 5, 100);
const hunter  = new Archer("Robin",   150, 5, 10);
const boss    = new Warrior("Demon King", 500, 10, "Shadow Blade");

// POLYMORPHISM in action — same `attack()` call, different behavior!
console.log("=".repeat(50));
console.log("⚔️  BATTLE BEGINS!");
console.log("=".repeat(50));

hero.status();
wizard.status();
boss.status();

console.log("\n🥊 Round 1:");
hero.attack(boss);      // Warrior attack
wizard.attack(boss);    // Mage attack (SAME method name!)
hunter.attack(boss);    // Archer attack (SAME method name!)

console.log("\n⚔️  Boss counter-attacks:");
boss.attack(hero);
boss.attack(wizard);

hero.berserkerMode();
console.log("\n🥊 Round 2 (Berserker!):");
hero.attack(boss);
wizard.meditate();
wizard.attack(boss);

// ──────────────────────────────────────────
// 4️⃣ ABSTRACTION — Using Abstract-like pattern
// Story: Payment system — users don't need to know HOW it processes
// ──────────────────────────────────────────

console.log("\n\n💳 ABSTRACTION — Payment System:\n");

class PaymentProcessor {
  constructor(name) {
    if (new.target === PaymentProcessor) {
      throw new Error("❌ Cannot instantiate abstract class PaymentProcessor!");
    }
    this.name = name;
  }

  // Abstract method — MUST be overridden
  processPayment(amount) {
    throw new Error(`${this.name} must implement processPayment()`);
  }

  // Concrete method — same for all
  generateReceipt(amount, orderId) {
    console.log(`🧾 Receipt | Processor: ${this.name} | ₹${amount} | Order: ${orderId}`);
  }
}

class UPIPayment extends PaymentProcessor {
  constructor(upiId) {
    super("UPI");
    this.upiId = upiId;
  }

  processPayment(amount) {
    console.log(`📱 UPI Payment: ₹${amount} via ${this.upiId}`);
    return { success: true, method: "UPI", amount };
  }
}

class CardPayment extends PaymentProcessor {
  constructor(cardNumber) {
    super("Card");
    this.cardNumber = `****${cardNumber.slice(-4)}`;
  }

  processPayment(amount) {
    console.log(`💳 Card Payment: ₹${amount} via ${this.cardNumber}`);
    return { success: true, method: "Card", amount };
  }
}

class CashPayment extends PaymentProcessor {
  constructor() {
    super("Cash");
  }

  processPayment(amount) {
    console.log(`💵 Cash Payment: ₹${amount} collected at counter`);
    return { success: true, method: "Cash", amount };
  }
}

// Polymorphism + Abstraction together:
const payments = [
  new UPIPayment("abhishek@paytm"),
  new CardPayment("1234567890123456"),
  new CashPayment(),
];

// Same checkout() call works for ALL payment types!
function checkout(paymentProcessor, amount, orderId) {
  const result = paymentProcessor.processPayment(amount); // abstracted!
  if (result.success) {
    paymentProcessor.generateReceipt(amount, orderId);
    console.log("✅ Payment Successful!\n");
  }
}

payments.forEach((p, i) => checkout(p, 1500, `ORDER-${1001 + i}`));

// ============================================================
// 🧪 YOUR CODING CHALLENGES - TRY THESE!
// ============================================================

// 🟡 CHALLENGE 1 (Easy):
// Create a class `Car` with:
//   - Properties: make, model, year, speed (=0), fuel (=100)
//   - Methods: accelerate(amount), brake(amount), refuel()
//   - Private #vin (vehicle ID number)
//   - getInfo() — show all details
// Create 3 different cars and simulate driving!

// 🟠 CHALLENGE 2 (Medium):
// Build an Animal Kingdom:
// class Animal { name, sound, speak(), eat(food), sleep() }
// class Dog extends Animal { breed, fetch(), wagTail() }
// class Cat extends Animal { indoor, purr(), scratch() }
// class Bird extends Animal { canFly, fly(), sing() }
// Show POLYMORPHISM: make an array of animals and call speak() on each.
// Show INHERITANCE: Dog and Cat should inherit eat() and sleep().

// 🔴 CHALLENGE 3 (Hard):
// Build an E-Commerce OOP System:
// class Product { id, name, price, stock, #discount }
//   - applyDiscount(percent)
//   - getPrice()  ← returns discounted price
//   - purchase(qty) ← reduces stock, throws if insufficient
// class Cart { items[], user }
//   - addItem(product, qty)
//   - removeItem(productId)
//   - calculateTotal() ← applies all discounts
//   - checkout() ← processes purchase for all items
// class Order { cart, status, orderId, timestamp }
//   - updateStatus(newStatus)
//   - getTrackingInfo()
// Simulate: Create products, add to cart, checkout, track order!
