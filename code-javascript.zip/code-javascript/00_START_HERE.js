// ============================================================
// 🗺️  JAVASCRIPT LEARNING ROADMAP
// ============================================================
// Your complete plan to master JS through story-based coding!
// ============================================================

/*
📚 FILES IN THIS LEARNING SERIES:
══════════════════════════════════════════════════════════════

  01_callbacks.js        → 🍕 Pizza shop callback story
  02_promises.js         → 🚗 Cab booking promise story  
  03_async_await.js      → 👨‍🍳 Chef waiting for ingredients
  04_closures.js         → 🔐 Secret locker & bank account
  05_map_filter_reduce.js→ 🍲 Chef transforming ingredients
  06_call_apply_bind.js  → 👨‍🍳 Borrowing chef's skills
  07_currying.js         → 🍫 Vending machine coins one-by-one
  08_spread_rest.js      → 🎁 Opening & packing gift boxes
  09_prototype_oops.js   → 👨‍👩‍👧 Family tree inheritance
  10_oops_complete.js    → 🎮 Full Game OOP system
  11_regex.js            → 🕵️  Detective finding clues in text

══════════════════════════════════════════════════════════════
📋 HOW TO STUDY EACH FILE:
══════════════════════════════════════════════════════════════

  STEP 1: Read the STORY at the top 📖
  STEP 2: Run the file: node filename.js 
  STEP 3: Read each section carefully 👀
  STEP 4: Modify the examples — change values, break it! 🔨
  STEP 5: Solve the CHALLENGES at the bottom 💪
  STEP 6: Move to next file only after completing challenges ✅

══════════════════════════════════════════════════════════════
🎯 CONCEPT QUICK REFERENCE:
══════════════════════════════════════════════════════════════

┌─────────────────┬──────────────────────────────────────────┐
│ Concept         │ One-Line Summary                         │
├─────────────────┼──────────────────────────────────────────┤
│ Callback        │ "Call me BACK when done" 📞               │
│ Promise         │ "I PROMISE to give you result" 🤝         │
│ Async/Await     │ "WAIT for me, then continue" ⏳           │
│ Closure         │ "I REMEMBER my outer variables" 🧠        │
│ Map             │ "TRANSFORM every element" 🔄              │
│ Filter          │ "KEEP only matching elements" 🧹          │
│ Reduce          │ "COMBINE all into one" 🍲                 │
│ Call            │ "Borrow with args one-by-one" 📞          │
│ Apply           │ "Borrow with args as array" 📋            │
│ Bind            │ "Fix 'this' for later use" 🔗             │
│ Currying        │ "One arg at a time" 🍫                    │
│ Spread          │ "Unpack/expand array/object" 🎁           │
│ Rest            │ "Collect remaining into array" 🎒         │
│ Prototype       │ "Inherit from parent object" 🧬           │
│ OOP             │ Model real world as objects 🌍          │
│ Regex           │ Pattern match & extract text 🔍           │
└─────────────────┴──────────────────────────────────────────┘

══════════════════════════════════════════════════════════════
⚡ HOW TO RUN FILES:
══════════════════════════════════════════════════════════════

  Make sure Node.js is installed:
    node --version

  Run any file:
    node 01_callbacks.js
    node 02_promises.js
    node 03_async_await.js
    ... and so on

══════════════════════════════════════════════════════════════
🏆 CHALLENGE DIFFICULTY LEVELS:
══════════════════════════════════════════════════════════════

  🟡 Easy    → Do this FIRST. Gets you comfortable.
  🟠 Medium  → Apply concepts in realistic scenarios.
  🔴 Hard    → Combine multiple concepts. Interview-level!

══════════════════════════════════════════════════════════════
🚀 SUGGESTED LEARNING ORDER:
══════════════════════════════════════════════════════════════

  Week 1:
    Day 1-2: Callbacks (01)
    Day 3-4: Promises (02)
    Day 5-7: Async/Await (03) + practice

  Week 2:
    Day 1-2: Closures (04)
    Day 3-4: Map/Filter/Reduce (05)
    Day 5-7: Call/Apply/Bind (06) + practice

  Week 3:
    Day 1-2: Currying (07)
    Day 3-4: Spread/Rest (08)
    Day 5-7: Prototypes (09) + practice

  Week 4:
    Day 1-3: Full OOP (10)
    Day 4-5: Regex (11)
    Day 6-7: Build a COMPLETE PROJECT combining everything!

══════════════════════════════════════════════════════════════
🎓 FINAL PROJECT IDEAS (combine ALL concepts):
══════════════════════════════════════════════════════════════

  🛒 Mini E-Commerce: Products, Cart, Orders, Payments
     (OOP + Promises + async/await + map/filter/reduce)

  🏦 Banking App: Accounts, Transfers, History
     (Closures + OOP + Promises + Prototypes)

  ✅ Task Manager: Add/Edit/Delete/Filter tasks
     (Closures + Map/Filter/Reduce + OOP)

  🎮 Text Adventure Game: Characters, battles, inventory
     (OOP + Closures + Currying + Callbacks)

══════════════════════════════════════════════════════════════
💡 PRO TIPS:
══════════════════════════════════════════════════════════════

  1. console.log() EVERYTHING when learning
  2. Break things intentionally — then fix them
  3. Rewrite examples from scratch without looking
  4. Connect each concept to a real-world scenario
  5. The challenges are designed to be hard — that's good!
  6. Google is allowed, copying answers is NOT 😄

══════════════════════════════════════════════════════════════
*/

console.log(`
╔══════════════════════════════════════════════════════════╗
║     🎉 WELCOME TO YOUR JS LEARNING JOURNEY!              ║
║                                                          ║
║     You have 10 files, each with:                        ║
║     ✅ Story-based examples                              ║
║     ✅ Real-life code                                     ║
║     ✅ 3 challenges per file (Easy → Hard)               ║
║                                                          ║
║     Start with: node 01_callbacks.js                     ║
║                                                          ║
║     Remember: Code > Theory. Always!                     ║
╚══════════════════════════════════════════════════════════╝
`);
