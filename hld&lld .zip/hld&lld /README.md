# 🎯 The HLD & LLD Interview Mastery Journey

> *"You don't learn system design by memorizing. You learn it by living through the problems that forced these solutions to exist."*

Welcome, future architect. This isn't a textbook. This is a **story** — your story — of becoming someone who can walk into any HLD/LLD interview and design systems with confidence.

---

## 📖 How to Read This

Each chapter follows the same flow:

1. **The Problem Appears** — a real situation you'd face
2. **The Naive Attempt** — how a beginner would solve it (and fail)
3. **The "Aha!" Moment** — the concept/pattern that fixes it
4. **The Interview Lens** — how this exact thing gets asked
5. **Cheat Card** — quick recall before the interview

Read in order. Don't skip. Each chapter builds on the last.

---

## 🗺️ The Roadmap

### 🧱 PART 1 — LLD (Low Level Design)
Think: *"How do I structure code inside one service?"*

| # | Chapter | What You'll Master |
|---|---------|--------------------|
| 1 | [`01-lld/01-oop-story.md`](./01-lld/01-oop-story.md) | OOP through a coffee shop story |
| 2 | [`01-lld/02-solid-principles.md`](./01-lld/02-solid-principles.md) | SOLID via a startup that kept breaking |
| 3 | [`01-lld/03-design-patterns-creational.md`](./01-lld/03-design-patterns-creational.md) | Singleton, Factory, Builder, Prototype |
| 4 | [`01-lld/04-design-patterns-structural.md`](./01-lld/04-design-patterns-structural.md) | Adapter, Decorator, Facade, Proxy |
| 5 | [`01-lld/05-design-patterns-behavioral.md`](./01-lld/05-design-patterns-behavioral.md) | Strategy, Observer, State, Command |
| 6 | [`01-lld/06-uml-quickstart.md`](./01-lld/06-uml-quickstart.md) | Class diagrams in 10 minutes |
| 7 | [`01-lld/07-case-parking-lot.md`](./01-lld/07-case-parking-lot.md) | 🅿️ Parking Lot |
| 8 | [`01-lld/08-case-splitwise.md`](./01-lld/08-case-splitwise.md) | 💸 Splitwise |
| 9 | [`01-lld/09-case-bookmyshow.md`](./01-lld/09-case-bookmyshow.md) | 🎬 BookMyShow |
| 10 | [`01-lld/10-case-elevator.md`](./01-lld/10-case-elevator.md) | 🛗 Elevator System |
| 11 | [`01-lld/11-case-snake-ladder-chess.md`](./01-lld/11-case-snake-ladder-chess.md) | ♟️ Games |
| 12 | [`01-lld/12-case-rate-limiter.md`](./01-lld/12-case-rate-limiter.md) | 🚦 Rate Limiter |

### 🏰 PART 2 — HLD (High Level Design)
Think: *"How do I make this work for 100 million users?"*

| # | Chapter | What You'll Master |
|---|---------|--------------------|
| 1 | [`02-hld/01-the-scaling-story.md`](./02-hld/01-the-scaling-story.md) | From 1 user → 1 billion |
| 2 | [`02-hld/02-databases-deep-dive.md`](./02-hld/02-databases-deep-dive.md) | SQL vs NoSQL, sharding, replication |
| 3 | [`02-hld/03-caching-story.md`](./02-hld/03-caching-story.md) | Redis, CDN, cache strategies |
| 4 | [`02-hld/04-load-balancers-and-proxies.md`](./02-hld/04-load-balancers-and-proxies.md) | LB, reverse proxy, API gateway |
| 5 | [`02-hld/05-message-queues.md`](./02-hld/05-message-queues.md) | Kafka, RabbitMQ, async world |
| 6 | [`02-hld/06-cap-pacelc-consistency.md`](./02-hld/06-cap-pacelc-consistency.md) | CAP, PACELC, consistency models |
| 7 | [`02-hld/07-microservices-vs-monolith.md`](./02-hld/07-microservices-vs-monolith.md) | When to split |
| 8 | [`02-hld/08-case-url-shortener.md`](./02-hld/08-case-url-shortener.md) | 🔗 TinyURL |
| 9 | [`02-hld/09-case-instagram.md`](./02-hld/09-case-instagram.md) | 📸 Instagram / Twitter feed |
| 10 | [`02-hld/10-case-whatsapp.md`](./02-hld/10-case-whatsapp.md) | 💬 WhatsApp |
| 11 | [`02-hld/11-case-uber.md`](./02-hld/11-case-uber.md) | 🚗 Uber |
| 12 | [`02-hld/12-case-netflix.md`](./02-hld/12-case-netflix.md) | 🎥 Netflix |
| 13 | [`02-hld/13-case-notification-system.md`](./02-hld/13-case-notification-system.md) | 🔔 Notifications |

### 🎤 PART 3 — Interview Mastery
| Chapter | Purpose |
|---------|---------|
| [`03-interview/01-the-framework.md`](./03-interview/01-the-framework.md) | The 7-step playbook for ANY question |
| [`03-interview/02-common-mistakes.md`](./03-interview/02-common-mistakes.md) | Why candidates fail |
| [`03-interview/03-cheatsheet.md`](./03-interview/03-cheatsheet.md) | Numbers, latencies, formulas |
| [`03-interview/04-questions-bank.md`](./03-interview/04-questions-bank.md) | 50+ practice prompts |

---

## 🔥 The 4-Week Plan

- **Week 1:** LLD chapters 1–6 (foundations + patterns). Code each pattern by hand.
- **Week 2:** LLD case studies 7–12. Whiteboard each *before* reading the solution.
- **Week 3:** HLD foundations 1–7. Draw every diagram twice.
- **Week 4:** HLD case studies + Interview framework. Mock interview daily.

> Rule: **Don't just read. Re-tell the story to a rubber duck.** If you can teach it, you own it.

Now open Chapter 1 and let's begin. 👉 [`01-lld/01-oop-story.md`](./01-lld/01-oop-story.md)
