# HLD Chapter 6 — CAP, PACELC & Consistency Models 🌐

> The theory chapter. But interviewers test it constantly. Get the **vocabulary** right and you sound senior.

---

## CAP Theorem (Eric Brewer, 2000)

In a distributed system, when a **Network Partition** happens, you can pick **only 2 of 3**:

- **C** — **Consistency** (every read sees the latest write)
- **A** — **Availability** (every request gets a response, not error)
- **P** — **Partition tolerance** (system keeps working despite network failures)

In real distributed systems, **P is non-negotiable** (networks fail). So the real choice during a partition is:

- **CP** — refuse some requests to stay consistent (e.g., Spanner, HBase, MongoDB w/ majority writes)
- **AP** — answer everything but possibly stale (e.g., Cassandra, DynamoDB default, Couchbase)

> ⚠️ Common mistake: "MongoDB is CP" or "Cassandra is AP" are oversimplified. Most modern DBs let you tune consistency per query.

---

## PACELC (the better model)

CAP only describes behavior **during partitions**. PACELC adds normal operation:

> **If P, then A or C; Else (no partition), L or C.**
> i.e., you also trade **Latency vs Consistency** when the network is fine.

| System | Partition behavior | Else (normal) |
|---|---|---|
| DynamoDB (default) | A | L |
| Cassandra | A | L |
| MongoDB (majority) | C | C |
| Spanner | C | C |
| BigTable / HBase | C | C |

---

## Consistency Models (★ memorize)

From strongest to weakest:

### 1. Linearizable / Strong Consistency
Reads always see the most recent committed write. As if there's one copy.
> Examples: Spanner, single-node Postgres, etcd.
> Cost: latency (often cross-DC consensus).

### 2. Sequential Consistency
Operations appear in *some* order consistent with program order, but not necessarily real time.

### 3. Causal Consistency
Operations causally related are seen in order; unrelated may not be.
> Useful for chat: "B is a reply to A" → everyone sees A before B.

### 4. Read Your Writes
After you write, you see your own writes immediately. Others may not yet.
> Implementation: pin user reads to master; or include version in client.

### 5. Monotonic Reads
You never see "older" data after seeing "newer".

### 6. Eventual Consistency
Given no new writes, all replicas converge eventually. Weakest.
> Used everywhere for non-critical data: feeds, view counts.

---

## When to choose which?

| Domain | Consistency |
|---|---|
| Bank balance, inventory, payments | Strong / Linearizable |
| Friends list, profile updates | Read-your-writes |
| Chat order, threaded comments | Causal |
| Likes counter, view count | Eventual |
| Social feed | Eventual + ranked |

> **Most real apps mix consistency models** — strong where it matters, eventual where it scales.

---

## Replication & Quorum (Dynamo-style)

In wide-column DBs (Cassandra, Dynamo), each piece of data is replicated N times. A read or write needs a quorum.

```
N = total replicas
W = nodes that must ack a write
R = nodes that must respond to a read

Strong consistency  ⇔  W + R > N
```

Common configs:
- **N=3, W=2, R=2** → strong, fault-tolerant
- **N=3, W=1, R=1** → fastest, weakly consistent
- **N=3, W=3, R=1** → fast reads, slow writes

---

## Consensus Algorithms (in 30 seconds)

To agree on a single value across machines despite failures.

- **Paxos** — original, correct, hard to implement
- **Raft** — Paxos but understandable; used by etcd, Consul, CockroachDB
- **Zab** — used by ZooKeeper

You don't need to implement them — **but mention them** when designing leader election, distributed locks, or consistent metadata.

---

## Failure Models

- **Crash failure** — node dies cleanly
- **Omission** — message lost
- **Network partition** — some nodes can't talk to others
- **Byzantine** — nodes lie/misbehave (rare outside crypto)

For most interview discussions, plan for crashes + partitions.

---

## Idempotency, Retries & At-Least-Once

In distributed systems, **anything can be retried**. So design APIs to be idempotent:
- Use **idempotency keys** on POST endpoints (`Idempotency-Key: abc123`)
- Use **conditional writes** (DB upserts, version numbers)
- Watch out for non-idempotent operations like "+= 1" — wrap in transactions or use unique tokens

---

## 🎤 Common Interview Asks

1. **"Explain CAP."** → Define + give a CP and an AP example. Mention PACELC for bonus points.
2. **"How do you ensure read-your-writes?"** → master read after write, or carry a version token.
3. **"Strong vs eventual consistency in your design?"** → Pick per data type with reasoning.
4. **"What is split-brain?"** → Two leaders elected during a partition → divergent state. Mitigated by quorum-based election.
5. **"How would you implement a distributed lock?"** → ZooKeeper / etcd / Redis Redlock. Caveats: clock skew, fencing tokens.

---

## 🧾 Cheat Card

```
CAP        : during partition pick C or A (P always)
PACELC     : also trade L vs C when no partition

Consistency: linearizable > sequential > causal > read-your-writes > eventual

Quorum (Dynamo): W + R > N  ⇒  strong

Consensus  : Raft, Paxos, Zab — for leader election, metadata
Always     : idempotent APIs, fencing tokens, retries with backoff
```

➡️ **Next:** [HLD 7 — Microservices vs Monolith](./07-microservices-vs-monolith.md)
