# HLD Chapter 4 — Load Balancers, Proxies & API Gateways 🚦

> The traffic cops of the internet. They decide *who goes where* and *what gets through*.

---

## Load Balancer (LB)

Distributes incoming requests across multiple backend servers.

### Why we need it
- **Scale** — one server can't handle all traffic
- **Reliability** — if one server dies, LB sends traffic elsewhere
- **Zero-downtime deploys** — drain one server at a time

### Layer 4 (TCP) vs Layer 7 (HTTP)

| | L4 | L7 |
|---|---|---|
| Inspects | TCP/UDP packets | HTTP path, headers, cookies |
| Speed | Faster | Slightly slower |
| Routing | by IP/port | by URL, headers, host |
| Examples | AWS NLB, HAProxy (TCP) | Nginx, AWS ALB, Envoy |

**Rule of thumb:** L7 unless you specifically need L4 (e.g., non-HTTP, ultra-low latency).

### Algorithms (★)

1. **Round Robin** — rotate. Simple but ignores load.
2. **Weighted Round Robin** — give bigger servers more weight.
3. **Least Connections** — send to least-busy. Best for long-lived connections.
4. **Least Response Time** — send to fastest responder.
5. **IP Hash** — same client → same server (sticky).
6. **Consistent Hash** — useful for routing to caches/shards.

### Health checks
LB pings each server (`GET /health`); unhealthy ones removed from pool. Tune timeouts/intervals carefully.

### Sticky sessions
Pin a user to a specific server (cookie or IP hash). Useful when state is on server, **but breaks horizontal scaling**. Prefer stateless apps.

---

## Reverse Proxy

A server that sits in front of backend servers and forwards requests. **Most LBs are reverse proxies.**

Beyond load balancing, a reverse proxy can:
- Terminate **TLS/SSL** (offload encryption from app servers)
- **Caching** static responses
- **Compression** (gzip/brotli)
- **Rate limiting** & DDoS protection
- Path-based routing (`/api → backend1, /static → CDN`)

> Examples: **Nginx, Envoy, HAProxy, Traefik, Caddy**.

### Forward Proxy (different beast!)
Forward proxy serves **clients** (think corporate firewall, VPN). Reverse proxy serves **servers**. Don't confuse.

---

## API Gateway

A specialized reverse proxy for **microservices**. The single entry point for clients.

```
[Mobile / Web] ──▶ [API Gateway] ──┬──▶ User Service
                                    ├──▶ Order Service
                                    ├──▶ Payment Service
                                    └──▶ Notification Service
```

Responsibilities:
- **Auth** (JWT/OAuth verification once at the edge)
- **Rate limiting** (per API key/user)
- **Routing** (`/users/* → user-svc`)
- **Request/response transformation** (e.g., GraphQL → REST)
- **API composition** (one client call → fan-out to multiple services)
- **Logging, metrics, tracing**

> Examples: **Kong, AWS API Gateway, Zuul, Apigee, Tyk**.

### Backend-for-Frontend (BFF) pattern
One gateway per client type (mobile, web, partner) tailored to that client's needs. Avoids "one gateway tries to please everyone."

---

## Traffic Path in a Real System

```
         DNS (geo-routing)
              │
              ▼
        ┌──────────┐
        │   CDN    │ ── static, edge cache
        └────┬─────┘
             │ (origin miss)
             ▼
        ┌──────────┐
        │   WAF    │ ── DDoS / SQLi filtering
        └────┬─────┘
             ▼
        ┌──────────┐
        │   LB/    │ ── TLS termination, routing
        │ Reverse  │
        │  Proxy   │
        └────┬─────┘
             ▼
        ┌──────────┐
        │   API    │ ── auth, rate limit, routing
        │ Gateway  │
        └────┬─────┘
             ▼
       [ Microservices ]
```

---

## DNS — the very first hop

- DNS maps `bookly.com` → IP address.
- **GeoDNS** returns different IPs based on user location (route to nearest region).
- TTL controls how long clients cache the answer.
- **Anycast**: same IP advertised from many locations → router sends user to nearest.

---

## Reliability patterns at the gateway

- **Circuit breaker** — stop calling a failing downstream after N errors; auto-retry after cooldown. (Hystrix, Resilience4j.)
- **Bulkhead** — isolate thread pools so one slow service doesn't drown others.
- **Retry with exponential backoff + jitter**
- **Timeouts** at every layer (default to "fail fast")
- **Graceful degradation** — return cached/partial data when downstream is dead

---

## 🎤 Interview Asks

1. *"L4 vs L7 LB?"* — packet vs HTTP-aware.
2. *"How do you handle a server failing during a request?"* — health checks, retries, idempotency.
3. *"Where would you put authentication — at each service or gateway?"* — Gateway for coarse auth (JWT verify); services for business-level authz.
4. *"How do you avoid a single point of failure at the LB?"* — multiple LBs behind a virtual IP / DNS round-robin / cloud-managed LBs are HA by default.

---

## 🧾 Cheat Card

```
LB        : distributes traffic; algos: RR, weighted, least-conn, IP hash, consistent hash
Proxy     : reverse proxy = front-of-servers; forward proxy = client-side
Gateway   : auth + rate-limit + routing + composition for microservices
Patterns  : circuit breaker, bulkhead, retry+jitter, timeouts
DNS       : GeoDNS / Anycast for global routing
Tools     : Nginx, Envoy, HAProxy, Kong, AWS ALB/NLB, Cloudflare
```

➡️ **Next:** [HLD 5 — Message Queues & Async Systems](./05-message-queues.md)
