# HLD Chapter 8 — 🔗 Case Study: TinyURL / URL Shortener

> The "Hello World" of HLD interviews. Master this — half the patterns repeat in every other case.

---

## Step 1 — Clarify (always!)

- Input: long URL → output: short URL like `tiny.cc/abc123`
- Click `tiny.cc/abc123` → redirect (301/302) to long URL
- Custom alias support? (assume yes)
- Expiry? (assume optional TTL)
- Analytics — click count? (yes)

---

## Step 2 — Estimate

> Tell the interviewer your numbers. Always.

Assume:
- 100M new URLs/month → ~40 URLs/sec write
- Read:write = 100:1 → 4000 reads/sec
- Peak ≈ 3× → 12K reads/sec
- Storage: 100M × 12 months × 5 years × 500 bytes ≈ **3 TB**

---

## Step 3 — API

```
POST /shorten     { url, alias?, ttl? } → { short_url }
GET  /:code        → 301 redirect
GET  /api/stats/:code → { clicks, last_seen, ... }
```

---

## Step 4 — The Core: Generating Short Codes

### Approach A — Hash (e.g., MD5/SHA-1) + base62
```
hash(long_url) → take first 7 chars → base62 → "abc123x"
```
- ❌ Collisions need handling (retry with salt)
- ✅ Same URL → same short code (deduplication)

### Approach B — Counter + base62 (★ favored)
- Auto-increment ID → encode in base62 → 7 chars handles 62⁷ ≈ **3.5 trillion** URLs.
```python
ALPH = "0123456789abcdefghijklmnopqrstuvwxyzABC...XYZ"  # 62 chars
def encode(n):
    s = ""
    while n > 0: s = ALPH[n%62] + s; n //= 62
    return s
```
- ✅ No collisions
- ❌ Sequential codes are guessable; mitigate by **shuffling/encrypting** the counter

### Approach C — Distributed Counter
A single auto-increment is a bottleneck. Solutions:
- **Range-based ID allocation** — each app server pre-allocates 1000 IDs from a central source (ZooKeeper / DB sequence).
- **Twitter Snowflake** — 64-bit ID = `[timestamp | machine_id | sequence]`.
- **UUID** → too long for short URL; encode/truncate.

---

## Step 5 — Storage

| Data | Store | Why |
|---|---|---|
| `short_code → long_url` | KV store (Redis cache + Cassandra/DynamoDB) | huge volume, fast lookup |
| Custom aliases | RDBMS or unique index in KV | enforce uniqueness |
| Click analytics | Kafka → time-series DB / data warehouse | append-only, async |

Schema:
```
url(short_code PK, long_url, user_id, created_at, expires_at)
```

---

## Step 6 — High-Level Architecture

```
                   ┌─── CDN/edge cache (popular short URLs)
                   ▼
[Client] ──▶ [LB] ──▶ [API Gateway]
                          ├─▶ Write Service ──▶ [ID Generator]
                          │                     └─▶ [DB cluster (sharded)]
                          ├─▶ Read Service  ──▶ [Redis cache] ──miss──▶ DB
                          └─▶ Analytics:    ──▶ [Kafka] ──▶ [ClickHouse / BigQuery]
```

---

## Step 7 — Key Design Decisions

### Why Redis cache?
- Read:write = 100:1, popular URLs hit billions of times
- Cache hit rate >95% achievable; ~1ms reads vs ~10ms DB

### Why Kafka for analytics?
- Don't slow down redirect for analytics
- Each click → produce event → consumer aggregates async

### Why sharded DB?
- 3 TB across years, 12K QPS reads. Shard by `short_code` (consistent hash).

### 301 vs 302 redirect?
- **301 (permanent)** — browsers cache → fewer hits to your service → fewer analytics
- **302 (temporary)** — every click hits your service → accurate analytics
- Most shorteners use **302**.

---

## Step 8 — Failure & Edge Cases

- **Custom alias collision** → atomic check-and-set in DB.
- **ID generator down** → multiple generators with different ranges; or fallback to UUIDs.
- **Hot URL** (viral link) → CDN caches the redirect; replicate hot key in cache.
- **Cache stampede** when popular URL expires → SWR or per-key lock.
- **Abuse / spam URLs** → URL safety check (Google Safe Browsing API), rate limit per IP.
- **GDPR / take-downs** → soft-delete with 410 Gone response.

---

## Step 9 — Scaling Story (full picture)

1. Start: single Postgres + counter
2. Add Redis cache → 95% reads served fast
3. Move analytics off the hot path → Kafka
4. Shard DB by `short_code`
5. Add CDN for hottest URLs
6. Multi-region for global users (geo-route + replicate)

---

## 🎤 Likely Follow-ups

1. *"Why base62, not base64?"* → 64 includes `+` and `/` — not URL-safe.
2. *"How do you avoid two requests getting the same code?"* → unique index + retry, or pre-allocated ranges per server.
3. *"How do you scale write throughput?"* → distributed ID generator + sharded DB.
4. *"How is analytics computed?"* → Kafka → stream processor (Flink/Spark) → time-series DB.
5. *"Latency target?"* — redirect <30ms global. Cache + CDN make this possible.

---

## 🧾 Cheat Card

```
Pattern stack:
  base62 + counter / Snowflake → short codes
  Redis cache + sharded KV     → reads
  Kafka + ClickHouse           → analytics
  CDN                          → hottest URLs
  302 redirect                 → accurate metrics

Bottleneck order: ID gen → cache → DB → network
```

➡️ **Next:** [HLD 9 — Instagram / Twitter Feed](./09-case-instagram.md)
