# HLD Chapter 3 — The Caching Story 🧠⚡

> *"The fastest request is the one you never make."*

A cache is a small, fast layer in front of a slow, large one. In interviews, **adding a cache** is often the cheapest 10× speedup you can propose.

---

## Where caches live (everywhere!)

```
[Browser] ──▶ [CDN] ──▶ [Reverse Proxy] ──▶ [App-level cache] ──▶ [Distributed cache: Redis] ──▶ [DB cache] ──▶ [Disk]
```

Each layer hits something faster. The trick is **picking the right one** for the data.

---

## 5 Caching Strategies (★ memorize)

### 1. Cache-aside (Lazy loading) — most common
```
Read:  app → cache; on miss → DB → fill cache → return
Write: app → DB; invalidate cache (or update)
```
✅ Simple, only cache what's used.
❌ First read is slow ("cold cache"). Risk of stale data on writes.

### 2. Read-through
The cache itself fetches from DB on miss. App only talks to cache.
✅ Cleaner code. ❌ Cache must know how to read DB.

### 3. Write-through
Writes go to cache **and** DB synchronously.
✅ Cache always fresh. ❌ Slower writes.

### 4. Write-behind / Write-back
Writes go to cache; **async** flushed to DB later.
✅ Fast writes, batches updates. ❌ Risk of data loss if cache dies.

### 5. Refresh-ahead
Cache proactively refreshes hot keys before expiry.
✅ Hides cold-cache latency. ❌ Wasted work for unused keys.

---

## Eviction Policies

When cache is full, who gets kicked out?

- **LRU** (Least Recently Used) — most common, good general-purpose
- **LFU** (Least Frequently Used) — best when access frequency matters
- **FIFO** — simple
- **TTL-based** — items expire after time
- **Random** — surprisingly OK at scale

Redis supports all of these (`maxmemory-policy`).

---

## TTL & Invalidation — the hardest problem

> *"There are only two hard things in CS: cache invalidation and naming things."* — Phil Karlton

Strategies when DB updates:
- **TTL only** — eventually consistent. Simple. Used widely.
- **Explicit invalidate** on write — `DEL cache_key` after DB update. Race conditions possible.
- **Write-through** — never stale, but slower writes.
- **Versioned keys** — `user:42:v3` — old versions naturally expire.

---

## Cache Pitfalls (★ interview gold)

### 🔥 Cache Stampede / Thundering Herd
A popular key expires → 10,000 concurrent requests miss → all hit DB → DB melts.
**Fix:**
- **Lock**: only one request rebuilds, others wait
- **Stale-while-revalidate**: serve old value while one fetches new
- **Probabilistic early refresh**

### 🥶 Cache Penetration
Requests for keys that **don't exist anywhere** (e.g., probing user IDs). Always miss → always hits DB.
**Fix:**
- Cache **negative** results (`null` with short TTL)
- **Bloom filter** in front

### 🌪️ Cache Avalanche
Many keys expire at same time → mass DB hit.
**Fix:** add **jitter** to TTLs (`TTL = base + rand`).

### 🥵 Hot Key Problem
One key (celebrity user, viral post) gets billions of reads → single Redis shard saturates.
**Fix:**
- **Replicate** the key across N copies, read random one
- Push the value to local in-memory cache on each app server

---

## CDN — Cache at the Edge

CDN = a global network of cache servers near users.
- Stores **static** assets (images, JS, CSS, video).
- Increasingly: dynamic edge functions (Cloudflare Workers).
- **Push** model: you upload to edges proactively.
- **Pull** model: edge fetches from origin on first miss, caches.

Cache control via HTTP headers:
```
Cache-Control: public, max-age=86400, immutable
ETag: "abc123"
```

---

## Redis — the swiss army knife

Use Redis for:
- Cache (KV with TTL)
- Sessions
- Rate limiting (counters, token buckets)
- Leaderboards (sorted sets)
- Real-time analytics (HyperLogLog, streams)
- Pub/Sub messaging
- Distributed locks (`SETNX` or Redlock)

Memcached vs Redis: Memcached is simpler and slightly faster for plain KV; Redis adds rich data types & persistence.

---

## Capacity Planning Example

App handles 10K QPS with 80% cache hit rate.
- Cache hits → 8K QPS to Redis (~0.5ms each)
- Cache misses → 2K QPS to DB (~10ms each)
- Without cache: 10K QPS to DB → DB likely dies.

**Hit rate is everything.** Aim for >90% on hot data.

---

## 🎤 The Interview Lens

- *"How do you keep the cache consistent?"* → Discuss strategies; honestly say "eventual consistency with short TTL is usually fine."
- *"What if Redis goes down?"* → fallback to DB (graceful degradation), Redis cluster with replication, automatic failover.
- *"How do you cache user-specific data?"* → key by user ID, short TTL, invalidate on profile update.
- *"How would you cache infinitely scrolling feeds?"* → cache page-by-page or by cursor; pre-warm hot users' feeds.

---

## 🧾 Cheat Card

```
Strategies   : cache-aside (most common), read-through, write-through, write-behind, refresh-ahead
Eviction     : LRU, LFU, TTL, FIFO, Random
Pitfalls     : stampede (lock/SWR), penetration (bloom/negative cache), avalanche (jitter), hot key (replicate)
Layers       : browser → CDN → app local → distributed (Redis) → DB
Tools        : Redis, Memcached, Varnish (HTTP), Cloudflare/CloudFront (CDN)
Hit rate >90%? you're winning.
```

➡️ **Next:** [HLD 4 — Load Balancers & Proxies](./04-load-balancers-and-proxies.md)
