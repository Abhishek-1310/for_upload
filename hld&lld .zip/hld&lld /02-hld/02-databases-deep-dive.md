# HLD Chapter 2 — Databases Deep Dive 🗄️

> If you can confidently answer *"SQL or NoSQL? Why? How would you shard it?"* — you've already passed half the interview.

---

## 🔵 SQL (Relational) — Postgres, MySQL, Oracle

**Mental model:** rigid tables, foreign keys, ACID transactions, joins.

✅ Use when:
- Relationships matter (users ↔ orders ↔ items)
- Strong consistency, transactions (banking, inventory)
- Complex queries / reporting (joins, aggregations)
- Schema is mostly stable

⚠️ Pain points at scale:
- Joins across shards are slow
- Schema migrations on huge tables = risky

---

## 🟢 NoSQL — Many flavors

| Type | Example | Best for |
|---|---|---|
| **Key-Value** | Redis, DynamoDB | cache, sessions, leaderboards |
| **Document** | MongoDB, Couchbase | flexible JSON, content mgmt |
| **Wide-column** | Cassandra, HBase, Bigtable | huge write QPS, time-series |
| **Graph** | Neo4j, JanusGraph | social networks, fraud rings |
| **Search** | Elasticsearch, OpenSearch | full-text, log analytics |

✅ Use NoSQL when:
- Massive horizontal scale
- Schema evolves often
- Workload fits a specific access pattern (key lookup, time-range)
- You don't need multi-row ACID across many entities

---

## 🆚 SQL vs NoSQL Decision Tree

```
Need multi-row ACID transactions?      → SQL
Need flexible/unknown schema?           → Document NoSQL
Need 1M+ writes/sec, simple lookups?    → Wide-column NoSQL
Need full-text search / fuzzy matching? → Elasticsearch
Need relationship traversal (friends-of-friends)? → Graph DB
Default for OLTP web app at moderate scale? → Postgres (SQL) — it scales further than people think
```

> Common interview answer that wins points: *"I'd start with Postgres because it scales surprisingly far and gives me ACID. I'd add specialized stores (cache/search/blob) only when justified by access patterns."*

---

## ACID vs BASE

### ACID (SQL)
- **A**tomicity — all or nothing
- **C**onsistency — invariants preserved
- **I**solation — concurrent txns don't interfere
- **D**urability — once committed, persisted

### BASE (NoSQL)
- **B**asically **A**vailable
- **S**oft state
- **E**ventual consistency

NoSQL trades strict consistency for availability and scale. (More in CAP chapter.)

---

## 📐 Indexes (the speed-up secret)

A DB index is like a book's index — finds rows by key in O(log N) instead of scanning.

```sql
CREATE INDEX idx_orders_user_id ON orders(user_id);
```

- **B-Tree** index (default): great for `=`, `<`, `>`, range
- **Hash** index: only `=`
- **Composite** `(user_id, created_at)`: queries using prefix benefit
- **Covering** index: includes all columns needed → no row lookup

⚠️ Trade-off: indexes speed up reads but slow down writes (every insert updates each index). Don't add blindly.

---

## 🔀 Replication (Reliability + Read scale)

```
[Master] ──async/sync replication──▶ [Replica 1, Replica 2 ...]
   ↑ writes                                ↑ reads
```

**Modes:**
- **Synchronous** — master waits for replica ack. Strong consistency, slow writes.
- **Asynchronous** — fast, but replica lag → stale reads possible.
- **Semi-synchronous** — wait for at least one replica.

**Failover:** if master dies, promote a replica (manual or via Patroni / RDS automated failover).

---

## 🍰 Sharding (Horizontal Partitioning)

When one DB can't hold or serve the data, split it.

### Strategies

1. **Hash-based** (`hash(user_id) % N`)
   - ✅ Even distribution
   - ❌ Resizing reshuffles everything → use **consistent hashing**

2. **Range-based** (`user_id 1-1M → shard1, 1M-2M → shard2`)
   - ✅ Range scans efficient
   - ❌ Hot spots if data isn't uniform

3. **Geo-based** (by region)
   - ✅ Low latency for users
   - ❌ Cross-region complexity

4. **Directory-based** (lookup service decides)
   - ✅ Flexible
   - ❌ Lookup service is now critical

### Consistent Hashing (★ favorite interview topic)

Place servers and keys on a **virtual ring (0 to 2³²-1)**. Each key goes to the next server clockwise. Adding/removing a server only re-maps a small slice of keys.

Use **virtual nodes** (each physical server represented by 100+ points on the ring) for even distribution.

**Used by:** DynamoDB, Cassandra, memcached clients, CDNs.

---

## 🧊 Vertical vs Horizontal Partitioning

- **Vertical** — split *columns*: rarely-used columns to a side table.
- **Horizontal (sharding)** — split *rows*: each shard has same schema, subset of rows.

---

## 🛡️ Transactions & Isolation Levels

Going from least to most strict:

| Level | Allows | Prevents |
|---|---|---|
| Read Uncommitted | dirty reads | nothing |
| Read Committed (default in Postgres) | non-repeatable reads | dirty reads |
| Repeatable Read (default in MySQL) | phantom reads | non-repeatable |
| Serializable | nothing weird | everything (slowest) |

**Phantom read** — same query returns different rows because another txn inserted in between.

For distributed systems: use **2-Phase Commit (2PC)** or **Sagas** (preferred for microservices).

---

## 🧮 Capacity Estimation Skill

Always estimate. Example: *"A social app with 100M DAU, 10 posts read per user/day"*:

```
Reads/day  = 100M × 10 = 1B reads/day
Reads/sec  ≈ 1B / 86400 ≈ 11.6K QPS  (avg)
Peak       ≈ 3× avg ≈ 35K QPS
With 10:1 read:write → writes ≈ 3.5K QPS
```

Storage: 1B posts × 1KB ≈ 1TB/day. Plan accordingly.

---

## 🎤 Common Interview Questions

1. **"SQL or NoSQL for X?"** → Justify with access patterns + consistency needs.
2. **"How would you shard?"** → Pick strategy, mention consistent hashing for hash-based.
3. **"What's the difference between replication and sharding?"** → Replication = copies for availability/reads. Sharding = splitting data for capacity.
4. **"How do you handle replication lag?"** → Read-from-master for read-after-write; or session pinning.
5. **"How would you migrate from one schema to another with zero downtime?"** → Dual-write → backfill → dual-read → cutover → cleanup.

---

## 🧾 Cheat Card

```
SQL: ACID, joins, fixed schema     → Postgres/MySQL
NoSQL: scale, flex, BASE
   KV       → Redis, DynamoDB
   Doc      → MongoDB
   Column   → Cassandra (huge writes)
   Graph    → Neo4j
   Search   → Elasticsearch

Scale tools:
   Replication  → reads + reliability
   Sharding     → writes + capacity (consistent hashing!)
   Indexes      → fast lookups (cost: slower writes)

ACID levels: read-uncommitted < committed < repeatable-read < serializable
```

➡️ **Next:** [HLD 3 — Caching Story](./03-caching-story.md)
