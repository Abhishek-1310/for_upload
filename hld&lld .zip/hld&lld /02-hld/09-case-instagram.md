# HLD Chapter 9 — 📸 Case Study: Instagram / Twitter Feed

> The "social feed" is the most pattern-rich HLD problem. Master fan-out, timelines, and ranking.

---

## Step 1 — Clarify

- Users post (text/image/video)
- Users follow others
- Home feed = posts from followed users, reverse-chronological (later: ranked)
- Likes, comments
- Scale: ~500M DAU, average user follows 200, posts 1/day

---

## Step 2 — Estimate

- 500M × 1 post = **500M posts/day** ≈ 6K writes/sec avg, 20K peak
- Each user opens feed 5×/day → 2.5B feed reads/day ≈ 30K read QPS
- Storage: 500M × 1KB metadata = 500GB/day; images on **Object Store (S3)** + CDN.

---

## Step 3 — Core Services

```
[Mobile/Web] ──▶ [API Gateway] ──┬──▶ User Service
                                  ├──▶ Post Service       ── posts → DB + S3 (media)
                                  ├──▶ Follow Service     ── graph DB / table
                                  ├──▶ Feed Service       ── timeline assembly
                                  ├──▶ Like / Comment svc
                                  └──▶ Notification svc
                                  
                  Kafka <──── post.created event ────▶ Fan-out workers
                                                              ▼
                                                       [User timeline cache]
```

---

## Step 4 — The Big Question: How to Build the Feed?

### Option A — Pull / Fan-out on Read
At read time: query posts of all followees, merge, sort, return.
- ✅ Cheap writes
- ❌ Reads heavy: a user with 500 followees → 500 queries → expensive
- ❌ Bad latency for active users

### Option B — Push / Fan-out on Write (★ Twitter/Insta style)
When user A posts → for each follower of A, push the post into their pre-computed timeline cache (Redis list).
- ✅ Reads are O(1): just read your timeline list
- ❌ Expensive writes for users with many followers (celebrity → 100M pushes!)

### Option C — Hybrid (★ what real systems do)
- For **normal users**, fan-out on write (push)
- For **celebrities** (followers > 1M), fan-out on read (pull)
- At read time, merge: pre-computed timeline + recent posts from celebs the user follows

> This solves the **"Justin Bieber problem"** — a single celebrity post would take hours to push to 100M timelines.

---

## Step 5 — Storage Choices

| Data | Store | Reason |
|---|---|---|
| Users | Postgres / DynamoDB | structured, low volume |
| Posts | Cassandra / DynamoDB | huge writes, time-series-ish |
| Follow graph | sharded MySQL / Cassandra (by user_id) | huge fan-out reads |
| Timeline (per user) | Redis sorted set (cap to ~1000 most recent) | O(1) reads |
| Media (images/videos) | S3 + CDN | large blobs |
| Search (hashtags, captions) | Elasticsearch | full-text |
| Counters (likes, views) | Redis HyperLogLog / atomic counters; eventual flush to DB |

---

## Step 6 — Posting Flow

```
1. POST /post
2. Upload media → S3 (returns URL)
3. Save post in Cassandra (post_id = Snowflake ID)
4. Publish event "post.created" to Kafka
5. Return success
   
Async (consumers of Kafka):
   - Fan-out worker: for each follower, LPUSH timeline:{user} post_id; LTRIM to 1000
   - Notification worker: push notif to followers (subset)
   - Search indexer: index caption/hashtags into Elasticsearch
   - Analytics: count posts, etc.
```

---

## Step 7 — Reading the Feed

```
GET /feed?cursor=...
  1. Read timeline:{user} from Redis (post_ids, paginated)
  2. For celebrity follows, query their recent posts directly (cached separately)
  3. Merge & sort by timestamp
  4. Hydrate post details (Redis cache → Cassandra fallback)
  5. Apply ranking (later)
  6. Return
```

Latency target: **<200ms p99**.

---

## Step 8 — Ranking (the modern feed)

Simple chronological is "old". Real systems rank by:
- Recency
- User's past engagement with author (likes/comments)
- Post engagement velocity (likes/min)
- Content type preference (video over text?)
- ML model output

Implementation: candidate generation (1000 posts) → light ranking → heavy ML scoring → return top 50.

This is its own ML pipeline — mention it, don't over-engineer in interview.

---

## Step 9 — Scale Tricks

- **Cap timeline length** — only keep latest 1000 in Redis; older from Cassandra.
- **Pre-compute** for active users only (LRU eviction for inactive).
- **CDN** for images/videos; thumbnails generated async on upload.
- **Edge caching** of user profile / public posts.
- **Cassandra clustering key** = `(user_id, created_at DESC)` for fast "user's recent posts".
- **Sharding follow graph** by user_id; followee list might be huge for celebs → store separately.

---

## Step 10 — Failure & Edge Cases

- **User unfollows** → timelines have stale posts. Fix: filter at read time, or rebuild timeline lazily.
- **Deleted post** → mark deleted; readers filter; eventually purged.
- **Hot celebrity post** → cache aggressively at edge.
- **Duplicate posts on retry** → idempotency key on POST.
- **Spam / abuse** → rate-limit posting per user; ML-based moderation.

---

## 🎤 Likely Follow-ups

1. *"How do you handle the celebrity problem?"* → hybrid push/pull.
2. *"What if Redis goes down?"* → rebuild from Cassandra (slow, degraded mode).
3. *"How to ensure feed shows 'read-your-writes'?"* → for own posts, prepend from local cache or query own posts directly.
4. *"How to support stories / ephemeral content?"* → similar but with TTL on entries.
5. *"Comments on posts — show top N first?"* → separate Comments service; sort by likes/relevance.

---

## 🧾 Cheat Card

```
Feed strategy: hybrid push/pull (push for normal, pull for celebs)
Stores       : Cassandra (posts), Redis (timelines), S3 (media), ES (search)
Async        : Kafka for fan-out, notifications, search indexing
Sharding     : by user_id
Caching      : timeline, profile, hot posts; CDN for media
Latency      : <200ms p99 feed read
```

➡️ **Next:** [HLD 10 — WhatsApp](./10-case-whatsapp.md)
