# HLD Chapter 5 — Message Queues & Async Systems 📨

> *"If you don't need it now, don't do it now."* — the asynchronous philosophy.

---

## The Problem They Solve

A user uploads a video on Bookly:
- Save metadata to DB ✅ fast
- Generate 5 thumbnails 🐢 5 seconds
- Transcode to 4K/1080p/720p 🐢 5 minutes
- Send notification emails 🐢 1 second
- Update search index 🐢 2 seconds

If you do this **synchronously**, the user waits 5+ minutes for "Upload complete." Disaster.

**Solution:** save metadata immediately → drop a *message* on a queue → workers do the slow stuff later.

```
[App] ──save metadata──▶ [DB]
[App] ──"new video v123"──▶ [Queue] ──▶ [Worker pool]
                                         ├─ thumbnail worker
                                         ├─ transcode worker
                                         ├─ email worker
                                         └─ index worker
```

Response to user: **instant**. Background work: parallel.

---

## Two Big Models

### 1. Message Queue (point-to-point)
Each message goes to **one** consumer. Used for tasks/jobs.
> RabbitMQ, AWS SQS, Redis Lists, Beanstalkd

### 2. Pub/Sub (publish/subscribe)
Each message goes to **all** subscribers. Used for events.
> Kafka, Google Pub/Sub, Redis Pub/Sub, NATS

> **Kafka** uniquely handles both via consumer groups + log retention. It's the de-facto standard for event streaming.

---

## Why Async / Queues?

- ⚡ **Fast responses** — heavy work moved off the request path
- 🛡️ **Decoupling** — producer doesn't know consumer details
- 📈 **Smoothing** — buffer spikes (queue absorbs burst)
- 🔁 **Retries** — failed consumers retry without losing message
- 📊 **Replay** — Kafka lets you re-process history (e.g., rebuild a cache, fix a bug)
- 🧩 **Fan-out** — many services react to one event

---

## Delivery Guarantees (★ critical interview concept)

- **At-most-once** — fire and forget. Loss possible. (rare)
- **At-least-once** — retried until ack. **Duplicates possible.** Most common.
- **Exactly-once** — no loss, no dup. Hard. Kafka achieves it within Kafka with transactions; end-to-end requires **idempotent consumers**.

> 🧠 Always design consumers to be **idempotent** — processing same message twice produces same result. (Use a `processed_message_id` table, or upserts.)

---

## Ordering

- Kafka guarantees order **within a partition**. Use a key (e.g., `user_id`) so all messages for that user go to the same partition.
- RabbitMQ guarantees order within a single queue if there's one consumer.
- Across partitions/queues — no global ordering guarantees.

---

## Kafka in 90 seconds

```
Producer ──▶ [ Topic ]  (split into N partitions)
                  ├─ partition 0: msg msg msg ...
                  ├─ partition 1: msg msg ...
                  └─ partition 2: msg ...
                  ▼
              [ Consumer Group ]
                  ├─ consumer A → partition 0
                  ├─ consumer B → partition 1
                  └─ consumer C → partition 2
```

- **Topic** = channel. **Partition** = parallel log. **Consumer Group** = scale-out unit.
- Messages are **persisted** on disk for retention period (days). You can re-read them.
- **Offset** = position; consumer commits offsets to track progress.
- Replication factor (e.g., 3) = each partition copied to 3 brokers for HA.

---

## Common Patterns

### 1. Work Queue
N consumers pull tasks; each task done by one consumer.

### 2. Pub/Sub Fan-out
One event ("OrderPlaced") → multiple services react (inventory, notifications, analytics).

### 3. Event Sourcing
**Store the events**, not the current state. Replay them to derive state. Powerful for audit, rebuild, time-travel debugging.

### 4. CQRS (Command Query Responsibility Segregation)
Writes go through one model (commands → events). Reads come from a separate optimized read store (built from events). Common in event-sourced systems.

### 5. Saga (distributed transaction without 2PC)
Long-running flow split into local transactions. Each step has a **compensating action** if a later step fails.
> Example: book flight → book hotel → if hotel fails, *cancel flight*.

### 6. Outbox Pattern
DB write + publishing event in one atomic step:
1. App writes to DB **and** an `outbox` table in same transaction.
2. Separate process (or CDC tool) reads outbox → publishes to Kafka.

Solves "DB committed but Kafka publish failed" problem.

### 7. Dead Letter Queue (DLQ)
Messages that fail after N retries → DLQ for manual inspection. Always have one!

---

## Choosing the Right Tool

| Need | Pick |
|---|---|
| Simple background jobs | **SQS / RabbitMQ / Redis** |
| Event streaming, replay, analytics | **Kafka** |
| Lightweight microservice events | **NATS** |
| Cloud-managed pub/sub | **Google Pub/Sub / SNS+SQS** |
| Log shipping | **Kafka / Kinesis** |

---

## ⚠️ Pitfalls

- **Without idempotency**, at-least-once → duplicate side effects (charging twice 😱)
- **Slow consumer** → queue grows unbounded → memory blow up. Monitor lag.
- **Poison pills** — bad messages crash the consumer in a loop. Use retries with backoff and DLQ.
- **Ordering needs** are subtle — check before partitioning.
- **Backpressure** — if downstream slow, producers must slow down or buffer (Kafka does this naturally).

---

## 🎤 The Interview Lens

- *"Why did you add Kafka?"* — decouple, smoothing, replay, fan-out.
- *"What if a message is processed twice?"* — make consumer idempotent; use unique IDs.
- *"How do you handle ordering?"* — partition key.
- *"How would you implement notifications/emails?"* — push event to queue; worker sends email; retry on failure; DLQ for poison.
- *"DB and Kafka in same transaction?"* — Outbox pattern.

---

## 🧾 Cheat Card

```
Async win  : fast response, decouple, smooth, retry, replay, fan-out

Models     : queue (one consumer), pub/sub (all consumers)
Tools      : Kafka (streams), RabbitMQ/SQS (jobs), Redis (light)

Guarantees : at-most-once, at-least-once (default), exactly-once (hard)
Order      : per-partition (use key)

Patterns   : work queue, pub/sub, event sourcing, CQRS, saga, outbox, DLQ
Always     : idempotent consumers + DLQ + monitor lag
```

➡️ **Next:** [HLD 6 — CAP, PACELC & Consistency](./06-cap-pacelc-consistency.md)
