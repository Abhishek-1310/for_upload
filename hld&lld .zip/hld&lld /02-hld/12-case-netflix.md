# HLD Chapter 12 — 🎥 Case Study: Netflix / Video Streaming

> Tests **CDN, video pipelines, adaptive streaming, recommendations**.

---

## Step 1 — Clarify

- 250M users globally, watch ~2 hr/day
- Catalog: ~10K titles, each available in many resolutions/codecs/languages
- Users browse, search, watch (start/pause/resume), get recommendations
- DRM-protected content
- 4K, HDR, mobile, smart TV

---

## Step 2 — Estimate

- Avg bitrate 5 Mbps × 250M concurrent peak (say 50M concurrent) = 250 Tbps egress!
- This is why **CDN dominates** — almost all traffic served from edges, not origin.

---

## Step 3 — High-Level Architecture

```
[Devices] ─┬─▶ [CDN Edge: Open Connect] ── video chunks (HLS/DASH)
           └─▶ [API Gateway]
                   ├─▶ Catalog Svc
                   ├─▶ User Svc
                   ├─▶ Playback Svc (auth, license, manifest)
                   ├─▶ Recommendation Svc
                   ├─▶ Continue-Watching / History Svc
                   └─▶ Search Svc
                        ▲
                        │
        [Recommendation ML pipeline] ◀── Kafka events ── viewing telemetry
                        │
                  [Cassandra / S3 / data lake]
```

---

## Step 4 — Video Ingest Pipeline (offline)

When a new title is uploaded:
```
1. Upload master file (huge, lossless) → S3
2. Trigger transcoding pipeline (AWS Elemental / FFmpeg cluster)
   - Multiple resolutions: 240p, 480p, 720p, 1080p, 4K
   - Multiple codecs: H.264, H.265 (HEVC), VP9, AV1
   - Multiple bitrates per resolution
3. Segment into 2-10 sec chunks (HLS .ts / DASH .m4s)
4. Generate manifest files (.m3u8 / .mpd) listing chunks + bitrates
5. Encrypt chunks (DRM: Widevine/PlayReady/FairPlay)
6. Push to CDN (Open Connect Appliances at ISPs)
```

Result: thousands of files per title, totaling many GBs.

---

## Step 5 — Adaptive Bitrate Streaming (★)

Why: a viewer's bandwidth varies (4G → 5G → wifi). The player auto-switches.

- Player downloads manifest → list of bitrates
- Picks chunk based on measured network speed + buffer health
- Each chunk independent → can switch bitrate at any chunk boundary
- Standards: **HLS** (Apple), **MPEG-DASH** (open)

---

## Step 6 — CDN — the heart of Netflix

Netflix runs **Open Connect** — its own CDN. Boxes deployed inside ISPs (peering directly with viewers). Most popular content pre-positioned ("filling") during off-peak hours.

```
[Viewer] ─ shortest path ─ [ISP-local OCA] ─ if miss → [Regional cache] → [Origin in S3]
```

99%+ of traffic served from the **closest cache**. Origin sees almost nothing.

---

## Step 7 — Playback Flow

```
1. User clicks Play
2. Playback Svc:
   a. Verify subscription/region (geo-block)
   b. Issue DRM license (encrypted decrypt key)
   c. Return manifest URL pointing to nearest CDN edge
3. Player fetches manifest → starts streaming chunks
4. Periodic heartbeats: progress, buffer, errors → Kafka
```

---

## Step 8 — User Data

| Data | Store |
|---|---|
| User profile, subscription | Postgres / DynamoDB |
| Continue Watching (per profile) | Cassandra (PK by user_id) |
| Viewing history | Cassandra + S3 archival |
| Watch events stream | Kafka → Flink → analytics + ML features |
| Search index | Elasticsearch |

---

## Step 9 — Recommendations

- Offline batch: collaborative filtering, matrix factorization, deep learning models trained nightly on watch history
- Online: feature store + model serving for real-time re-ranking
- Personalized homepage rows: "Trending in India", "Because you watched X"
- Even artwork is personalized (different thumbnail per user!)

For HLD interview, mention pipeline:
```
Kafka events → Spark/Flink → Feature store + Model training (offline) → Model serving (online) → Re-rank rows
```

---

## Step 10 — Search

- Elasticsearch index for titles, casts, descriptions
- Auto-complete via prefix index
- Personalized ranking applied on top

---

## Step 11 — Edge Cases & Reliability

- **CDN edge fails** → player retries with next-nearest from manifest
- **Bandwidth drop** → ABR auto-switches to lower bitrate
- **Multiple devices** → continue-watching synced via centralized service
- **Region licensing** → geo-IP check; titles available per region
- **Pirate copies** → DRM + watermarking
- **Failovers** → multi-region active-active for control plane

---

## Step 12 — Chaos & Reliability culture

Netflix popularized **Chaos Engineering** — Chaos Monkey randomly kills servers in production to ensure resilience. Mention this as a culture point if asked about reliability.

---

## 🎤 Likely Follow-ups

1. *"Why segment video?"* — adaptive bitrate, parallel CDN delivery, partial caching, restartable.
2. *"How is DRM enforced?"* — encrypted chunks; license server issues key bound to device.
3. *"Why HLS over progressive download?"* — adaptive, partial caching, encrypted, standard.
4. *"How do you serve a sudden global hit?"* — pre-fill OCAs, scale origin slightly, rely on CDN tiered cache.
5. *"Live streaming differences?"* — same chunk model, but real-time encoding; ultra-low-latency variants (LL-HLS, WebRTC).

---

## 🧾 Cheat Card

```
Pipeline    : ingest → transcode (multi bitrate/codec) → segment → encrypt → push to CDN
Delivery    : Open Connect / CDN edges close to ISPs (>99% hit rate)
Streaming   : HLS / DASH adaptive bitrate, 2-10s chunks
Playback    : auth + DRM license + manifest URL
Data        : Cassandra (history), Kafka (events), S3 (master files), ES (search)
ML          : offline training, online serving for personalization
Reliability : multi-region, chaos engineering, ABR fallback
```

➡️ **Next:** [HLD 13 — Notification System](./13-case-notification-system.md)
