# HLD Chapter 7 — Microservices vs Monolith 🧱 vs 🪙🪙🪙

> The most over-asked, over-debated HLD topic. Here's the **honest** take.

---

## The Monolith

One codebase, one deployable, one DB.

```
┌─────────────────────────────┐
│         Monolith App        │
│  ┌──────┬──────┬─────────┐  │
│  │ User │ Order│ Payment │  │
│  │ mod  │ mod  │ mod     │  │
│  └──────┴──────┴─────────┘  │
└─────────────────────────────┘
            │
        [ One DB ]
```

✅ Pros:
- Simple to develop, test, deploy
- Refactoring across modules is easy
- One transaction = atomic
- Lower ops cost, perfect for small teams

❌ Cons (at scale):
- Slow build / deploy as it grows
- Single failure can crash everything
- Hard to scale independently (can't add 10 servers just for payment)
- Tech stack locked in

---

## Microservices

Many small services, each with its own DB and deploy lifecycle. Communicate over network (HTTP/gRPC/queues).

```
[ User svc ] ── [ Order svc ] ── [ Payment svc ] ── [ Notif svc ]
    │              │                 │                  │
   DB1            DB2               DB3                DB4
```

✅ Pros:
- Independent deploy (team A doesn't block team B)
- Scale services independently
- Polyglot — different language/DB per service
- Fault isolation (one crash doesn't down everything)

❌ Cons:
- **Distributed system complexity** — networks fail, latency, partial failures
- **Data consistency is hard** — no cross-service transactions; need sagas
- **Operational overhead** — observability, deployment, networking, service mesh
- **Debugging** is hard (one user request → 20 services)
- **Latency tax** — every call is now a network hop

> ⚠️ Famous quote: *"Microservices are not free."* Most startups should NOT start with microservices.

---

## Modular Monolith — the underrated middle path

One deployable, but **strict module boundaries** in code (separate packages, well-defined interfaces, possibly separate DB schemas).

✅ Most benefits of monolith with most benefits of microservices, **without** the network pain. Easy to extract into microservices later if needed.

> **Recommended starter architecture for 90% of projects.**

---

## When to break out a microservice?

Trigger signals:
- One module needs **independent scaling** (e.g., video transcoding eats CPU)
- One module has **different security/compliance** needs (PCI for payments)
- A separate **team** owns it
- Different **release cadence** (mobile API ships daily; back office monthly)
- Legacy module needs rewrite (strangler pattern)

If none apply → keep it in the monolith.

---

## Service Communication

| Pattern | When |
|---|---|
| **Sync REST/gRPC** | request-response, low latency, strong coupling | 
| **Async via Queue/Kafka** | events, decoupled, replayable |
| **GraphQL gateway** | clients need flexible queries, BFF pattern |

Best practice: **prefer async events** for state changes; sync only when caller really needs immediate response.

---

## Data Ownership Rule

> *"Each microservice owns its DB. Other services may NEVER read/write that DB directly."*

If service B needs data from service A:
- Call service A's API (sync), or
- Subscribe to service A's events and maintain a local view (async, eventual)

Sharing a DB across services = **distributed monolith** = worst of both worlds.

---

## Cross-cutting concerns in microservices land

You'll need:
- **Service discovery** — Consul, Kubernetes DNS, Eureka
- **Service mesh** — Istio, Linkerd (mTLS, retries, observability between services)
- **Distributed tracing** — Jaeger, Zipkin, OpenTelemetry
- **Centralized logging** — ELK / Loki
- **Metrics** — Prometheus + Grafana
- **CI/CD per service** — independent pipelines
- **API gateway** at the edge (covered in Chapter 4)

---

## Common Microservices Patterns

- **Saga** — distributed long-running transaction (chapter 5)
- **CQRS + Event Sourcing** — separate write/read models (chapter 5)
- **Outbox** — atomic DB+event publish (chapter 5)
- **Strangler Fig** — gradually replace a legacy monolith by routing traffic to new services
- **Backend for Frontend (BFF)** — gateway tailored per client
- **Sidecar** — auxiliary container alongside service (e.g., Envoy proxy in service mesh)

---

## 🎤 The Interview Lens

- *"Monolith or microservices for your design?"* → **Don't reflexively say microservices.** Justify based on team size, growth, scaling profile.
- *"How do services communicate?"* → Sync vs async with trade-offs.
- *"How do you handle distributed transactions?"* → Saga + outbox + idempotency.
- *"How do you debug across services?"* → Tracing with correlation IDs (OpenTelemetry).
- *"How do you avoid a 'distributed monolith'?"* → No shared DBs, well-defined APIs, async where possible, version contracts.

> A senior answer: *"I'd start as a modular monolith with clean module boundaries. As scale and team size grow, I'd extract specific bounded contexts into services — payment first, due to compliance/scale, then notification, then..."*

---

## 🧾 Cheat Card

```
Monolith     : simple, fast, atomic. Scale ceiling.
Modular Mono : recommended starter for most teams.
Microservices: independent deploy/scale, but distributed-system tax.

Rules:
- Each service owns its DB
- Prefer async events for state changes
- Idempotent APIs everywhere
- Need tracing, metrics, mesh from day one of microservices

Patterns: Saga, Outbox, CQRS, ES, Strangler Fig, BFF, Sidecar
```

🎉 **HLD foundations complete!** Now apply them to real systems.

➡️ **Next:** [HLD 8 — TinyURL](./08-case-url-shortener.md)
