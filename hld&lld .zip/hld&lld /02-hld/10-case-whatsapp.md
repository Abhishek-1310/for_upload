# HLD Chapter 10 — 💬 Case Study: WhatsApp / Chat System

> Real-time messaging for billions. Tests **WebSockets, presence, delivery guarantees, fan-out**.

---

## Step 1 — Clarify

- 1-1 chat + group chat (up to 1000 members, say)
- Online/offline presence
- Read receipts (sent ✓, delivered ✓✓, read ✓✓ blue)
- Last-seen
- Media (image/voice/video)
- E2E encryption (mention, don't deep-dive in HLD)
- Push notifications when offline

---

## Step 2 — Estimate

- 2B DAU, ~40 messages/user/day → 80B messages/day → ~1M QPS write
- Each msg ~100 bytes metadata + maybe media URL
- Storage: 80B × 100B = 8TB/day for messages

---

## Step 3 — Connection Model

WhatsApp/iMessage use **persistent connections** (TCP/WebSocket/MQTT) for instant delivery.

```
[Phone A] ◀─WS─▶ [Edge Gateway 1]               [Edge Gateway K] ◀─WS─▶ [Phone B]
                       │                              │
                       └──────▶ [Message Service] ◀──┘
                                       │
                                  [Cassandra]
                                       │
                                  [Kafka pubsub]
                                  (cross-gateway routing)
```

- Each phone keeps a long-lived connection to one gateway (Edge / Chat Server).
- A user's gateway is tracked in a **session/presence store** (Redis): `user:42 → gateway-7`.

---

## Step 4 — Sending a Message (1-1)

```
1. A sends MSG (to=B, body, client_msg_id) on its WS to Gateway-1
2. Gateway-1 → Message Service:
     a. Validate, store in Cassandra (chat_id, ts, sender, body)
     b. Lookup B's gateway from Redis (user:B → Gateway-7)
     c. If online: forward to Gateway-7 → push to B's socket
        Else: store in B's "pending" queue + send mobile push notif
3. ACK back to A: "sent ✓"
4. When B's app receives: ACK to server → "delivered ✓✓"
5. When B opens chat: server marks read → notify A: "read ✓✓ blue"
```

### Why WebSocket, not HTTP polling?
- Polling = waste + latency. WS = push, low overhead, bi-directional.
- Alternatives: **MQTT** (used by Facebook Messenger — designed for mobile).

---

## Step 5 — Storage Schema

`messages` (Cassandra):
```
PRIMARY KEY ((chat_id), msg_id DESC)
chat_id (1-1: hash of two user_ids; group: group_id)
msg_id  : Snowflake ID (sortable by time)
sender, body/media_url, ts, status (sent/delivered/read)
```

Why Cassandra?
- Append-heavy, time-ordered → wide-column shines
- Easy partitioning by `chat_id`
- Massive write throughput

---

## Step 6 — Group Chat (the fan-out)

When A sends to a group of 1000:
1. Persist message **once** under `chat_id = group_id`
2. Look up group members
3. Fan out to each member's gateway (or queue if offline)

For huge groups, this is one-time cost. For very large broadcasts (channels), use pub/sub:
- Members subscribe to a Kafka/Redis pub-sub topic for the group
- Server publishes once → all gateways receive → push to relevant users

---

## Step 7 — Presence / Last-Seen

- `presence:user_id → online | last_ts` in Redis
- On WS connect → mark online; on disconnect → mark offline + last_ts
- For privacy, expose only to allowed contacts
- Heartbeats every ~30s to detect zombie connections

---

## Step 8 — Read Receipts & Delivery State

Each message has states: `SENT → DELIVERED → READ`. Updates flow back to sender. Stored on the message row (or in a separate per-user table for groups).

For groups, a message is "read" when read by all? Usually shown per-recipient on tap-and-hold.

---

## Step 9 — Media

- Direct upload to S3 / Object Store via presigned URL
- Server stores only the URL + metadata
- CDN delivers media globally

---

## Step 10 — Cross-Gateway Routing

User A on Gateway-1 sends to user B on Gateway-7. How do they find each other?

- **Option 1:** Central session registry (Redis `user → gateway`). Gateway-1 looks up, RPCs Gateway-7.
- **Option 2:** Pub/Sub channel per user: `user:B`. Any gateway publishes; B's gateway subscribes. Decouples gateways.

Real systems use both — Redis for fast routing, Kafka for durability/replay.

---

## Step 11 — Offline / Push Notifications

- If recipient is offline → message stored in DB → flagged as pending
- Send push via APNs (iOS) / FCM (Android) → wakes device → fetches messages
- On reconnect, client requests "messages since last_msg_id" — server returns deltas

---

## Step 12 — End-to-End Encryption (mention)

- Signal Protocol: each device has identity key + pre-keys
- Server stores **encrypted ciphertext only** (can't read it)
- Group key distribution via sender keys
- Implication: server-side search, ML, moderation are limited

---

## Step 13 — Multi-region & DR

- Each region runs its own gateways + DB cluster
- Cross-region replication for message store
- Users home-region based on signup; roam transparently
- Conflict resolution: messages have monotonic IDs (Snowflake) — last writer wins per chat partition

---

## ⚠️ Failure Modes

- Gateway crash → client reconnects to another; pending messages re-pulled
- Redis presence lag → message routes to wrong gateway → falls back via DB queue
- Network partition → messages buffered locally on phone → sent on reconnect (ordering preserved by client_msg_id + server timestamp)
- Duplicate sends → dedupe by `client_msg_id` (idempotency)

---

## 🎤 Likely Follow-ups

1. *"WS vs Long-poll vs SSE?"* — WS: bi-directional. SSE: server→client only. LP: legacy.
2. *"How does presence scale?"* — Redis hash partitioned; eventually-consistent.
3. *"What if user is on 3 devices?"* — multi-device sync → store device list, fan-out to all; merge state.
4. *"Ordering guarantees?"* — per chat (partition) ordering via single-writer or version vectors.
5. *"How to handle 1M-member group?"* — channel/broadcast model, not chat.

---

## 🧾 Cheat Card

```
Connections : WebSocket / MQTT (persistent)
Routing     : Redis presence + Kafka pub/sub
Storage     : Cassandra (chat partitioned), S3 (media)
Delivery    : SENT → DELIVERED → READ; idempotent client_msg_id
Offline     : pending queue + APNs/FCM push
Groups      : single store + fan-out to gateways
Always      : heartbeats, reconnect with last_msg_id, idempotency
```

➡️ **Next:** [HLD 11 — Uber](./11-case-uber.md)
