# HLD Chapter 13 — 🔔 Case Study: Notification System

> Often a follow-up question. Tests **fan-out, channels, throttling, reliability**.

---

## Step 1 — Clarify

- Channels: push (APNs/FCM), email, SMS, in-app
- Triggers: user actions (like, comment), scheduled (digest), broadcast (marketing)
- User preferences: opt-out per channel, quiet hours, language
- Scale: billions/day at FAANG scale

---

## Step 2 — Architecture

```
[Producer services]
   └── publish "event"  ──▶ [ Kafka topic ]
                                   │
                          [ Notification Orchestrator ]
                                   │
                  ┌────────────────┼────────────────┐
                  ▼                ▼                ▼
             [Template Svc]  [Preference Svc]  [Throttler / Dedup]
                                   │
                  ┌────────────────┼────────────────┬───────────────┐
                  ▼                ▼                ▼               ▼
         [Push Worker]      [Email Worker]    [SMS Worker]   [In-App Worker]
                  │                │                │               │
                APNs/FCM     SES/SendGrid     Twilio/SNS      WS gateway
```

---

## Step 3 — Components

### Notification Orchestrator
- Consumes events
- Decides: which user(s)? which channel(s)?
- Renders template (i18n, variables)
- Applies user preferences and rate limits
- Routes to channel-specific worker queues

### Template Service
- Versioned templates per (event, channel, language)
- A/B testing variants
- Rendering engine (Mustache/Handlebars)

### Preference Service
- KV store: `user:42 → {push: true, email: false, quiet_hours: 22-08}`
- Cached aggressively in Redis

### Throttler / Deduper
- Don't spam: e.g., "max 1 push per user per 5 min for 'liked your post'"
- Dedup window: identical notif within X min → suppress
- Implemented via Redis sets/sliding window counters

### Channel Workers
- Pull from queue, call APNs/FCM/SES/Twilio
- Retry on failure with exponential backoff
- DLQ for permanent failures

---

## Step 4 — Data Stores

| Data | Store |
|---|---|
| User device tokens (APNs/FCM) | Cassandra / DynamoDB (`user → [token, platform, last_seen]`) |
| Templates | Postgres + Redis cache |
| User preferences | DynamoDB / Redis |
| In-app notifications (history) | Cassandra (`user_id, ts DESC`) |
| Scheduled notifications | Redis sorted set / DB with cron worker |
| Delivery logs | Kafka → data warehouse |

---

## Step 5 — Reliability & Guarantees

- **At-least-once** delivery — acceptable for most notifs
- **Idempotency**: dedupe key = `hash(user_id, event_id, channel)` — workers check before sending
- **Retry budget**: e.g., 3 retries, then DLQ
- **DLQ → manual investigation**
- **Observability**: track sent / delivered / opened per channel

---

## Step 6 — Scaling Concerns

- **Stampede on broadcasts** (e.g., world cup goal → 100M push) → spread over time, batch APNs requests, use APNs batch API
- **Hot user** (popular celeb gets 1M likes) → group/aggregate notifications ("X and 10K others liked your post")
- **APNs/FCM rate limits** → backoff + queue
- **Schedule precision** → use Redis sorted set keyed by timestamp; worker polls due notifications

---

## Step 7 — Templates & Personalization

```yaml
event: post.liked
channel: push
locale: en
title: "{{liker_name}} liked your post"
body: "{{post_excerpt}}"
deeplink: "/post/{{post_id}}"
```

Personalization layer can: pick best send time, choose channel based on engagement history.

---

## Step 8 — User-facing controls

- Unsubscribe links in emails (CAN-SPAM / GDPR)
- Per-category preferences in app
- Quiet hours
- Frequency caps

---

## ⚠️ Failure Modes & Edge Cases

- Invalid/expired token → mark token dead, stop sending
- Email bounce → suppress address
- SMS to wrong country → carrier reject; observed via webhook
- Race: user opted out *during* send → orchestrator must check just before send
- Time zones — "send at 9 AM local" requires user-local cron

---

## 🎤 Likely Follow-ups

1. *"How do you avoid duplicate notifications?"* — idempotency key in Redis with TTL.
2. *"How do you schedule notifications?"* — Redis ZSET keyed by `send_at`; worker pops due items.
3. *"How to scale push for 100M concurrent broadcast?"* — pre-fan-out to per-shard queues; throttle to APNs/FCM rate limits; batch where possible.
4. *"How do you measure success?"* — sent → delivered → opened → clicked (CTR). Observed via APNs/FCM/email pixel and app callbacks.
5. *"How to add a new channel (e.g., WhatsApp Business)?"* — new worker + new template variant. Orchestrator unchanged.

---

## 🧾 Cheat Card

```
Pipeline    : event → Kafka → orchestrator → template+pref+throttle → channel queue → worker → APNs/FCM/SES/Twilio
Stores      : tokens (KV), prefs (KV+cache), templates (RDB+cache), in-app history (wide-column), schedule (Redis ZSET)
Patterns    : fan-out, idempotency, retry+DLQ, dedupe windows, freq caps
Channels    : push, email, SMS, in-app, WhatsApp
Always      : preferences enforced at last mile, observability per stage
```

🎉 **HLD case studies done!** Now learn how to **deliver** your design in interview.

➡️ **Next:** [Interview Framework](../03-interview/01-the-framework.md)
