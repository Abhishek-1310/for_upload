# HLD Chapter 11 — 🚗 Case Study: Uber / Ola / Lyft

> Real-time location, geo queries, matching at scale. The geospatial HLD masterpiece.

---

## Step 1 — Clarify

- Riders request rides; drivers nearby get notified; one accepts
- Real-time location updates of drivers (every 4 sec)
- ETA, fare estimation
- Trip lifecycle: requested → matched → arriving → on-trip → completed → paid
- Surge pricing
- Rating & payment after trip

---

## Step 2 — Estimate

- 10M active drivers globally, each pinging location every 4s → 2.5M location updates/sec
- 5M ride requests/day → ~60 QPS avg, 1000+ peak
- Geospatial searches dominate the read load

---

## Step 3 — High-Level Architecture

```
[Rider App]      [Driver App]
    │                 │
    └──── HTTPS / WS ──── [API Gateway]
                              │
   ┌──────────────┬──────────────┬─────────────┬──────────────┐
   ▼              ▼              ▼             ▼              ▼
User Svc    Trip Svc      Location Svc   Matching Svc    Payment Svc
   │              │              │             │              │
   ▼              ▼              ▼             ▼              ▼
 Postgres    Cassandra      Redis (geo)    Kafka events    Stripe etc.
                                │
                            [ Quad-tree / S2 / Geohash index ]
```

---

## Step 4 — The Geospatial Problem

> *"Find all drivers within 3 km of (lat, lng)."*

Naïve: scan all drivers — O(N). Catastrophic.

### Solution 1 — Geohash
Encode (lat, lng) into a base32 string. Nearby points share **prefix**.
- e.g., `tdr1y...` and `tdr1z...` are adjacent
- Index: `geohash_prefix → list of driver_ids`
- Query: take query geohash → check 9 surrounding cells

### Solution 2 — Quadtree / S2 (Google)
Recursively split region into 4 cells until each holds ≤ K drivers. Search prunes branches outside radius.

### Solution 3 — Redis GEO (`GEOADD`, `GEORADIUS`)
Built-in geospatial commands using sorted sets + geohash internally.

> Uber's actual system: **H3** (hexagonal hierarchical index). Mention it for senior credit.

---

## Step 5 — Location Updates

- Driver app sends ping every 4 sec via WS or REST
- Lightweight Location Service updates Redis GEO + publishes to Kafka topic `driver.location`
- Other services (trip, matching, ETA) consume the stream

```
Driver ─every 4s─▶ Location Svc
                    │
                    ├──▶ Redis GEO (latest position)
                    └──▶ Kafka topic (history, analytics)
```

Storing every ping in main DB = wasteful. Latest in Redis, history in S3/data lake.

---

## Step 6 — Ride Matching Flow

```
1. Rider taps "Book"
2. Trip Svc creates trip (state = REQUESTED)
3. Matching Svc:
     a. GEORADIUS Redis → top N nearest available drivers
     b. Rank by ETA / rating / cancellation rate
     c. Send offer to driver #1 (push notif + WS message), 15-sec timeout
     d. If declined/timeout → driver #2 → ...
4. Driver accepts → trip state = MATCHED, broadcast to rider
5. Driver arrives → ARRIVED → ON_TRIP (start) → COMPLETED
6. Payment Svc charges; notification to both
```

The matching is essentially a **distributed dispatch** problem. Some companies use **batched matching** (collect requests for 2-5s, optimize globally) for higher efficiency.

---

## Step 7 — Storage by Concern

| Data | Store | Reason |
|---|---|---|
| Users, drivers profile | Postgres | structured, relational |
| Trips (active + history) | Cassandra/DynamoDB partitioned by `(city_id, trip_id)` | huge volume |
| Driver locations (latest) | Redis GEO | sub-ms reads |
| Location history | S3 / Hadoop | archival, ML training |
| Surge zones, heatmaps | Redis / in-memory | fast lookup |
| Payments | Postgres | ACID critical |

---

## Step 8 — Surge Pricing

- Divide cities into hexagons (H3)
- For each hex: monitor `(active_requests / available_drivers)` per minute
- If ratio > threshold → multiplier (1.5×, 2×, …)
- Compute on streaming engine (Flink/Spark Streaming) consuming Kafka events
- Push surge map to clients periodically

---

## Step 9 — ETA Computation

- Map service (e.g., OSRM, Google Directions) for route + travel time
- ML model adjusts for traffic, time of day, historical
- Cached per (origin grid, destination grid) for short TTL

---

## Step 10 — Real-time Updates to Rider

- Once matched, rider's app subscribes (WS) to driver's location updates
- Server forwards every ping to the rider's socket (1-1 fan-out)
- Smoothed on client for animation

---

## Step 11 — State Machines

Trip state: `REQUESTED → MATCHING → MATCHED → ARRIVING → ON_TRIP → COMPLETED → PAID` (with `CANCELLED`/`FAILED` branches).

Implement using a state machine library or an event-sourced approach. Each transition emits an event.

---

## Step 12 — Failure Modes

- Driver app loses connection mid-trip → fall back to last known location + offline mode
- Matching service down → degraded "best-effort" matching from cache
- Payment fails → retry with idempotency key; eventual consistency for trip state
- Hot city (NYC at 6pm) → shard by city; isolate so one city can't down others
- Race condition: two riders matched to same driver → use Redis `SETNX` driver:available before assigning

---

## Step 13 — Geo-sharding

Each city / region runs its own clusters. Cross-region queries are rare. Drivers don't typically cross regions in one trip.

---

## 🎤 Likely Follow-ups

1. *"Why Redis for locations?"* — sub-ms reads + built-in geo, simple TTL.
2. *"What if Redis loses a driver?"* — driver re-pings every 4s; brief unavailability.
3. *"How do you avoid duplicate matches?"* — atomic SETNX/CAS on driver state.
4. *"Surge pricing fairness?"* — disclose to user before booking; cap multiplier.
5. *"How to support carpool / pool rides?"* — multi-rider trip object; route optimization (NP-hard, approximations).

---

## 🧾 Cheat Card

```
Geo index   : Redis GEO / Geohash / Quadtree / S2 / H3
Location    : 4-sec pings → Location Svc → Redis (latest) + Kafka (history)
Matching    : GEORADIUS top-N → rank by ETA/rating → offer w/ timeout
Trip state  : REQ→MATCHED→ARRIVING→ON_TRIP→COMPLETED (state machine + events)
Surge       : streaming compute on hex grid
Sharding    : by city/region
Always      : idempotency on payment + matching, atomic driver assignment
```

➡️ **Next:** [HLD 12 — Netflix](./12-case-netflix.md)
