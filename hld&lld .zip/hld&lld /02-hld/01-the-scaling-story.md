# HLD Chapter 1 — From 1 User to 1 Billion: The Scaling Story 🚀

> The single most important HLD narrative. Every interview answer flows from this.

You're building **"Bookly"**, a tiny app where users post book reviews. Day 1, it runs on your laptop. By the end of this chapter, it's serving the planet. Let's walk the journey.

---

## 🌱 Stage 0 — The Single Server (Day 1)

```
[User] ──HTTP──▶ [Single Server: app + DB on same machine]
```

- 1 user, 1 box.
- Tech: Node/Django/Spring + Postgres on `localhost`.
- Cost: $5/month VPS. ✅ Works fine.

**Death point:** Disk fills up. CPU spikes when 100 users arrive. App and DB fight for RAM.

---

## 🪴 Stage 1 — Split App and DB

```
[User] ──▶ [App Server] ──▶ [Database Server]
```

Why? Because they have **different resource profiles** (app = CPU/RAM, DB = disk/IO). Scale them independently.

**Death point:** App server CPU pegged at 100%. One server can't handle the traffic.

---

## 🌳 Stage 2 — Multiple App Servers + Load Balancer

```
                    ┌──▶ App Server 1 ┐
[User] ─▶ [LB] ─────┼──▶ App Server 2 ┼──▶ [DB]
                    └──▶ App Server N ┘
```

- **Load Balancer (LB)** — Nginx, HAProxy, AWS ALB.
- App servers are now **stateless** — any server can handle any request.
- Where does session data live? → Redis or DB. **Never in app memory.**

> 🧠 Mantra: *"Stateless servers + state in shared store"* — repeat this in your interview.

**Death point:** DB is the bottleneck. Every read hits Postgres.

---

## 🌲 Stage 3 — Add Caching

```
[App Server] ──▶ [Redis Cache] (read-through) ──▶ [DB]
```

Hot data (popular books, user profile) lives in Redis. **Latency drops from 50ms to 1ms.**

Strategies (covered in Chapter 3):
- **Cache-aside** (most common): app checks cache → miss → fetch DB → fill cache.
- **Write-through, Write-behind**.

**Death point:** DB writes are slow; replication lag appears.

---

## 🌲 Stage 4 — DB Read Replicas (Master-Slave)

```
                   ┌─Replica 1 (read)
[App] ─writes─▶ [Master DB] ──replication──┤
                   └─Replica 2 (read)
       ─reads ─▶ [Replica*]
```

- 1 master handles writes, N replicas handle reads.
- Caveat: **replication lag** → "I just posted, why don't I see it?" Solution: read your own writes from master.

**Death point:** Even one master can't handle write QPS. Or single DB is too big to fit.

---

## 🌳 Stage 5 — Sharding (Horizontal Partitioning)

Split DB by key (e.g., `user_id % 4`). Each shard owns a slice.

```
user 0,4,8…  → Shard 0
user 1,5,9…  → Shard 1
user 2,6,10… → Shard 2
user 3,7,11… → Shard 3
```

Pain points:
- **Cross-shard queries** are slow (need fan-out).
- **Re-sharding** when load grows → use **consistent hashing**.
- Transactions across shards are hard (need 2PC or saga).

**Death point:** Some operations don't fit relational model — full-text search, recommendations, time-series.

---

## 🌴 Stage 6 — Specialize Storage

| Need | Right tool |
|---|---|
| Full-text search | Elasticsearch / OpenSearch |
| Time-series (metrics) | InfluxDB / TimescaleDB / Prometheus |
| Graph relations | Neo4j |
| Object/files | S3 / GCS |
| Cache | Redis / Memcached |
| Wide-column / huge writes | Cassandra / DynamoDB |
| Document model | MongoDB |
| Strong-consistent global | Spanner / CockroachDB |

> Polyglot persistence: use the right DB for each job.

---

## 🌴 Stage 7 — Async / Message Queues

Some work is **slow** (sending emails, generating thumbnails, ML pipelines). Don't make the user wait.

```
[App] ──enqueue──▶ [Kafka / RabbitMQ] ──▶ [Worker pool]
```

- Decouples producer & consumer
- Enables retries, backpressure, replay
- Foundation of **event-driven architecture**

(Chapter 5 deep-dives queues.)

---

## 🌟 Stage 8 — CDN & Edge

Static assets (images, JS, CSS, videos) → push to a **CDN** (Cloudflare, CloudFront, Akamai). Served from a server *near* the user.

```
[User in Tokyo] ──▶ [CDN edge: Tokyo] (<10ms)
                         ↓ (miss)
                    [Origin in US] (200ms)
```

---

## 🌍 Stage 9 — Multi-Region Active-Active

Deploy stack in US, EU, India. Route users via **GeoDNS / Anycast**. Replicate state across regions (eventual consistency for most data; strong consistency for payments).

This is the FAANG-scale picture:

```
        ┌────────────[ Global DNS / Anycast ]────────────┐
        │                                                 │
   ┌────▼─── US Region ────┐                ┌──── EU Region ────▼──┐
   │  CDN → LB → App pool  │   replication  │  CDN → LB → App pool │
   │  Cache → Sharded DB   │ ◀────────────▶ │  Cache → Sharded DB  │
   │  Async workers, MQ    │                │  Async workers, MQ   │
   └───────────────────────┘                └──────────────────────┘
```

---

## 🧠 Mental Anchors

You'll mention these in **every** HLD answer:

1. **Vertical scaling** = bigger machine (CPU/RAM) — limited.
2. **Horizontal scaling** = more machines — preferred at scale.
3. **Stateless services** scale horizontally easily; state goes to shared stores.
4. **Latency targets** (memorize):
   ```
   L1 cache         0.5 ns
   Main memory     100 ns
   SSD random read  16 µs
   Network in DC    500 µs
   Network cross-region 100-200 ms
   ```
5. **Bottleneck order**: CPU → DB → network → disk. Always identify *where* the wall is before adding tech.

---

## 🎤 The Interview Lens

When asked *"How would you scale X?"*, walk this same path:
- Start small
- Identify the *next* bottleneck
- Add the *minimum* component to fix it
- Justify with numbers

Don't say "I'll add Kafka and microservices" on day 1 — interviewers hate buzzword soup.

---

## 🧾 Cheat Card

```
1. Single box
2. Split app/db
3. Multiple app servers + LB (stateless!)
4. Cache layer
5. DB read replicas
6. DB sharding
7. Specialized stores (search, time-series, blob)
8. Async + message queue
9. CDN / edge
10. Multi-region
```

➡️ **Next:** [HLD 2 — Databases Deep Dive](./02-databases-deep-dive.md)
