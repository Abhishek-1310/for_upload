# Chapter 6 — UML Quickstart (10 minutes, no fluff) ✏️

In an LLD interview, you'll often be asked to **draw a class diagram**. Don't panic — you only need a tiny subset of UML.

---

## The 5 Symbols You Actually Need

```
┌──────────────────┐
│   ClassName      │   ← class box (name in bold/center)
├──────────────────┤
│ - field: Type    │   ← attributes
│ + field: Type    │
├──────────────────┤
│ + method(): Ret  │   ← methods
└──────────────────┘
```

Visibility:
- `+` public
- `-` private
- `#` protected

---

## The 6 Relationships

| Symbol | Name | Meaning | Example |
|---|---|---|---|
| `──▷` (hollow triangle) | **Inheritance / extends** | "is-a" | `Dog ──▷ Animal` |
| `┄┄▷` (dashed triangle) | **Implements interface** | "implements" | `EmailSender ┄┄▷ Notifier` |
| `───` plain line | **Association** | knows about | `Order ─── Customer` |
| `◇───` (hollow diamond) | **Aggregation** | "has-a", weak (independent lifecycle) | `Team ◇─── Player` |
| `◆───` (filled diamond) | **Composition** | "has-a", strong (dies together) | `House ◆─── Room` |
| `┄┄>` dashed arrow | **Dependency** | uses temporarily | `Order ┄┄> PaymentService` |

> **Aggregation vs Composition** is a favorite trick question.
> - Aggregation: Team disbands → Players still exist.
> - Composition: House demolished → Rooms gone.

---

## Multiplicity (cardinality)

```
Customer 1 ─── * Order        ← one customer has many orders
Order    1 ─── 1..* Item      ← one order has at least 1 item
```

---

## A Tiny Worked Example — Library

```
            ┌──────────────┐
            │ <<interface>>│
            │  Searchable  │
            └──────────────┘
                  ▲
                  ┊ (implements)
            ┌──────────────┐
            │   Library    │
            ├──────────────┤
            │ - books: Book[]
            │ - members: Member[]
            ├──────────────┤
            │ + add_book() │
            │ + search()   │
            └──────────────┘
              ◆ 1
              │
              │ *
            ┌──────────────┐         ┌──────────────┐
            │     Book     │ * ─── 1 │   Author     │
            ├──────────────┤         └──────────────┘
            │ - title      │
            │ - isbn       │
            └──────────────┘
                  ▲
          ┌───────┴───────┐
          │               │
   ┌─────────────┐  ┌─────────────┐
   │  EBook      │  │ PrintedBook │
   └─────────────┘  └─────────────┘
```

This single picture shows: composition, association with multiplicity, inheritance, and an interface.

---

## Sequence Diagrams (when interviewer asks about flow)

Use a simple top-to-bottom timeline:

```
User       Controller     Service       DB
 │             │            │            │
 │  POST /buy  │            │            │
 │────────────▶│            │            │
 │             │ buy()      │            │
 │             │───────────▶│            │
 │             │            │ insert()   │
 │             │            │───────────▶│
 │             │            │   ok       │
 │             │            │◀───────────│
 │   201       │            │            │
 │◀────────────│            │            │
```

You can sketch this on a whiteboard / Excalidraw / draw.io quickly.

---

## Interview tips

- Don't waste time on perfect notation — clarity > strict UML.
- Always label multiplicities (`1`, `*`, `0..1`).
- For LLD, **class diagram + 1-2 sequence diagrams** is enough.
- Tools to know: **Excalidraw**, **draw.io / diagrams.net**, **PlantUML**.

---

➡️ **Next:** [Chapter 7 — Case Study: Parking Lot](./07-case-parking-lot.md)
