# Chapter 10 — 🛗 Case Study: Elevator System

> *"Design the control system for a building with multiple elevators."*

This question tests **state machines + scheduling algorithms** in OOP form.

---

## Step 1 — Clarify

- N elevators in a building of M floors
- Internal buttons (inside cab) and external buttons (on each floor: UP / DOWN)
- Direction-aware scheduling (don't reverse mid-trip — like real elevators)
- Capacity limits, emergency stop, door open/close
- Algorithm: **SCAN / LOOK** (elevator industry standard)

---

## Step 2 — Entities

`Building, Elevator, ElevatorController, Request, Direction, ElevatorState (Idle/Moving/Stopped), Door`

---

## Step 3 — Patterns

| Concern | Pattern |
|---|---|
| Idle / Moving / DoorsOpen states | **State** |
| Choosing which elevator answers a hall call | **Strategy** (`NearestCar`, `ZoneBased`) |
| Floor → request route | **Command** (each request as object) |
| Display panel updates | **Observer** |
| Single controller per building | **Singleton** |

---

## Step 4 — Code

```python
from enum import Enum
from heapq import heappush, heappop
from abc import ABC, abstractmethod

class Direction(Enum): UP=1; DOWN=-1; IDLE=0

class ElevatorState(Enum): IDLE=1; MOVING=2; DOORS_OPEN=3; MAINTENANCE=4

class Request:
    def __init__(self, source_floor, dest_floor=None, direction=None):
        self.source = source_floor
        self.dest = dest_floor                # None for hall calls
        self.dir = direction

class Elevator:
    def __init__(self, eid, capacity=10):
        self.id = eid
        self.current = 0
        self.direction = Direction.IDLE
        self.state = ElevatorState.IDLE
        self.capacity = capacity
        self.up_stops   = []     # min-heap of floors above
        self.down_stops = []     # max-heap (negate)

    def add_stop(self, floor):
        if floor > self.current:
            heappush(self.up_stops, floor)
        elif floor < self.current:
            heappush(self.down_stops, -floor)
        # if equal: doors open

    def step(self):
        """Run one tick of the LOOK algorithm."""
        if self.direction == Direction.UP:
            if self.up_stops:
                next_f = self.up_stops[0]
                self._move_toward(next_f)
                if self.current == next_f:
                    heappop(self.up_stops); self._open_doors()
            else:
                self.direction = Direction.DOWN if self.down_stops else Direction.IDLE
        elif self.direction == Direction.DOWN:
            if self.down_stops:
                next_f = -self.down_stops[0]
                self._move_toward(next_f)
                if self.current == next_f:
                    heappop(self.down_stops); self._open_doors()
            else:
                self.direction = Direction.UP if self.up_stops else Direction.IDLE
        else:  # IDLE → choose direction
            if self.up_stops:   self.direction = Direction.UP
            elif self.down_stops: self.direction = Direction.DOWN

    def _move_toward(self, floor):
        self.state = ElevatorState.MOVING
        self.current += 1 if floor > self.current else -1

    def _open_doors(self):
        self.state = ElevatorState.DOORS_OPEN
        print(f"E{self.id} doors open at floor {self.current}")
        self.state = ElevatorState.IDLE


# ── Strategy: pick which elevator handles a hall call ──
class DispatchStrategy(ABC):
    @abstractmethod
    def pick(self, elevators, request: Request) -> Elevator: pass

class NearestCar(DispatchStrategy):
    def pick(self, elevators, req):
        # prefer elevators going same direction & passing through
        candidates = []
        for e in elevators:
            if e.state == ElevatorState.MAINTENANCE: continue
            if e.direction == Direction.IDLE:
                score = abs(e.current - req.source)
            elif e.direction == req.dir and (
                (req.dir == Direction.UP and e.current <= req.source) or
                (req.dir == Direction.DOWN and e.current >= req.source)
            ):
                score = abs(e.current - req.source)
            else:
                score = abs(e.current - req.source) + 100   # penalty
            candidates.append((score, e))
        return min(candidates, key=lambda x: x[0])[1]


# ── Controller (Singleton) ──
class ElevatorController:
    def __init__(self, elevators, strategy: DispatchStrategy):
        self.elevators = elevators
        self.strategy = strategy

    def hall_call(self, floor, direction):
        req = Request(floor, direction=direction)
        chosen = self.strategy.pick(self.elevators, req)
        chosen.add_stop(floor)
        print(f"hall call f{floor} {direction.name} → E{chosen.id}")

    def cab_request(self, elevator_id, dest_floor):
        e = next(x for x in self.elevators if x.id == elevator_id)
        e.add_stop(dest_floor)

    def tick(self):
        for e in self.elevators: e.step()
```

### Driver
```python
elevators = [Elevator(1), Elevator(2)]
ctrl = ElevatorController(elevators, NearestCar())

ctrl.hall_call(5, Direction.UP)     # someone on floor 5 wants to go up
ctrl.hall_call(2, Direction.DOWN)
ctrl.cab_request(1, 9)              # passenger in E1 picks floor 9

for _ in range(15): ctrl.tick()
```

---

## ⚠️ Follow-ups

1. **"Why two heaps?"** → Up-stops sorted ascending, down-stops descending. Implements LOOK efficiently.
2. **"Other scheduling algorithms?"** → FCFS (fair but slow), SCAN (full sweep top-bottom), LOOK (sweep only as far as needed) — most modern elevators use LOOK.
3. **"Multiple elevator coordination — avoid all serving same floor."** → Strategy assigns each call to one car only (above). Could also use zoning.
4. **"What if power fails / emergency button?"** → New state `EMERGENCY`, controller routes to nearest floor and opens doors.
5. **"How would you test this?"** → Inject a fake clock; tick deterministically.

---

## ✅ Concepts demonstrated
- **State** machine (Idle/Moving/Doors)
- **Strategy** for dispatch
- Real algorithm (LOOK) implemented with heaps
- Clean separation: Elevator (mechanism) vs Controller (policy)

---

➡️ **Next:** [Chapter 11 — Snake & Ladder, Chess, Tic-Tac-Toe](./11-case-snake-ladder-chess.md)
