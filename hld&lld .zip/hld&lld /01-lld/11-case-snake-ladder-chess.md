# Chapter 11 — ♟️ Case Studies: Games (Snake-Ladder, Chess, Tic-Tac-Toe)

Games are perfect interview problems — small enough to finish, deep enough to show OOP fluency.

---

## 🎲 11A — Snake & Ladder

### Clarify
- Board size (default 100), N players, multiple snakes & ladders, dice (1-6).
- A 6 grants extra turn? (ask interviewer)

### Entities
`Game, Board, Cell, Snake, Ladder, Dice, Player`

### Patterns
- **Singleton**: `Dice`
- **Strategy**: dice variants (single, double, custom)
- **Observer**: notify on player win

### Code
```python
import random
from collections import deque

class Snake:
    def __init__(self, head, tail): self.head, self.tail = head, tail
class Ladder:
    def __init__(self, bottom, top): self.bottom, self.top = bottom, top

class Board:
    def __init__(self, size, snakes, ladders):
        self.size = size
        self.jumps = {}                           # cell → destination
        for s in snakes:   self.jumps[s.head] = s.tail
        for l in ladders:  self.jumps[l.bottom] = l.top

    def next_position(self, current, roll):
        target = current + roll
        if target > self.size: return current     # overshoot → stay
        return self.jumps.get(target, target)

class Dice:
    def __init__(self, faces=6): self.faces = faces
    def roll(self): return random.randint(1, self.faces)

class Player:
    def __init__(self, name): self.name = name; self.pos = 0

class Game:
    def __init__(self, board, players, dice):
        self.board = board
        self.players = deque(players)
        self.dice = dice

    def play(self):
        while True:
            p = self.players.popleft()
            roll = self.dice.roll()
            p.pos = self.board.next_position(p.pos, roll)
            print(f"{p.name} rolled {roll} → {p.pos}")
            if p.pos == self.board.size:
                print(f"🏆 {p.name} wins!"); return p
            self.players.append(p)
```

---

## ♟️ 11B — Chess (Skeleton — focus on **modeling**, not full rules)

### Clarify
2-player, 8×8 board, 6 piece types, move legality, check/checkmate detection, undo, time control (optional).

### Entities
`Game, Board, Cell, Piece (King/Queen/Rook/Bishop/Knight/Pawn), Move, Player, MoveValidator`

### Patterns
- **Strategy** (or polymorphism): each piece's move logic
- **Command**: `Move` objects → enables undo/redo, history, PGN export
- **State**: game states (Active / Check / Checkmate / Stalemate / Draw)
- **Factory**: build initial board

### Core code
```python
from abc import ABC, abstractmethod
from enum import Enum

class Color(Enum): WHITE=1; BLACK=2

class Piece(ABC):
    def __init__(self, color): self.color = color
    @abstractmethod
    def can_move(self, board, src, dst) -> bool: pass

class King(Piece):
    def can_move(self, board, src, dst):
        return max(abs(src[0]-dst[0]), abs(src[1]-dst[1])) == 1

class Knight(Piece):
    def can_move(self, board, src, dst):
        dx, dy = abs(src[0]-dst[0]), abs(src[1]-dst[1])
        return (dx, dy) in [(1,2),(2,1)]

# ... Rook, Bishop, Queen, Pawn similarly

class Cell:
    def __init__(self, x, y, piece=None):
        self.x, self.y, self.piece = x, y, piece

class Board:
    def __init__(self):
        self.grid = [[Cell(x,y) for y in range(8)] for x in range(8)]
        # ...place pieces in initial positions

class Move:                                      # Command pattern
    def __init__(self, player, src, dst, piece, captured=None):
        self.player=player; self.src=src; self.dst=dst
        self.piece=piece; self.captured=captured

class Game:
    def __init__(self, p1, p2):
        self.board = Board()
        self.players = [p1, p2]
        self.turn = 0
        self.history = []                        # for undo / PGN

    def make_move(self, src, dst):
        piece = self.board.grid[src[0]][src[1]].piece
        if piece is None or piece.color != self._current().color: 
            raise Exception("invalid")
        if not piece.can_move(self.board, src, dst):
            raise Exception("illegal move for this piece")
        # check for own-color capture, check after move, etc.
        ...
        self.history.append(Move(self._current(), src, dst, piece))
        self.turn ^= 1

    def _current(self): return self.players[self.turn]
```

> Tell the interviewer: *"For brevity, I'll skip exhaustive piece rules; the architecture is what matters."*

---

## ❌⭕ 11C — Tic-Tac-Toe

Used as a **warm-up**; show clean OOP in 5 minutes.

```python
class TicTacToe:
    def __init__(self):
        self.b = [["."]*3 for _ in range(3)]
        self.turn = "X"

    def play(self, r, c):
        if self.b[r][c] != ".": raise Exception("taken")
        self.b[r][c] = self.turn
        if self._wins(self.turn): return f"{self.turn} wins"
        self.turn = "O" if self.turn=="X" else "X"
        return None

    def _wins(self, p):
        lines = (
            self.b +                                             # rows
            [list(col) for col in zip(*self.b)] +                # cols
            [[self.b[i][i] for i in range(3)],
             [self.b[i][2-i] for i in range(3)]]
        )
        return any(all(c==p for c in line) for line in lines)
```

Mention: Could extend to N×N (`ConnectN`), AI opponent (Minimax), GUI (Observer for board updates).

---

## 🎤 Common follow-ups (any game)

1. **"Add an AI opponent."** → Minimax / alpha-beta. Keep AI as a strategy plug-in.
2. **"Save & resume games."** → Memento pattern + serialization (JSON of board state).
3. **"Multiplayer over network."** → Move = Command serialized over WebSocket; server is authoritative.
4. **"Replay system."** → Already trivial — replay history list of `Move` commands.

---

## ✅ Why interviewers love games
They reveal whether you can:
- model a closed-world domain cleanly,
- choose right relationships (composition vs inheritance),
- separate **rules** (piece/board) from **flow** (game/turn manager).

---

➡️ **Next:** [Chapter 12 — Rate Limiter](./12-case-rate-limiter.md)
