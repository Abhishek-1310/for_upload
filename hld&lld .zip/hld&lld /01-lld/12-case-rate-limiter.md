# Chapter 12 — 🚦 Case Study: Rate Limiter

> *"Design a rate limiter — an API can be hit at most N times per user per minute."*

This is a **bridge question**: it tests OOP/LLD skills *and* HLD intuition (distributed systems). Master it.

---

## Step 1 — Clarify

- Per **user**? per **IP**? per **API key**? (probably user)
- N requests per **window** (e.g., 100/min)
- Single-server or distributed?
- Soft (warn) vs hard (block 429)?
- Burst tolerance allowed?

---

## Step 2 — The 4 Classic Algorithms (KNOW ALL FOUR)

### 1. Fixed Window Counter
Bucket per minute. Increment counter; reject if > N.
- ✅ Simple, low memory.
- ❌ Burst at boundary (100 requests at 11:59:59 + 100 at 12:00:01 = 200 in 2 sec).

```python
import time
class FixedWindow:
    def __init__(self, limit, window_sec):
        self.limit = limit; self.window = window_sec
        self.counts = {}                 # user → (window_start, count)
    def allow(self, user):
        now = int(time.time()); w = now - now % self.window
        start, cnt = self.counts.get(user, (w, 0))
        if start != w: start, cnt = w, 0
        if cnt >= self.limit: return False
        self.counts[user] = (start, cnt + 1)
        return True
```

### 2. Sliding Window Log
Store timestamp of every request; count those within `now - window`.
- ✅ Most accurate.
- ❌ Memory heavy (N entries per user).

```python
from collections import deque
class SlidingLog:
    def __init__(self, limit, window): self.limit=limit; self.window=window; self.log={}
    def allow(self, user):
        now = time.time()
        q = self.log.setdefault(user, deque())
        while q and q[0] <= now - self.window: q.popleft()
        if len(q) >= self.limit: return False
        q.append(now); return True
```

### 3. Sliding Window Counter (hybrid)
Combine current + previous window with weight.
- Approx. accurate, low memory. Used in production (Cloudflare).

```python
class SlidingCounter:
    def __init__(self, limit, window_sec):
        self.limit=limit; self.window=window_sec; self.buckets={}   # user→{w:count}
    def allow(self, user):
        now = time.time(); cur_w = int(now // self.window)
        elapsed = (now % self.window) / self.window           # fraction into window
        d = self.buckets.setdefault(user, {})
        cur = d.get(cur_w, 0); prev = d.get(cur_w - 1, 0)
        weighted = prev * (1 - elapsed) + cur
        if weighted + 1 > self.limit: return False
        d[cur_w] = cur + 1
        for k in list(d):                                     # cleanup
            if k < cur_w - 1: d.pop(k)
        return True
```

### 4. Token Bucket (the one most companies use)
Bucket holds up to `capacity` tokens. Refilled at `rate` per second. Each request consumes one. Out of tokens → reject.
- ✅ Allows controlled bursts.
- ✅ Simple, memory O(1) per user.

```python
class TokenBucket:
    def __init__(self, capacity, refill_per_sec):
        self.cap = capacity; self.rate = refill_per_sec
        self.state = {}                  # user → (tokens, last_ts)
    def allow(self, user):
        now = time.time()
        tokens, last = self.state.get(user, (self.cap, now))
        tokens = min(self.cap, tokens + (now - last) * self.rate)
        if tokens < 1:
            self.state[user] = (tokens, now); return False
        self.state[user] = (tokens - 1, now); return True
```

> **Sister algorithm: Leaky Bucket** — requests queue, drained at fixed rate. Smooths traffic. (Token bucket allows bursts; leaky doesn't.)

---

## Step 3 — Clean LLD with Strategy

```python
from abc import ABC, abstractmethod

class RateLimiter(ABC):
    @abstractmethod
    def allow(self, user) -> bool: pass

# concrete classes above implement RateLimiter

class APIGateway:
    def __init__(self, limiter: RateLimiter):
        self.limiter = limiter            # DIP — injected
    def handle(self, user, request):
        if not self.limiter.allow(user):
            return 429, "Too Many Requests"
        return 200, "OK"
```

Swap algorithms without touching the gateway. **OCP + DIP** in action.

---

## Step 4 — Going Distributed (HLD bonus)

Once you have many API servers, in-memory state desyncs. Solutions:

1. **Centralized counter in Redis** — every server `INCR rl:{user}:{minute}` with TTL. Atomic.
2. **Redis with Lua script** — run the entire token-bucket update atomically (avoids race conditions).
3. **Sticky sessions** — route a user always to the same server (load-balancer hash on user ID). Easier but less elastic.
4. **Local + sync** — each server keeps a local counter, periodically reconciles with central store. Eventual but fast.

### Redis token bucket (snippet)
```lua
-- KEYS[1] = "tb:user42"
-- ARGV   = capacity, refill_rate, now
local data = redis.call("HMGET", KEYS[1], "tokens", "ts")
local tokens = tonumber(data[1]) or tonumber(ARGV[1])
local ts     = tonumber(data[2]) or tonumber(ARGV[3])
tokens = math.min(tonumber(ARGV[1]),
                  tokens + (tonumber(ARGV[3]) - ts) * tonumber(ARGV[2]))
local allow = 0
if tokens >= 1 then tokens = tokens - 1; allow = 1 end
redis.call("HMSET", KEYS[1], "tokens", tokens, "ts", ARGV[3])
redis.call("EXPIRE", KEYS[1], 60)
return allow
```

---

## ⚠️ Follow-ups

1. **"Why not store in DB?"** → too slow. Need sub-millisecond. Redis / in-memory required.
2. **"Per-endpoint vs per-user limits?"** → composite key: `{user}:{endpoint}`.
3. **"How to pick algorithm?"**
   - Need bursts? → Token bucket
   - Smooth traffic? → Leaky bucket
   - Strict accuracy? → Sliding log
   - Memory tight? → Fixed window or sliding counter
4. **"What happens at exactly the limit boundary?"** → discuss precision vs cost.
5. **"Distributed clock skew?"** → use a single source of time (Redis server time).

---

## ✅ Cheat card

```
Algorithm           | Burst | Memory | Accuracy
--------------------|-------|--------|----------
Fixed Window        |  ❌   |   O(1) | low (boundary)
Sliding Window Log  |  ✅   |   O(N) | highest
Sliding Counter     |  ✅   |   O(1) | high (approx)
Token Bucket        |  ✅   |   O(1) | high  ← most popular
Leaky Bucket        |  ❌   |   O(1) | smooths

Distributed:  Redis + Lua  >  sticky sessions  >  local-only
```

---

🎉 **You've finished the LLD section!** Take a breath. Re-tell each story to a friend. Then move to:

➡️ **Next:** [Part 2, Chapter 1 — The Scaling Story](../02-hld/01-the-scaling-story.md)
