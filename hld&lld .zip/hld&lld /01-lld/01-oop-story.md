# Chapter 1 — The Coffee Shop That Taught Me OOP ☕

## 🎬 The Problem Appears

Imagine you just got hired as a developer at **"Brewly"**, a tiny coffee shop chain. The owner, Maria, hands you a sticky note:

> *"Build me a billing app. We sell coffee and tea. Track orders, calculate bills, print receipts."*

Easy, right? You open your laptop and type:

```python
def make_order(item, size, price, customer_name, customer_phone, ...):
    total = price
    if size == "large": total += 50
    print(f"Receipt for {customer_name}: {item} {size} = {total}")
```

It works. Maria pays you. You go home happy.

## 💥 The Disaster

Two weeks later Maria calls you in panic:
- *"We added smoothies, sandwiches, and combos."*
- *"We have 4 branches now, each with different prices."*
- *"Customers want loyalty points."*
- *"And we want online + in-store + delivery orders."*

You open your `make_order` function. It's **400 lines**. Every change breaks something. You change the price for tea, and somehow coffee becomes free.

You're drowning.

## 💡 The "Aha!" Moment — Objects

That night, Maria says something that changes everything:

> *"In my shop, every **thing** has its own job. The barista makes drinks. The cashier handles money. The receipt is its own piece of paper. They don't get tangled."*

That's **OOP**. Stop thinking in functions. Start thinking in **things** — *objects* — each with their own data and behavior.

```python
class MenuItem:
    def __init__(self, name, base_price):
        self.name = name
        self.base_price = base_price
    def price(self):
        return self.base_price

class Coffee(MenuItem):
    def __init__(self, size):
        super().__init__("Coffee", 100)
        self.size = size
    def price(self):
        return self.base_price + (50 if self.size == "large" else 0)

class Order:
    def __init__(self, customer):
        self.customer = customer
        self.items = []
    def add(self, item): self.items.append(item)
    def total(self): return sum(i.price() for i in self.items)

class Receipt:
    def print(self, order):
        print(f"--- Receipt for {order.customer.name} ---")
        for i in order.items: print(f"{i.name}: {i.price()}")
        print(f"TOTAL: {order.total()}")
```

Now adding a smoothie? Just `class Smoothie(MenuItem)`. The `Order` and `Receipt` don't even need to know.

---

## 🧠 The 4 Pillars (As Maria Would Explain Them)

### 1️⃣ Encapsulation — *"Mind your own business"*
The cashier doesn't open the espresso machine. Each object hides its internals and exposes only what others need.
```python
class Account:
    def __init__(self): self.__balance = 0   # private
    def deposit(self, amt): 
        if amt > 0: self.__balance += amt    # controlled access
```
**Why interviewers love it:** Prevents bugs. Makes refactoring safe.

### 2️⃣ Abstraction — *"Just press the button"*
You order a latte. You don't care which beans, which machine. You see a *menu* — that's the abstraction.
```python
from abc import ABC, abstractmethod
class PaymentMethod(ABC):
    @abstractmethod
    def pay(self, amount): pass
# Caller writes: payment.pay(500). Doesn't know if it's UPI, Card, or Cash.
```

### 3️⃣ Inheritance — *"Family traits"*
A `Latte` *is a* `Coffee` *is a* `MenuItem`. Don't rewrite — inherit.
> ⚠️ Trap: Don't inherit just to reuse code. Inherit only when there's a true *"is-a"* relationship. Otherwise prefer **composition** (more on this in SOLID).

### 4️⃣ Polymorphism — *"Same word, different meaning"*
You say `item.price()`. Whether it's coffee, tea, or a combo, each computes its own price.
```python
for item in order.items:
    print(item.price())   # each class answers differently
```
This is what kills the giant `if/elif/else` ladder.

---

## 🔑 Class vs Object vs Instance (The Interview Trap)

- **Class** = blueprint (the *recipe* for a latte)
- **Object/Instance** = actual thing made from blueprint (the *cup* you're holding)

## 🏗️ Has-a vs Is-a (Composition vs Inheritance)

| Relationship | Example | Use |
|---|---|---|
| **Is-a** | `Latte` is a `Coffee` | Inheritance |
| **Has-a** | `Order` has `Items` | Composition |

Modern wisdom: **"Favor composition over inheritance."** Why? Inheritance creates rigid hierarchies. Composition is flexible — you can swap parts.

---

## 🎤 The Interview Lens

Interviewers will ask:

1. **"Explain OOP."** → Don't list 4 words. Tell the coffee shop story. Show *why* each pillar exists.
2. **"Difference between abstraction and encapsulation?"**
   - Abstraction = hiding *complexity* (what it does)
   - Encapsulation = hiding *data* (how it stores)
3. **"When would you NOT use inheritance?"** → When the relationship is "has-a" or behavior changes per instance.
4. **"What's polymorphism without inheritance?"** → Duck typing (Python), interfaces (Java).

---

## 🧾 Cheat Card

```
4 Pillars:
  Encapsulation  → hide data, expose methods
  Abstraction    → hide complexity, expose interface
  Inheritance    → "is-a", reuse via parent
  Polymorphism   → same call, different behavior

Golden rule: Favor composition over inheritance.
Red flag in code: 50-line if/elif on type → use polymorphism.
```

---

➡️ **Next:** [Chapter 2 — SOLID: The Startup That Kept Breaking](./02-solid-principles.md)
