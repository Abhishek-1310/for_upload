# Chapter 9 — 🎬 Case Study: BookMyShow

> *"Design a movie ticket booking system. Multiple cities, theaters, shows. Two users must never get the same seat."*

---

## Step 1 — Clarify

- Cities → Theaters → Screens → Shows → Seats
- Movies have multiple shows across screens
- Booking: select seats, hold them, pay, confirm
- **Concurrency**: 2 users tap same seat at the same time → only one wins
- Payments + cancellation + refund window
- For LLD scope, we'll skip search/recommendation

---

## Step 2 — Entities

`City, Theater, Screen, Seat, Movie, Show, Booking, Payment, User`

---

## Step 3 — Relationships

```
City      ◆── Theater
Theater   ◆── Screen
Screen    ◆── Seat
Movie     ── shown in ──▶  Show ── on ──▶ Screen
Show      1── *  Seat-Lock / SeatStatus
Booking   1── 1..* Seat
Booking   1── 1   Payment
User      1── *   Booking
```

---

## Step 4 — Patterns

| Concern | Pattern |
|---|---|
| Booking lifecycle (CREATED → HELD → PAID → CONFIRMED → CANCELLED) | **State** |
| Pricing tiers (silver/gold/platinum, weekend, peak) | **Strategy / Decorator** |
| Multiple payment methods | **Strategy** |
| Notify user on booking | **Observer** |
| Seat selection algorithm (best seats first) | **Strategy** |

---

## Step 5 — Code (key parts)

```python
from abc import ABC, abstractmethod
from datetime import datetime, timedelta
from enum import Enum
from threading import Lock
import uuid

class SeatType(Enum): SILVER = 1; GOLD = 2; PLATINUM = 3
class SeatStatus(Enum): AVAILABLE = 1; HELD = 2; BOOKED = 3

class Seat:
    def __init__(self, row, col, stype: SeatType):
        self.id = f"{row}{col}"
        self.type = stype

class Movie:
    def __init__(self, title, duration_min): 
        self.id = str(uuid.uuid4())[:6]; self.title = title; self.duration = duration_min

class Screen:
    def __init__(self, seats: list[Seat]):
        self.id = str(uuid.uuid4())[:6]; self.seats = seats

class Show:
    def __init__(self, movie: Movie, screen: Screen, start: datetime):
        self.id = str(uuid.uuid4())[:6]
        self.movie = movie; self.screen = screen; self.start = start
        # Per-show seat status (other shows on same screen are independent)
        self.status = {s.id: SeatStatus.AVAILABLE for s in screen.seats}
        self.holds  = {}                   # seat_id -> (user_id, expiry)
        self.lock   = Lock()


# ── Pricing Strategy ──
class PricingStrategy(ABC):
    @abstractmethod
    def price(self, seat: Seat, show: Show) -> float: pass

class StandardPricing(PricingStrategy):
    base = {SeatType.SILVER:150, SeatType.GOLD:250, SeatType.PLATINUM:400}
    def price(self, seat, show):
        p = self.base[seat.type]
        if show.start.weekday() >= 5: p *= 1.2     # weekend surge
        return round(p, 2)


# ── Booking State ──
class BookingState(Enum):
    CREATED=1; HELD=2; PAID=3; CONFIRMED=4; CANCELLED=5; EXPIRED=6

class Booking:
    HOLD_MIN = 5
    def __init__(self, user, show, seats, pricing: PricingStrategy):
        self.id = str(uuid.uuid4())[:8]
        self.user = user; self.show = show; self.seats = seats
        self.amount = sum(pricing.price(s, show) for s in seats)
        self.state = BookingState.CREATED
        self.held_until = None


# ── Payment Strategy ──
class PaymentStrategy(ABC):
    @abstractmethod
    def pay(self, amount, ref): pass

class CardPayment(PaymentStrategy):
    def pay(self, amount, ref): print(f"💳 charged {amount} for {ref}"); return True


# ── Booking Service ──
class BookingService:
    def __init__(self, pricing): self.pricing = pricing

    def hold_seats(self, user, show: Show, seat_ids: list[str]) -> Booking:
        with show.lock:                                    # 🔒 critical section
            now = datetime.now()
            # 1) check & cleanup expired holds
            for sid, (_, exp) in list(show.holds.items()):
                if exp < now and show.status[sid] == SeatStatus.HELD:
                    show.status[sid] = SeatStatus.AVAILABLE
                    show.holds.pop(sid)
            # 2) ensure all requested seats free
            for sid in seat_ids:
                if show.status[sid] != SeatStatus.AVAILABLE:
                    raise Exception(f"Seat {sid} not available")
            # 3) hold them atomically
            expiry = now + timedelta(minutes=Booking.HOLD_MIN)
            for sid in seat_ids:
                show.status[sid] = SeatStatus.HELD
                show.holds[sid] = (user.id, expiry)

        seats = [s for s in show.screen.seats if s.id in seat_ids]
        booking = Booking(user, show, seats, self.pricing)
        booking.state = BookingState.HELD
        booking.held_until = expiry
        return booking

    def confirm(self, booking: Booking, payment: PaymentStrategy):
        if booking.state != BookingState.HELD:
            raise Exception("Booking not in HELD state")
        if datetime.now() > booking.held_until:
            self._release(booking, BookingState.EXPIRED); raise Exception("Hold expired")
        if not payment.pay(booking.amount, booking.id):
            self._release(booking, BookingState.CANCELLED); raise Exception("Payment failed")
        with booking.show.lock:
            for s in booking.seats:
                booking.show.status[s.id] = SeatStatus.BOOKED
                booking.show.holds.pop(s.id, None)
        booking.state = BookingState.CONFIRMED

    def _release(self, booking, new_state):
        with booking.show.lock:
            for s in booking.seats:
                if booking.show.status[s.id] == SeatStatus.HELD:
                    booking.show.status[s.id] = SeatStatus.AVAILABLE
                    booking.show.holds.pop(s.id, None)
        booking.state = new_state
```

### Why the lock?
Two requests for the same seat enter `hold_seats` → only one acquires `show.lock` → checks availability → marks HELD → releases lock. The second sees it as HELD → fails. **Race condition solved.**

---

## ⚠️ Follow-ups

1. **"What if your service is multi-instance (horizontal scaling)?"**
   - In-memory locks won't work. Use **Redis distributed lock** (`SETNX seat:show123:A1`), or a DB row lock (`SELECT ... FOR UPDATE`).
2. **"Auto-release seats after 5 minutes?"**
   - Background scheduler / Redis TTL keys / a delayed Kafka message.
3. **"Pricing surge during high demand?"**
   - Decorator chain: `WeekendDecorator(PrimeTimeDecorator(StandardPricing()))`.
4. **"How do you prevent overbooking under high QPS?"**
   - Single-source-of-truth for seat status (DB with row-level lock or atomic Redis ops). Optimistic locking with version columns also works.
5. **"How is showtime data fetched fast?"**
   - Cache (Redis) keyed by `city:movie:date`. Invalidate on show updates.

---

## ✅ Concepts demonstrated

- **State machine** for booking lifecycle
- **Strategy** for pricing & payment
- **Concurrency** via per-show lock
- **OCP**: add a new payment / pricing rule without touching service
- Clear separation: domain (Show, Booking) vs orchestration (Service)

---

➡️ **Next:** [Chapter 10 — Elevator System](./10-case-elevator.md)
