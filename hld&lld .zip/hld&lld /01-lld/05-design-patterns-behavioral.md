# Chapter 5 — Behavioral Patterns: How Objects Talk 💬

## 🎬 The Setup

Creation: ✅. Structure: ✅. Now the question becomes — *how do objects coordinate, react, and pass responsibilities?*

These are **Behavioral Patterns**. The most interview-loved category.

---

## 1️⃣ Strategy — *"Plug-and-play algorithms"* 🎯

### Story
Your e-commerce app has shipping logic:
```python
if mode == "standard": cost = ...
elif mode == "express": cost = ...
elif mode == "drone":   cost = ...
```
Every new mode = edit + risk. (Sound familiar? OCP cries.)

### Solution
Encapsulate each algorithm as a strategy object.

```python
class ShippingStrategy(ABC):
    @abstractmethod
    def cost(self, weight): pass

class Standard(ShippingStrategy): def cost(self, w): return w * 5
class Express(ShippingStrategy):  def cost(self, w): return w * 10
class Drone(ShippingStrategy):    def cost(self, w): return w * 20 + 50

class Order:
    def __init__(self, strategy: ShippingStrategy): self.s = strategy
    def total_shipping(self, w): return self.s.cost(w)

Order(Express()).total_shipping(3)  # 30
```

> Strategy is the **#1 most useful** pattern in real code. Whenever you see `if type == ...`, think Strategy.

---

## 2️⃣ Observer — *"Subscribe & notify"* 📰

### Story
A YouTube channel uploads a video. 1M subscribers should be notified. Calling each one manually? Madness.

### Solution
Subject keeps a list of observers; when state changes, all are notified.

```python
class Channel:
    def __init__(self): self.subs = []
    def subscribe(self, s): self.subs.append(s)
    def upload(self, video):
        for s in self.subs: s.notify(video)

class Subscriber:
    def __init__(self, name): self.name = name
    def notify(self, video): print(f"{self.name} got: {video}")

c = Channel()
c.subscribe(Subscriber("Abhishek"))
c.subscribe(Subscriber("Maria"))
c.upload("System Design 101")
```

### When to use
Event systems, pub/sub, UI bindings, reactive frameworks.
Real: Java `PropertyChangeListener`, RxJS, Redux store, DOM events.

---

## 3️⃣ State — *"Behavior changes with mode"* 🔄

### Story
A vending machine: when **idle**, accept coins. When **has-money**, accept selection. When **dispensing**, ignore everything. Modeling with `if state == ...` is a 200-line monster.

### Solution
Each state is a class with its own behavior.

```python
class State(ABC):
    def insert_coin(self, m): pass
    def select(self, m, item): pass

class Idle(State):
    def insert_coin(self, m):
        print("coin accepted"); m.state = HasMoney()

class HasMoney(State):
    def select(self, m, item):
        print(f"dispensing {item}"); m.state = Idle()

class VendingMachine:
    def __init__(self): self.state = Idle()
    def insert_coin(self):    self.state.insert_coin(self)
    def select(self, item):   self.state.select(self, item)
```
No giant switch. Each state owns its rules.

### Strategy vs State?
Same structure, different intent.
- **Strategy** — client picks algorithm explicitly.
- **State** — object switches its *own* behavior internally.

---

## 4️⃣ Command — *"Action as object"* 📜

### Story
A text editor needs **undo/redo**. You also want to log every action and queue actions for execution.

### Solution
Wrap each action in a Command object with `execute()` and `undo()`.

```python
class Command(ABC):
    def execute(self): ...
    def undo(self): ...

class TypeCommand(Command):
    def __init__(self, doc, text): self.doc=doc; self.text=text
    def execute(self): self.doc.append(self.text)
    def undo(self):    self.doc.remove_last(len(self.text))

class Editor:
    def __init__(self): self.history = []
    def run(self, cmd: Command):
        cmd.execute(); self.history.append(cmd)
    def undo(self):
        self.history.pop().undo()
```

### When to use
Undo/redo, macros, task queues, transactional ops.

---

## 5️⃣ Chain of Responsibility — *"Pass it down the line"* 🧗

### Story
A web request goes through: auth → rate-limit → logging → handler. Hardcoding all in one function = pain.

### Solution
Each handler decides: *handle it* or *pass to next*.

```python
class Handler(ABC):
    def __init__(self): self.next = None
    def set_next(self, h): self.next = h; return h
    def handle(self, req):
        if self.next: self.next.handle(req)

class AuthHandler(Handler):
    def handle(self, req):
        if not req.user: print("blocked"); return
        super().handle(req)

class RateLimitHandler(Handler):
    def handle(self, req):
        if req.too_many: print("rate limited"); return
        super().handle(req)
```
Compose chains: `auth.set_next(rate).set_next(logger)`.

### Real-world
Express.js / FastAPI middleware, servlet filters, logging frameworks.

---

## 6️⃣ Template Method — *"Recipe with blanks"* 📋

### Story
Two report types — PDF and CSV. Both: `fetch → format → save`. The middle step differs; the rest is identical.

### Solution
Parent defines the skeleton; subclasses override specific steps.

```python
class Report(ABC):
    def generate(self):           # template
        data = self.fetch()
        out  = self.format(data)
        self.save(out)
    def fetch(self): return [1,2,3]
    @abstractmethod
    def format(self, data): pass
    def save(self, out): print(f"saved: {out}")

class CSVReport(Report):
    def format(self, data): return ",".join(map(str, data))
class PDFReport(Report):
    def format(self, data): return f"<pdf>{data}</pdf>"
```

---

## 7️⃣ Iterator — *"Walk a collection without exposing it"* 🚶

You already use it: `for x in list`. Pattern intent → uniform traversal regardless of underlying structure (array, tree, graph).

---

## 8️⃣ Mediator — *"All chat goes through me"* 🎙️

### Story
In a chat room, if every user knew every other user, that's N×N relationships. The chat room becomes a tangle.

### Solution
A `ChatRoom` mediator — users only know it. It knows everyone.

```python
class ChatRoom:
    def __init__(self): self.users = []
    def join(self, u): self.users.append(u); u.room = self
    def send(self, sender, msg):
        for u in self.users:
            if u is not sender: u.receive(msg)
```

### When to use
Decouple a network of communicating objects (e.g., UI dialogs, ATC tower, chat).

---

## 9️⃣ Memento — *"Snapshot for time-travel"* 🕰️

Undo isn't just for editors. Whenever you need to **save & restore** state without exposing internals → Memento.

```python
class EditorMemento:
    def __init__(self, content): self._content = content
class Editor:
    def __init__(self): self.content = ""
    def save(self): return EditorMemento(self.content)
    def restore(self, m): self.content = m._content
```

---

## 🧠 Pattern Picker

```
Pick algorithm at runtime?       → Strategy
React to events?                 → Observer
Object behaves differently/state?→ State
Need undo/redo or queueing?      → Command
Pipeline of handlers?            → Chain of Responsibility
Reusable algorithm skeleton?     → Template Method
Decouple many-to-many comm?      → Mediator
Need snapshots?                  → Memento
```

---

## 🎤 The Interview Lens

- *"Strategy vs State?"* → external choice vs internal transition.
- *"Show me a real Observer."* → Redux/Vuex stores, DOM events, Kafka consumers.
- *"How would you build undo?"* → Command + Memento.
- *"Middleware?"* → Chain of Responsibility.
- *"How do these patterns enforce SOLID?"*
  - Strategy/State → OCP
  - Observer → DIP (subject depends on observer interface)
  - Command → SRP (each action a class)

---

## 🧾 Cheat Card

| Pattern | Purpose | Real example |
|---|---|---|
| Strategy | swappable algorithms | shipping mode, sort comparator |
| Observer | pub/sub | event bus, Redux |
| State | behavior per state | TCP connection, vending machine |
| Command | action as object | undo/redo, job queue |
| Chain of Resp. | pass through handlers | middleware |
| Template Method | fixed steps + hooks | unit-test setup/teardown |
| Iterator | traversal | `for x in coll` |
| Mediator | hub of comm | chat room, ATC |
| Memento | save/restore state | editor undo |

---

➡️ **Next:** [Chapter 6 — UML Quickstart](./06-uml-quickstart.md)
