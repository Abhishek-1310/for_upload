# Chapter 7 — 🅿️ Case Study: Design a Parking Lot

> The most asked LLD interview question of all time. If you can ace this, half the LLD interviews are won.

---

## 🎬 The Prompt (As You'll Hear It)

> *"Design a parking lot system. Multiple floors, different vehicle types, payment at exit. Walk me through your classes."*

Most candidates immediately start coding. **Don't.** Use the **5-step LLD framework**:

```
1. Clarify requirements   (5 min)
2. Identify entities      (5 min)
3. Define relationships   (5 min)
4. Apply patterns         (5 min)
5. Code key classes       (15 min)
```

---

## Step 1 — Clarify (always ask, never assume)

Ask the interviewer:
- How many floors? entries/exits? (multi-entry?)
- Vehicle types? (Bike, Car, Truck — different spot sizes)
- Pricing model? (hourly? flat?)
- Reservation needed?
- Payment methods? (cash, card, UPI)
- Concurrency — multiple cars entering at once?

**Assume for this exercise:**
- Multi-floor, multi-entry/exit
- 3 vehicle types: Bike, Car, Truck → 3 spot sizes
- Hourly pricing per vehicle type
- No reservations
- Multiple payment methods
- Concurrent entries handled

---

## Step 2 — Identify Entities (Nouns!)

Read the requirements and extract **nouns**:

`ParkingLot, Floor, ParkingSpot, Vehicle (Bike/Car/Truck), Ticket, Entry/Exit Gate, Payment, DisplayBoard, ParkingAttendant`

That's your class list (roughly).

---

## Step 3 — Relationships

```
ParkingLot   ◆── 1..*  Floor
Floor        ◆── 1..*  ParkingSpot
ParkingSpot       ─── 0..1 Vehicle      (occupies)
Vehicle      ──▷ Bike, Car, Truck       (inheritance)
ParkingSpot  ──▷ BikeSpot, CarSpot, TruckSpot
EntryGate    ── creates ──▶ Ticket
ExitGate     ── processes ─▶ Payment
```

---

## Step 4 — Patterns You'll Use

| Concern | Pattern |
|---|---|
| One lot instance globally | **Singleton** (`ParkingLot`) |
| Pick spot type per vehicle | **Strategy** or **Factory** |
| Pricing per vehicle/duration | **Strategy** (`HourlyRate`, `FlatRate`) |
| Multiple payment methods | **Strategy** (`CardPayment`, `UPIPayment`, `Cash`) |
| Notify display board on park/leave | **Observer** |
| Build complex `Ticket` | **Builder** (optional) |

---

## Step 5 — Code (key classes)

```python
from abc import ABC, abstractmethod
from datetime import datetime
from enum import Enum
from threading import Lock
import uuid

# ─────── Vehicle Hierarchy ───────
class VehicleType(Enum):
    BIKE = 1; CAR = 2; TRUCK = 3

class Vehicle(ABC):
    def __init__(self, plate: str, vtype: VehicleType):
        self.plate = plate
        self.type = vtype

class Bike(Vehicle):  
    def __init__(self, plate): super().__init__(plate, VehicleType.BIKE)
class Car(Vehicle):   
    def __init__(self, plate): super().__init__(plate, VehicleType.CAR)
class Truck(Vehicle): 
    def __init__(self, plate): super().__init__(plate, VehicleType.TRUCK)


# ─────── Parking Spot ───────
class ParkingSpot(ABC):
    def __init__(self, spot_id, vtype: VehicleType):
        self.id = spot_id
        self.allowed = vtype
        self.vehicle = None
    def is_free(self): return self.vehicle is None
    def park(self, v: Vehicle):
        if not self.is_free(): raise Exception("occupied")
        if v.type != self.allowed: raise Exception("wrong size")
        self.vehicle = v
    def vacate(self): self.vehicle = None

class BikeSpot(ParkingSpot):  
    def __init__(self, i): super().__init__(i, VehicleType.BIKE)
class CarSpot(ParkingSpot):   
    def __init__(self, i): super().__init__(i, VehicleType.CAR)
class TruckSpot(ParkingSpot): 
    def __init__(self, i): super().__init__(i, VehicleType.TRUCK)


# ─────── Floor ───────
class Floor:
    def __init__(self, number, spots):
        self.number = number
        self.spots = spots                # list[ParkingSpot]
    def find_free(self, vtype: VehicleType):
        return next((s for s in self.spots if s.is_free() and s.allowed == vtype), None)


# ─────── Pricing Strategy ───────
class PricingStrategy(ABC):
    @abstractmethod
    def cost(self, vtype: VehicleType, hours: float) -> float: pass

class HourlyPricing(PricingStrategy):
    rates = {VehicleType.BIKE: 10, VehicleType.CAR: 30, VehicleType.TRUCK: 50}
    def cost(self, vtype, hours): return self.rates[vtype] * max(1, hours)


# ─────── Ticket ───────
class Ticket:
    def __init__(self, vehicle, spot, floor):
        self.id = str(uuid.uuid4())[:8]
        self.vehicle = vehicle
        self.spot = spot
        self.floor = floor
        self.entry_time = datetime.now()
        self.exit_time = None
        self.amount = 0


# ─────── Payment Strategy ───────
class PaymentStrategy(ABC):
    @abstractmethod
    def pay(self, amount): pass

class CardPayment(PaymentStrategy):
    def pay(self, a): print(f"Paid {a} by card"); return True
class UPIPayment(PaymentStrategy):
    def pay(self, a): print(f"Paid {a} via UPI"); return True


# ─────── Observer (Display Board) ───────
class DisplayBoard:
    def update(self, lot): 
        print(f"[Display] free spots: {lot.free_count()}")


# ─────── Parking Lot (Singleton) ───────
class ParkingLot:
    _instance = None
    _lock = Lock()
    def __new__(cls, *a, **kw):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
        return cls._instance

    def init(self, floors, pricing: PricingStrategy):
        self.floors = floors                # list[Floor]
        self.pricing = pricing
        self.tickets = {}
        self.observers = []
        self._lock = Lock()                 # for concurrent entries

    def add_observer(self, o): self.observers.append(o)
    def _notify(self):
        for o in self.observers: o.update(self)

    def free_count(self):
        return sum(1 for f in self.floors for s in f.spots if s.is_free())

    def park(self, vehicle: Vehicle) -> Ticket:
        with self._lock:                    # 🔒 thread safety
            for f in self.floors:
                spot = f.find_free(vehicle.type)
                if spot:
                    spot.park(vehicle)
                    t = Ticket(vehicle, spot, f)
                    self.tickets[t.id] = t
                    self._notify()
                    return t
            raise Exception("Lot full")

    def unpark(self, ticket_id, payment: PaymentStrategy) -> float:
        with self._lock:
            t = self.tickets[ticket_id]
            t.exit_time = datetime.now()
            hours = (t.exit_time - t.entry_time).total_seconds() / 3600
            t.amount = self.pricing.cost(t.vehicle.type, hours)
            payment.pay(t.amount)
            t.spot.vacate()
            del self.tickets[ticket_id]
            self._notify()
            return t.amount
```

### Driver
```python
floors = [Floor(1, [BikeSpot("B1"), CarSpot("C1"), TruckSpot("T1")])]
lot = ParkingLot(); lot.init(floors, HourlyPricing())
lot.add_observer(DisplayBoard())

t = lot.park(Car("KA-01-9999"))
# ... time passes ...
lot.unpark(t.id, UPIPayment())
```

---

## ⚠️ Common follow-ups (be ready!)

1. **"What if two cars try to grab the same spot?"** → Lock per `ParkingLot.park()` (shown above), or per spot. Discuss DB-level row locks if persisted.
2. **"How will it scale to 1000 lots nationwide?"** → That's HLD: each lot = one service, central ticketing in DB, sharded by lot_id.
3. **"Can a truck park in two car spots?"** → Add a `find_combined_free` strategy.
4. **"Add EV charging spots."** → Just a new `ParkingSpot` subclass + `VehicleType`. **OCP wins!**
5. **"How do you test it?"** → Inject pricing/payment via constructor (DIP). Mock them in tests.

---

## ✅ What This Demonstrates

| Concept | Where |
|---|---|
| OOP — inheritance & polymorphism | `Vehicle`, `ParkingSpot` hierarchies |
| SRP | Pricing, Payment, Display each separated |
| OCP | New vehicle/payment type → new class, no edit |
| DIP | Lot depends on `PricingStrategy` interface |
| Singleton | `ParkingLot` |
| Strategy | Pricing, Payment |
| Observer | Display board |
| Concurrency | `threading.Lock` |

This is a textbook **"yes-hire"** answer. Practice telling it in 25 minutes.

---

➡️ **Next:** [Chapter 8 — Splitwise](./08-case-splitwise.md)
