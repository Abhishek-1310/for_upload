# Chapter 8 — 💸 Case Study: Splitwise

> *"A group of 4 friends went on a trip. Some paid for hotel, some for food, some for fuel. Tell me who owes whom how much."*

---

## Step 1 — Clarify

- Group has many users; users can be in many groups → many-to-many.
- Expense types: **EQUAL**, **EXACT**, **PERCENTAGE**.
- Settle balances (simplify debts).
- Single currency for now.
- Persistence later (interview rarely cares).

---

## Step 2 — Entities

`User, Group, Expense, Split (Equal/Exact/Percent), ExpenseService, BalanceSheet`

---

## Step 3 — Relationships

```
User      *──* Group
Group     1──* Expense
Expense   1──* Split
Split     1──1 User
ExpenseService  ── manages ─▶ BalanceSheet (per user)
```

---

## Step 4 — Patterns

| Concern | Pattern |
|---|---|
| Different ways of splitting | **Strategy** |
| Build different `Expense` types fluently | **Factory / Builder** |
| Notify users on new expense | **Observer** |

---

## Step 5 — Code

```python
from abc import ABC, abstractmethod
from collections import defaultdict
from enum import Enum
import uuid

class User:
    def __init__(self, name): self.id = str(uuid.uuid4())[:6]; self.name = name
    def __repr__(self): return self.name

# ── Splits ──
class Split:
    def __init__(self, user: User): self.user = user; self.amount = 0.0

class SplitType(Enum):
    EQUAL = 1; EXACT = 2; PERCENT = 3

# ── Strategy: how to compute splits ──
class SplitStrategy(ABC):
    @abstractmethod
    def compute(self, total, splits, extras=None): pass

class EqualSplit(SplitStrategy):
    def compute(self, total, splits, extras=None):
        per = round(total / len(splits), 2)
        for s in splits: s.amount = per

class ExactSplit(SplitStrategy):
    def compute(self, total, splits, extras):     # extras: list[float]
        assert abs(sum(extras) - total) < 0.01
        for s, amt in zip(splits, extras): s.amount = amt

class PercentSplit(SplitStrategy):
    def compute(self, total, splits, extras):     # extras: list[%]
        assert abs(sum(extras) - 100) < 0.01
        for s, p in zip(splits, extras): s.amount = round(total * p / 100, 2)

STRATEGIES = {
    SplitType.EQUAL: EqualSplit(),
    SplitType.EXACT: ExactSplit(),
    SplitType.PERCENT: PercentSplit(),
}

# ── Expense ──
class Expense:
    def __init__(self, paid_by: User, amount: float, split_type: SplitType,
                 participants: list[User], extras=None, desc=""):
        self.id = str(uuid.uuid4())[:6]
        self.paid_by = paid_by
        self.amount = amount
        self.desc = desc
        self.splits = [Split(u) for u in participants]
        STRATEGIES[split_type].compute(amount, self.splits, extras)

# ── Balance Sheet (the heart) ──
# balances[A][B] = how much A owes B
class ExpenseService:
    def __init__(self):
        self.balances = defaultdict(lambda: defaultdict(float))
        self.expenses = []

    def add_expense(self, exp: Expense):
        self.expenses.append(exp)
        for s in exp.splits:
            if s.user.id == exp.paid_by.id: continue
            # s.user owes exp.paid_by amount = s.amount
            self.balances[s.user.id][exp.paid_by.id] += s.amount
            # net out the reverse direction
            reverse = self.balances[exp.paid_by.id][s.user.id]
            if reverse > 0:
                offset = min(reverse, self.balances[s.user.id][exp.paid_by.id])
                self.balances[exp.paid_by.id][s.user.id] -= offset
                self.balances[s.user.id][exp.paid_by.id] -= offset

    def show(self, users):
        for u in users:
            for v in users:
                amt = self.balances[u.id][v.id]
                if amt > 0.001:
                    print(f"{u.name} owes {v.name}: {round(amt, 2)}")
```

### Driver
```python
A, B, C = User("Abhi"), User("Bhanu"), User("Charu")
svc = ExpenseService()

# Hotel 3000, paid by A, split equally
svc.add_expense(Expense(A, 3000, SplitType.EQUAL, [A, B, C]))
# Food 600, paid by B, exact split A:200, B:100, C:300
svc.add_expense(Expense(B, 600, SplitType.EXACT, [A, B, C], extras=[200, 100, 300]))

svc.show([A, B, C])
# Bhanu owes Abhi: 900
# Charu owes Abhi: 1000
# Charu owes Bhanu:  -- (auto-netted)
```

---

## ⚠️ Follow-ups

1. **"Simplify debts (debt graph minimization)?"** → Use heap-based settlement: net each user's balance, then biggest creditor pays biggest debtor until zero. Mention it's similar to a min-cost flow problem.
2. **"Concurrency for two simultaneous expense additions?"** → Lock the involved users' balance rows, or use DB transactions with isolation level `SERIALIZABLE`.
3. **"Multi-currency?"** → Add currency to Expense; convert via FX rate strategy.
4. **"How is this stored in DB?"** → `users`, `groups`, `expenses`, `splits` tables. `balances` materialized view recomputed on each insert *or* event-sourced.
5. **"How to scale to millions of users?"** → That's HLD: shard by `group_id`. Use Kafka for expense events; consumers update balance store (Redis sorted sets / Cassandra).

---

## ✅ Concepts demonstrated
- **Strategy pattern** for splits (Equal / Exact / Percent)
- **SRP**: ExpenseService owns balances, Expense owns its splits
- **OCP**: add new split type → new strategy class
- Domain modeling with clean entities

---

➡️ **Next:** [Chapter 9 — BookMyShow](./09-case-bookmyshow.md)
