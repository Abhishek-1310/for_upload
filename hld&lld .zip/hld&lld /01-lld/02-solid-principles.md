# Chapter 2 — SOLID: The Startup That Kept Breaking 🏗️

## 🎬 The Problem Appears

You join **"Shipfast"**, a 3-person startup building a delivery app. The codebase is 6 months old. Every Monday someone pushes a fix, and by Friday three other things break.

The CTO says: *"Our code is fragile. We need principles."*

That week you discover **SOLID** — five principles named by Robert C. Martin. Each one is a *scar* — a wound the industry suffered before learning the lesson. Let's walk through each scar.

---

## 🅢 — Single Responsibility Principle (SRP)

> **A class should have one, and only one, reason to change.**

### The wound
You see this `Invoice` class:
```python
class Invoice:
    def calculate_total(self): ...
    def save_to_db(self): ...
    def send_email(self): ...
    def print_pdf(self): ...
```
Marketing wants a new email template → you touch `Invoice`. DB team migrates Postgres → you touch `Invoice`. PDF library upgrades → you touch `Invoice`.

**One class, four reasons to change.** Every change risks breaking the others.

### The fix
Split by *responsibility*:
```python
class Invoice:           # business logic only
    def calculate_total(self): ...

class InvoiceRepository:  # persistence
    def save(self, inv): ...

class InvoiceMailer:      # notifications
    def send(self, inv): ...

class InvoicePrinter:     # presentation
    def to_pdf(self, inv): ...
```

### Interview line
> *"I split classes when they have more than one **axis of change** — different stakeholders or different rates of change."*

---

## 🅞 — Open/Closed Principle (OCP)

> **Open for extension, closed for modification.**

### The wound
Discount logic at Shipfast:
```python
def calculate_discount(user):
    if user.type == "regular": return 0
    elif user.type == "premium": return 10
    elif user.type == "vip":     return 20
    # next week: STUDENT, SENIOR, BLACKFRIDAY...
```
Every new user type means **editing this function** — risking old logic.

### The fix — polymorphism
```python
class DiscountPolicy(ABC):
    @abstractmethod
    def percent(self): pass

class Premium(DiscountPolicy):  def percent(self): return 10
class VIP(DiscountPolicy):      def percent(self): return 20
class Student(DiscountPolicy):  def percent(self): return 15  # new! no edit!
```
You **extend** by adding a class. You don't **modify** existing code.

### Interview line
> *"If adding a feature forces me to edit a switch/if-else chain across the codebase, OCP is violated. I'd refactor to a strategy/polymorphic design."*

---

## 🅛 — Liskov Substitution Principle (LSP)

> **Subtypes must be substitutable for their base types without breaking behavior.**

### The wound — the famous Square/Rectangle trap
```python
class Rectangle:
    def set_width(self, w):  self.w = w
    def set_height(self, h): self.h = h
    def area(self): return self.w * self.h

class Square(Rectangle):       # Square IS-A Rectangle, right?
    def set_width(self, w):  self.w = self.h = w
    def set_height(self, h): self.w = self.h = h
```
Now this test:
```python
def test(r: Rectangle):
    r.set_width(5); r.set_height(4)
    assert r.area() == 20   # FAILS for Square (returns 16)
```
The subclass *broke* the parent's contract. That's an LSP violation.

### The fix
Don't model "is-a" by language inheritance unless behavior is preserved. Use composition or a common abstraction (e.g., both implement `Shape.area()`).

### Interview line
> *"LSP isn't about syntax — it's about **contracts**. A subclass shouldn't strengthen preconditions or weaken postconditions."*

---

## 🅘 — Interface Segregation Principle (ISP)

> **Don't force clients to depend on methods they don't use.**

### The wound
```python
class Worker(ABC):
    def code(self): ...
    def attend_meeting(self): ...
    def review_pr(self): ...

class Intern(Worker):
    def code(self): ...
    def attend_meeting(self): raise NotImplementedError  # 😬
    def review_pr(self): raise NotImplementedError       # 😬
```
The intern is forced to implement methods they don't do. Fat interface.

### The fix — split interfaces
```python
class Coder(ABC):       def code(self): ...
class MeetingGoer(ABC): def attend_meeting(self): ...
class Reviewer(ABC):    def review_pr(self): ...

class Intern(Coder): ...
class Senior(Coder, MeetingGoer, Reviewer): ...
```

### Interview line
> *"Many small focused interfaces beat one fat interface. Clients should only see the methods they care about."*

---

## 🅓 — Dependency Inversion Principle (DIP)

> **Depend on abstractions, not concretions.**

### The wound
```python
class MySQLDatabase:
    def save(self, data): ...

class OrderService:
    def __init__(self):
        self.db = MySQLDatabase()   # ⛓️ hard-wired
    def place_order(self, o): self.db.save(o)
```
Want to switch to Postgres? Test with a mock? You can't — `OrderService` is **glued** to MySQL.

### The fix — inject the abstraction
```python
class Database(ABC):
    @abstractmethod
    def save(self, data): pass

class MySQLDatabase(Database): ...
class PostgresDatabase(Database): ...

class OrderService:
    def __init__(self, db: Database):    # depends on the *interface*
        self.db = db
```
Now you swap implementations freely. This is the foundation of **dependency injection** and testability.

### Interview line
> *"High-level modules shouldn't depend on low-level details. Both should depend on abstractions. This is what makes systems testable and replaceable."*

---

## 🧠 The Mental Model

Picture SOLID as **5 walls of a house**:

```
   S — Each room has one purpose (kitchen ≠ bathroom)
   O — Add a new room without breaking old ones
   L — Replace any furniture with a same-shaped one
   I — Don't put a kitchen sink in the bedroom
   D — Wire to sockets (interfaces), not to specific bulbs
```

If even one wall is missing, the house wobbles.

---

## 🎤 The Interview Lens

Common asks:
1. *"Walk me through SOLID with examples."* → Tell each scar story.
2. *"Which principle do you find hardest in practice?"* → Honest answer: LSP. Discuss the contract issue.
3. *"How does DIP enable testing?"* → Mocks/fakes implement the abstraction.
4. *"Is SOLID always good?"* → No. Over-applied → tons of tiny classes, premature abstraction. Apply when **change is happening** or **clearly coming**.

---

## 🧾 Cheat Card

```
S — Single Responsibility  → one reason to change
O — Open/Closed            → extend, don't modify
L — Liskov Substitution    → subclass keeps the contract
I — Interface Segregation  → many small interfaces
D — Dependency Inversion   → depend on abstractions

Smell → Principle violated → Fix
  god class           → SRP → split
  growing if/else     → OCP → polymorphism
  override that throws→ LSP → rethink hierarchy
  unused methods      → ISP → split interface
  `new ConcreteX()`   → DIP → inject interface
```

---

➡️ **Next:** [Chapter 3 — Creational Design Patterns](./03-design-patterns-creational.md)
