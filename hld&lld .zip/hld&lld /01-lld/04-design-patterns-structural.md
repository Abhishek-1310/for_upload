# Chapter 4 — Structural Patterns: Wiring Objects Together 🔗

## 🎬 The Setup

You can now create objects gracefully. But your real codebase has dozens of classes that need to **work together** — sometimes they speak different languages, sometimes you want to add behavior without touching the original, sometimes you want to hide a complicated mess behind a clean door.

These are **Structural Patterns** — how objects compose into bigger structures.

---

## 1️⃣ Adapter — *"The travel plug"* 🔌

### Story
You bought a payments library: `StripeAPI.charge(amount)`. Your app already calls `payment.pay(amount)`. Replacing 200 call sites? No way.

### Solution
Wrap the new thing in your old shape.

```python
class StripeAPI:                      # 3rd party
    def charge(self, amt): print(f"Stripe ${amt}")

class PaymentGateway(ABC):
    @abstractmethod
    def pay(self, amount): pass

class StripeAdapter(PaymentGateway):
    def __init__(self, stripe): self.stripe = stripe
    def pay(self, amount): self.stripe.charge(amount)

gateway = StripeAdapter(StripeAPI())
gateway.pay(500)
```

### When to use
Integrating legacy code, third-party APIs with mismatched interfaces.

---

## 2️⃣ Decorator — *"Add toppings without changing the pizza"* 🎀

### Story
Your `DataReader` reads a file. Now you want **encrypted + compressed** reads. Subclassing for every combo gives `EncryptedCompressedBufferedReader` — explosion.

### Solution
Wrap with decorators — each adds one behavior.

```python
class DataSource(ABC):
    @abstractmethod
    def read(self): pass

class FileSource(DataSource):
    def read(self): return "raw-data"

class EncryptionDecorator(DataSource):
    def __init__(self, src): self.src = src
    def read(self): return f"encrypted({self.src.read()})"

class CompressionDecorator(DataSource):
    def __init__(self, src): self.src = src
    def read(self): return f"compressed({self.src.read()})"

src = CompressionDecorator(EncryptionDecorator(FileSource()))
print(src.read())  # compressed(encrypted(raw-data))
```

### When to use
Add responsibilities **dynamically** without subclass explosion.
Real example: Java `BufferedReader(new FileReader(...))`, Python `@decorators`.

---

## 3️⃣ Facade — *"One door to the chaos"* 🏛️

### Story
To boot the home theater you must:
```
projector.on(); screen.down(); amp.on(); amp.setSource(BLU);
lights.dim(20); player.insertDisc(); player.play();
```
7 calls. Every user gets it wrong.

### Solution
A **facade** wraps it all behind one method.

```python
class HomeTheaterFacade:
    def __init__(self, *components): self.c = components
    def watch_movie(self):
        for step in [start_lights, start_amp, start_screen, start_player]:
            step()
    def end_movie(self): ...
```

### When to use
Simplify usage of a complex subsystem. Doesn't *hide* the subsystem — power users can still go directly.

> Almost every "service layer" in a backend app is a facade.

---

## 4️⃣ Proxy — *"The bouncer"* 🛡️

### Story
You expose an `Image` class. Loading high-res images is **slow**. You also want to log accesses and check permissions.

### Solution
A proxy stands in front, controlling access.

```python
class Image(ABC):
    @abstractmethod
    def display(self): pass

class RealImage(Image):
    def __init__(self, path):
        self.path = path
        self._load()                 # expensive
    def _load(self): print(f"loading {self.path}")
    def display(self): print(f"showing {self.path}")

class ImageProxy(Image):
    def __init__(self, path): self.path = path; self._real = None
    def display(self):
        if self._real is None:       # lazy load
            self._real = RealImage(self.path)
        self._real.display()
```

### Variants
- **Virtual proxy** — lazy loading (above)
- **Protection proxy** — auth checks
- **Remote proxy** — network calls (e.g., RPC stubs)
- **Caching proxy** — return cached results

---

## 5️⃣ Composite — *"Tree of things treated alike"* 🌳

### Story
A file system. Files have size. Folders also have size — sum of children. You want `node.size()` to work the same way for both.

### Solution
Both implement the same interface.

```python
class FSNode(ABC):
    @abstractmethod
    def size(self): pass

class File(FSNode):
    def __init__(self, sz): self.sz = sz
    def size(self): return self.sz

class Folder(FSNode):
    def __init__(self): self.children = []
    def add(self, n): self.children.append(n)
    def size(self): return sum(c.size() for c in self.children)
```
Now any client treats a file or a folder identically. Recursion built-in.

### When to use
Tree structures: file systems, UI components, org charts, menus.

---

## 6️⃣ Bridge — *"Decouple abstraction from implementation"* 🌉

### Story
You have `Shape` (Circle, Square) and `Color` (Red, Blue). A naive design creates `RedCircle, BlueCircle, RedSquare, BlueSquare` — 2×2 = 4. Add 5 colors and 10 shapes → 50 classes.

### Solution
Split into two hierarchies linked by composition.

```python
class Color(ABC):
    @abstractmethod
    def fill(self): pass
class Red(Color):  def fill(self): return "red"
class Blue(Color): def fill(self): return "blue"

class Shape(ABC):
    def __init__(self, color: Color): self.color = color
    @abstractmethod
    def draw(self): pass

class Circle(Shape):
    def draw(self): print(f"{self.color.fill()} circle")
```
Now 5 colors + 10 shapes = 15 classes, not 50.

---

## 7️⃣ Flyweight — *"Share what's common"* 🪶

### Story
A document has 1 million characters. Each `Character` object stores font, size, color → 1M objects, gigabytes of RAM.

### Solution
Separate **intrinsic** (shared: font, size) from **extrinsic** (per-use: position). Keep one shared instance per intrinsic state.

Used in: text editors, game sprites, char/glyph rendering.

---

## 🧠 Pattern Picker

```
Mismatched interfaces?       → Adapter
Add behavior at runtime?     → Decorator
Hide complex subsystem?      → Facade
Control access / lazy load?  → Proxy
Tree of like things?         → Composite
Two changing dimensions?     → Bridge
Tons of similar objects?     → Flyweight
```

---

## 🎤 The Interview Lens

- *"Adapter vs Decorator vs Proxy?"*
  - Adapter: changes the *interface*
  - Decorator: keeps interface, adds *behavior*
  - Proxy: keeps interface, controls *access*
- *"Facade vs Adapter?"* → Facade simplifies a system; Adapter makes incompatible interfaces compatible.
- *"Where have you used decorators?"* → middleware in web frameworks, Python `@functools.lru_cache`.

---

## 🧾 Cheat Card

| Pattern | Purpose | Mnemonic |
|---|---|---|
| Adapter | bridge incompatible APIs | *travel plug* |
| Decorator | add behavior dynamically | *toppings* |
| Facade | simplify subsystem | *one door* |
| Proxy | control access | *bouncer* |
| Composite | tree of uniform parts | *file system* |
| Bridge | split two dimensions | *shape × color* |
| Flyweight | share common state | *one font, many chars* |

---

➡️ **Next:** [Chapter 5 — Behavioral Patterns](./05-design-patterns-behavioral.md)
