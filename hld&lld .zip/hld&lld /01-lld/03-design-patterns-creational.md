# Chapter 3 — Creational Patterns: How Objects Are Born 🧬

## 🎬 The Setup

You've internalized OOP and SOLID. Now your boss says:

> *"We need to create thousands of objects — payments, users, reports. But the *way* they're created keeps changing. Every refactor breaks our `new XYZ(...)` calls scattered everywhere."*

Welcome to the world of **Creational Patterns** — five proven ways to control how objects come into existence.

---

## 1️⃣ Singleton — *"There can be only one"* 👑

### Story
Your app has a `Logger`. Every class creates its own `Logger()`. You end up with 50 loggers fighting over the same log file.

### Solution
One global instance. Forever.

```python
class Logger:
    _instance = None
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    def log(self, msg): print(f"[LOG] {msg}")

a = Logger(); b = Logger()
assert a is b   # same object
```

### When to use
Logger, Config, DB connection pool, Cache.

### ⚠️ Traps
- **Hidden global state** → hard to test.
- **Thread safety** → use `threading.Lock` or static init.
- Often considered an *anti-pattern* if overused. Prefer **Dependency Injection** when possible.

---

## 2️⃣ Factory Method — *"You order; I'll figure out which kitchen"* 🏭

### Story
Your notification service:
```python
if type == "email": n = EmailNotifier()
elif type == "sms":  n = SMSNotifier()
elif type == "push": n = PushNotifier()
```
This `if-else` lives in **20 places**. Every new channel = 20 edits. (OCP violation, remember?)

### Solution
A factory class decides *which* concrete class to build.

```python
class Notifier(ABC):
    @abstractmethod
    def send(self, msg): pass

class EmailNotifier(Notifier):  def send(self, m): print("📧", m)
class SMSNotifier(Notifier):    def send(self, m): print("📱", m)

class NotifierFactory:
    @staticmethod
    def create(kind: str) -> Notifier:
        return {"email": EmailNotifier, "sms": SMSNotifier}[kind]()

NotifierFactory.create("email").send("hi")
```

### When to use
Whenever the **type to instantiate** depends on input/config and you want one place to manage it.

---

## 3️⃣ Abstract Factory — *"Family of related products"* 🏰

### Story
You're building a UI toolkit. On Mac you want `MacButton + MacMenu`. On Windows: `WinButton + WinMenu`. Mixing them looks ugly.

### Solution
A factory that produces *families* of objects guaranteed to match.

```python
class GUIFactory(ABC):
    def create_button(self): ...
    def create_menu(self): ...

class MacFactory(GUIFactory):
    def create_button(self): return MacButton()
    def create_menu(self):   return MacMenu()

class WinFactory(GUIFactory):
    def create_button(self): return WinButton()
    def create_menu(self):   return WinMenu()
```

### Factory Method vs Abstract Factory
- Factory Method = **one** product
- Abstract Factory = **family** of products that go together

---

## 4️⃣ Builder — *"Step-by-step construction"* 🧱

### Story
Your `Pizza` constructor:
```python
Pizza("large", True, False, True, True, False, "thin", "tomato", ["cheese","olives"])
```
Nobody can read this. Add one more param → everything breaks.

### Solution
Build piece by piece with a fluent API.

```python
class Pizza:
    def __init__(self): self.toppings=[]; self.size=None; self.crust=None
    def __repr__(self): return f"{self.size} {self.crust} pizza w/ {self.toppings}"

class PizzaBuilder:
    def __init__(self): self.p = Pizza()
    def size(self, s):     self.p.size = s; return self
    def crust(self, c):    self.p.crust = c; return self
    def add(self, t):      self.p.toppings.append(t); return self
    def build(self):       return self.p

pizza = (PizzaBuilder()
         .size("large").crust("thin")
         .add("cheese").add("olives")
         .build())
```

### When to use
- Many optional parameters
- Object needs to be immutable after construction
- Different representations of the same construction process

> Real-world: `StringBuilder`, `HttpRequest.Builder`, SQL query builders.

---

## 5️⃣ Prototype — *"Clone instead of build"* 🧬

### Story
You generate game enemies. Building one from scratch reads a config file, hits a DB, computes stats — **slow**. You need 1000 of them.

### Solution
Build one "prototype" → **clone** the rest.

```python
import copy
class Enemy:
    def __init__(self, hp, weapons): self.hp=hp; self.weapons=weapons
    def clone(self): return copy.deepcopy(self)

orc = Enemy(100, ["axe"])
army = [orc.clone() for _ in range(1000)]
```

### When to use
- Object creation is expensive
- You need many similar objects with small variations

---

## 🧠 Pattern Picker

```
Want only 1 instance?              → Singleton
Want to hide which class is built? → Factory Method
Need a family of matching objects? → Abstract Factory
Constructor has too many params?   → Builder
Creation is expensive, want copies?→ Prototype
```

---

## 🎤 The Interview Lens

- *"Difference between Factory Method and Abstract Factory?"* → one product vs family.
- *"Why is Singleton sometimes called an anti-pattern?"* → hidden global state, test pain.
- *"When would you use Builder over a constructor?"* → > 3-4 optional params, or immutability needed.
- *"How do these patterns relate to SOLID?"* → They mostly enforce **OCP** (extend without modifying) and **DIP** (clients depend on abstractions, not `new X()`).

---

## 🧾 Cheat Card

| Pattern | One-liner | Real example |
|---|---|---|
| Singleton | one instance only | Logger, Config |
| Factory Method | pick subclass at runtime | `NotifierFactory` |
| Abstract Factory | family of products | Cross-platform UI |
| Builder | step-by-step build | `StringBuilder`, SQL builder |
| Prototype | clone existing | Game entities, deep copy |

---

➡️ **Next:** [Chapter 4 — Structural Patterns](./04-design-patterns-structural.md)
