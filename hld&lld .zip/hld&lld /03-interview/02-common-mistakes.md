# Interview Chapter 2 — Why Candidates Fail (and how not to) ❌→✅

> Real reasons interviewers reject "technically correct" candidates.

---

## ❌ 1. Solving before understanding
You hear "design Twitter" and start drawing a feed before asking *which* features.
**Fix:** spend the first 5 minutes asking and confirming scope. Bonus: write the bullet list on the board.

## ❌ 2. Buzzword soup
*"I'll use Kubernetes, Kafka, Spark, Flink, Cassandra, Redis, Elasticsearch, gRPC..."*
**Fix:** for each tech, say **why** ("Kafka because we need replayable async fan-out"). If you can't justify it, drop it.

## ❌ 3. No estimation
Skipping the math means your architecture is unjustified. Adding sharding for 100 QPS is overkill; *not* adding caching for 100K QPS is naïve.
**Fix:** spend 3 minutes on back-of-envelope math early.

## ❌ 4. Silent thinking
The interviewer can't read your mind. Long silence = no signal = bad signal.
**Fix:** narrate. *"I'm comparing push vs pull fan-out... push is faster reads but expensive for celebs..."*

## ❌ 5. Refusing trade-offs
*"This is the right way."* Wrong. Every choice has cost.
**Fix:** always frame as *"Option A vs Option B; A wins because of X."*

## ❌ 6. Ignoring failure modes
*"And then it works."* — but interviewer cares about what happens when DB dies, network partitions, message duplicates.
**Fix:** end every component with one line on failure: *"If this dies, we fall back to Y."*

## ❌ 7. Premature optimization
Sharding, microservices, multi-region on day 1 of a startup tool? No.
**Fix:** "Start simple, scale when forced." Show the **growth path**, not the endgame.

## ❌ 8. Forgetting the read/write ratio
A 100:1 read-heavy system has very different architecture than write-heavy. Not naming it = missed signal.
**Fix:** state read:write early. It changes caching, replication, and storage choices.

## ❌ 9. Drawing too much, talking too little (or vice versa)
A diagram nobody understands is useless. A monologue with no diagram is forgettable.
**Fix:** alternate — sketch, then explain that piece, then sketch the next.

## ❌ 10. Defensive when challenged
Interviewer pushes back; you double down. Now they think you don't take input.
**Fix:** *"Good point — let me reconsider. If we did X instead, we'd get..."*

## ❌ 11. LLD: Going straight to code
Without entities/relationships, your code reflects no design.
**Fix:** spend 5-10 min on entities, relationships, patterns *before* code.

## ❌ 12. LLD: Not using SOLID/patterns explicitly
You implement Strategy but don't say "I'm using Strategy here." Interviewer might miss it.
**Fix:** name your patterns. *"Each payment method is a Strategy implementing PaymentMethod interface."*

## ❌ 13. Confusing aggregation/composition, has-a/is-a
A small UML mistake undermines confidence.
**Fix:** memorize: composition (◆) = strong/lifecycle, aggregation (◇) = weak.

## ❌ 14. No idempotency / no retries discussion
At scale, retries are mandatory. If you don't mention idempotency, you signaled inexperience.
**Fix:** mention `Idempotency-Key`, dedup, exactly-once-via-idempotent-consumer.

## ❌ 15. Not adapting to interviewer hints
They say *"What if there are 1M followers?"* — you keep talking about API design.
**Fix:** when they probe, **dive in**. They're guiding you to score points.

---

## ✅ Habits of Strong Candidates

- Ask 4-6 clarifying questions
- Write requirements bullet list visibly
- Do real numbers, even rough ones
- State assumptions explicitly: *"Assuming 100M DAU…"*
- Compare 2-3 options for major decisions
- Always say *"Trade-off: X vs Y"*
- End with summary + future improvements
- Comfortable saying "I don't know, but I'd find out by..."

---

## ✅ The Magic Phrases

Use these. They flag seniority:

- *"Let's start with the simplest design that meets the requirements, then scale."*
- *"What's the read-to-write ratio?"*
- *"Is this consistency-critical or eventual is OK?"*
- *"Let's identify the bottleneck before adding complexity."*
- *"Trade-off here: A is simpler but B scales better. Given our scale, I'd pick..."*
- *"This component must be idempotent because retries are inevitable."*
- *"For observability, I'd track p99 latency, error rate, queue lag."*

---

## ✅ Recovery When Stuck

- *"Let me think out loud..."* (buys time, narrates)
- *"Let's enumerate options. Option 1... Option 2..."*
- Re-read the question on the board
- Simplify: *"If I drop feature X, the design becomes Y; let me start there."*

---

➡️ **Next:** [Cheatsheet](./03-cheatsheet.md)
