# Interview Chapter 1 — The 7-Step Framework for ANY HLD/LLD Question 🎤

> Memorize this. Walk into the interview. Apply it. Pass.

---

## The 7 Steps

```
1. CLARIFY      → ask, never assume
2. ESTIMATE     → numbers tell the architecture
3. APIs         → contract first
4. DATA MODEL   → entities + relationships
5. HIGH-LEVEL   → boxes & arrows
6. DEEP-DIVE    → pick 1-2 components, go deep
7. SCALE & FAIL → bottlenecks, failure modes
```

Total time budget: 45 minutes. Roughly 5+5+5+5+10+10+5 minutes.

---

## Step 1 — Clarify (5 min)

**Always start here. Never code first.**

Ask:
- What are the **core features**? (drop "nice-to-haves" if interviewer doesn't push)
- **Scale**: DAU, QPS, data size?
- Read-heavy or write-heavy?
- Latency target?
- Consistency needs (strong vs eventual)?
- Any constraints? (mobile-first, regulatory, region)

> Repeat back what you understood: *"So we're designing X for Y users with Z requirements. Sound right?"*

This step alone differentiates senior vs junior candidates.

---

## Step 2 — Estimate (5 min)

Quick capacity math, written on the board:

```
DAU × actions/day      → events/day
÷ 86,400 seconds       → average QPS
× 3 (peak factor)      → peak QPS
× bytes per record     → storage/day
× retention years      → total storage
```

Why: numbers drive architecture choices.
- 100 QPS? Single Postgres. No microservices.
- 100K QPS? Cache, sharding, Kafka.
- 100M QPS? CDN, edge compute, multi-region.

---

## Step 3 — APIs (5 min)

Define the few core APIs. Just signatures + a brief description.

```
POST /post           { content, media }       → { post_id }
GET  /feed?cursor=X                            → { posts, next_cursor }
POST /follow         { target_user }           → 204
```

Mention: REST/gRPC/GraphQL? Authentication? Idempotency keys?

---

## Step 4 — Data Model (5 min)

Sketch entities and key relationships.

```
User(user_id PK, name, ...)
Post(post_id PK, user_id FK, content, ts)
Follow(follower_id, followee_id) PK both, INDEX on each side
```

Mention indexes you'd add and **partition/shard keys** at scale.
Pick datastore per entity (Postgres / Cassandra / Redis / S3) with **one-line justification**.

---

## Step 5 — High-Level Architecture (10 min)

Draw the boxes-and-arrows diagram.

```
[Client] → [LB] → [API Gateway] → [Services]
                                     ├─ DB
                                     ├─ Cache
                                     └─ Kafka → workers
```

Talk through the request flow: *"User taps Post → goes to Post Service → writes Cassandra → emits Kafka event → Fan-out workers update timelines."*

This is your **anchor** — interviewer can now ask anything in this picture.

---

## Step 6 — Deep-Dive (10 min)

Interviewer will pick **one part** and ask "How does this scale?" or "What if X fails?".

Common deep-dive areas:
- Database sharding strategy
- Caching strategy (and invalidation)
- Async pipeline / Kafka topology
- A specific algorithm (matching, ranking, geo search)
- Concurrency / consistency

Show off SOLID/patterns/CAP knowledge here.

---

## Step 7 — Scale & Failure (5 min)

Wrap up with:
- **Bottlenecks**: where would this break first? (DB writes, hot keys, single LB)
- **Failures**: what if a component dies? (replication, retries, circuit breakers, DLQ)
- **Monitoring**: what would I dashboard? (p99 latency, error rate, queue lag)
- **Future improvements**: things you'd add given more time

End with a confident summary: *"To summarize, we built X using Y; the main scaling levers are Z."*

---

## Anti-Patterns (★ avoid these)

❌ Jumping into code/diagrams before clarifying
❌ Buzzword vomit ("I'll add Kafka, Redis, Kubernetes, Spark, Cassandra" with no reason)
❌ One-size-fits-all microservices on day 1
❌ Ignoring the interviewer's hints (they're telling you what to dive into)
❌ "Perfect" silence — *think out loud*
❌ Refusing to estimate ("I don't know exact numbers") — give a reasonable guess

---

## What Interviewers Actually Score

1. **Clarification & scoping** — do you ask before assuming?
2. **Trade-off thinking** — can you compare two designs?
3. **Depth in your strongest area** — convince them you've built something real
4. **Communication** — clear narrative, simple diagrams
5. **Scale awareness** — handle 10× growth gracefully
6. **Failure thinking** — what breaks and how do you recover?

Notice: **none** of the criteria say "memorized 50 patterns."

---

## A 30-Second Opening Template

> *"Great, so we're designing [X] for [N] users with [features]. Before I sketch, let me confirm a few things and make some quick estimates.*
>
> *Key features: A, B, C. Out of scope for now: D, E.*
>
> *Scale-wise, this looks like ~[QPS] read, [QPS] write, [TB] storage over a year. That tells me we'll need [pattern].*
>
> *I'll start with a high-level diagram, then dive deeper into whichever part you'd like."*

This single paragraph signals seniority instantly.

---

➡️ **Next:** [Common Mistakes](./02-common-mistakes.md)
