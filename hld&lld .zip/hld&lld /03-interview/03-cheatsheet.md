# Interview Chapter 3 — The One-Page Cheatsheet 🧾

> Print or open this 30 minutes before the interview.

---

## ⚡ Latency Numbers Every Engineer Should Know

```
L1 cache reference                   0.5 ns
Branch mispredict                      5 ns
L2 cache reference                     7 ns
Mutex lock/unlock                     25 ns
Main memory reference                100 ns
Compress 1KB w/ Snappy             3,000 ns =   3 µs
Send 1KB over 1 Gbps network      10,000 ns =  10 µs
SSD random read                  150,000 ns = 150 µs
Read 1MB sequentially from RAM   250,000 ns = 250 µs
Round trip in same datacenter    500,000 ns = 500 µs = 0.5 ms
Read 1MB sequentially from SSD 1,000,000 ns =   1 ms
Disk seek                     10,000,000 ns =  10 ms
Read 1MB sequentially from disk 20,000,000 ns =  20 ms
Send packet CA → Netherlands → CA          150 ms
```

> 🧠 Short version: **memory ≪ network ≪ disk ≪ cross-region**.

---

## 🔢 Quick Capacity Math

```
1 day            = 86,400 sec ≈ 10⁵ sec
1 month          ≈ 2.6 × 10⁶ sec
1 year           ≈ 3.15 × 10⁷ sec

1 KB × 1B records ≈ 1 TB
1 KB × 1M QPS    = 1 GB/sec write throughput

Peak QPS ≈ 3× average QPS
Read:Write ratio: web reads 10:1, social 100:1
```

---

## 🗄️ Storage Cheat-Picker

| Need | Pick |
|---|---|
| ACID, joins, schema | **Postgres / MySQL** |
| Huge writes, time-ordered | **Cassandra / DynamoDB** |
| Flexible JSON | **MongoDB** |
| Cache, sessions, leaderboards | **Redis** |
| Full-text search | **Elasticsearch** |
| Files / blobs / video | **S3 / GCS** |
| Graph / social / fraud | **Neo4j** |
| Analytics / OLAP | **ClickHouse / BigQuery / Snowflake** |
| Streaming events | **Kafka / Kinesis** |
| Time-series metrics | **Prometheus / InfluxDB** |

---

## 🛠️ Pattern Picker

### Creational
- **Singleton** — one instance (Logger, Config)
- **Factory Method** — pick subclass at runtime
- **Abstract Factory** — family of related products
- **Builder** — many optional params / immutable
- **Prototype** — clone existing

### Structural
- **Adapter** — bridge incompatible APIs
- **Decorator** — add behavior dynamically
- **Facade** — simplify subsystem
- **Proxy** — control access / lazy load
- **Composite** — tree of like things
- **Bridge** — split two changing dimensions
- **Flyweight** — share common state

### Behavioral
- **Strategy** — swappable algorithms
- **Observer** — pub/sub
- **State** — behavior per state
- **Command** — action as object (undo)
- **Chain of Responsibility** — pipeline of handlers
- **Template Method** — fixed steps + hooks
- **Iterator** — uniform traversal
- **Mediator** — decouple many-to-many comm
- **Memento** — save/restore state

---

## 🧱 SOLID

```
S — Single Responsibility    one reason to change
O — Open/Closed              extend, don't modify
L — Liskov Substitution      subclass keeps the contract
I — Interface Segregation    many small interfaces
D — Dependency Inversion     depend on abstractions
```

---

## 🌐 Distributed Systems

### CAP / PACELC
- During partition → C or A
- Else → L or C

### Consistency models (strongest → weakest)
linearizable → sequential → causal → read-your-writes → eventual

### Quorum
`W + R > N` ⇒ strong consistency.

### Common defaults
- `N=3, W=2, R=2` → balanced
- Cassandra: tunable per query
- DynamoDB: eventual by default; strong on demand

---

## 🚦 Load Balancing Algorithms
Round-Robin · Weighted · Least-Conn · Least-Response-Time · IP Hash · Consistent Hash

## 🧊 Caching
Strategies: cache-aside · read-through · write-through · write-behind · refresh-ahead
Pitfalls: stampede · penetration · avalanche · hot key
Eviction: LRU · LFU · FIFO · TTL

## 📨 Messaging
- At-most-once / **at-least-once** (default) / exactly-once (hard)
- Order: per partition only (use key)
- Patterns: outbox, saga, CQRS, event sourcing, DLQ

## 🚦 Rate Limiting
Fixed window · Sliding log · Sliding counter · **Token bucket** · Leaky bucket

---

## 🎯 The Universal Interview Opener

> *"Let me first clarify requirements, do quick scale estimates, then propose APIs and data model. From there I'll draw a high-level diagram and we can deep-dive wherever you want."*

---

## 🧠 Sharding Keys Crib

| System | Shard by |
|---|---|
| Twitter/Insta posts | user_id |
| Chat messages | chat_id |
| URL shortener | short_code (hash) |
| Uber trips | city_id |
| Notifications | user_id |
| Analytics | date / event_type |

---

## 📊 Monitoring Golden Signals (SRE)

1. **Latency** (p50, p95, p99)
2. **Traffic** (QPS)
3. **Errors** (rate, %)
4. **Saturation** (CPU/RAM/disk/queue depth)

---

## 🔄 Reliability patterns
Retry+jitter · Timeouts · Circuit breaker · Bulkhead · Graceful degradation · Idempotency · DLQ · Health checks · Chaos testing

---

## ⏱️ The 45-min Time Budget

```
0:00 – 0:05   Clarify
0:05 – 0:10   Estimate
0:10 – 0:15   APIs
0:15 – 0:20   Data model
0:20 – 0:30   High-level architecture
0:30 – 0:40   Deep-dive (interviewer's pick)
0:40 – 0:45   Scale, failure, summary
```

---

➡️ **Next:** [Practice Question Bank](./04-questions-bank.md)
