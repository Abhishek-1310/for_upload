# Interview Chapter 4 — 50+ Practice Question Bank 📚

> Practice 1 question per day for 6 weeks. Time yourself. Speak out loud.

---

## 🧱 LLD Questions

### Tier 1 — Foundations (do these first)
1. Design **Parking Lot** ✅ (Ch 7)
2. Design **Splitwise** ✅ (Ch 8)
3. Design **BookMyShow** ✅ (Ch 9)
4. Design **Elevator System** ✅ (Ch 10)
5. Design **Tic-Tac-Toe / Snake-Ladder** ✅ (Ch 11)
6. Design **Rate Limiter** ✅ (Ch 12)

### Tier 2 — Common asks
7. Design **Vending Machine** (state machine focus)
8. Design **ATM** (state, transaction, security)
9. Design **Cab Booking (LLD only)** — match-making logic
10. Design **Library Management System**
11. Design **Hotel Booking System**
12. Design **Airline Reservation**
13. Design **Online Food Ordering (Swiggy/Zomato)**
14. Design **Online Auction System**
15. Design **Stack Overflow** (questions, votes, rep)
16. Design **Trading System (LLD)** — orders, matching engine
17. Design **Cricket Scoring System**
18. Design **Logger** (multi-level, async, file rotation)
19. Design **Notification System (LLD)** — channels as Strategy
20. Design **In-memory Key-Value store** (with TTL)
21. Design **In-memory File System**
22. Design **Linux `find` / `grep` (LLD)**
23. Design **Music Player / Playlist**
24. Design **CricBuzz / Live Score**
25. Design **Movie Ticket Cancellation Policy** (Strategy)
26. Design **Cache** (LRU/LFU implementation)
27. Design **Excel / Spreadsheet** (cells, formula, dependencies)
28. Design **Document Editor (Google Docs LLD)**
29. Design **Chess** (board, pieces, move validator)

---

## 🏰 HLD Questions

### Tier 1 — Most common (master these)
30. Design **TinyURL / URL Shortener** ✅ (Ch 8)
31. Design **Twitter / Instagram Feed** ✅ (Ch 9)
32. Design **WhatsApp / Chat** ✅ (Ch 10)
33. Design **Uber / Ola** ✅ (Ch 11)
34. Design **Netflix / YouTube** ✅ (Ch 12)
35. Design **Notification System (HLD)** ✅ (Ch 13)

### Tier 2 — Frequently asked
36. Design **Dropbox / Google Drive** (file sync, chunking, versioning)
37. Design **Google Docs (collaborative editing)** — OT/CRDT
38. Design **Search Autocomplete / Typeahead**
39. Design **Web Crawler**
40. Design **Distributed Logging / Monitoring System**
41. Design **Distributed Cache** (consistent hashing focus)
42. Design **Distributed Message Queue** (like Kafka)
43. Design **Distributed File System** (HDFS-like)
44. Design **News Feed (general — Facebook)**
45. Design **Top-K / Trending** (Twitter trends, top-songs)
46. Design **Distributed Counter** (likes/views at scale)
47. Design **Distributed Rate Limiter**
48. Design **Distributed Job Scheduler** (cron at scale)
49. Design **Distributed Lock**
50. Design **Distributed Unique ID Generator** (Snowflake)
51. Design **Pastebin / Gist**
52. Design **Yelp / Nearby Places** (geo)
53. Design **Tinder / Bumble** (matching, swipes)
54. Design **Slack / Discord** (channels, presence, search)
55. Design **Zoom / Google Meet** (WebRTC, signaling, SFU)
56. Design **E-Commerce (Amazon)** — catalog, cart, order, inventory
57. Design **Payment System** (idempotency, ledger, reconciliation)
58. Design **Stock Exchange / Trading Platform**
59. Design **Ad-serving / Real-Time Bidding**
60. Design **Recommendation System (general)**
61. Design **Online Code Judge (Leetcode)** — sandboxed execution
62. Design **CDN**
63. Design **DNS**
64. Design **Multiplayer Online Game**

---

## 🎯 How to Practice

For each question:
1. **Set 45-min timer.**
2. Apply the 7-step framework (clarify → estimate → APIs → data → HLD → deep-dive → scale/fail).
3. Talk out loud (or whiteboard alone).
4. Compare your answer with reference solutions:
   - Alex Xu — *System Design Interview Volume 1 & 2*
   - **ByteByteGo** YouTube channel
   - **Gaurav Sen** YouTube channel
   - **Code Karle / Sudo Code** (Hindi+English)
   - **Donne Martin** github.com/donnemartin/system-design-primer
   - **Educative.io** Grokking System Design (paid)

---

## 🗓️ Suggested 6-Week Plan

**Week 1 — LLD foundations**
- Mon: OOP & SOLID review
- Tue: Creational patterns
- Wed: Structural patterns
- Thu: Behavioral patterns
- Fri-Sun: Parking Lot, Splitwise, BookMyShow

**Week 2 — LLD case studies**
- 1 case/day from Tier 2 list
- End of week: do a full mock LLD with a friend

**Week 3 — HLD foundations**
- Mon: Scaling story + Databases
- Tue: Caching + LB
- Wed: Queues + CAP
- Thu: Microservices
- Fri-Sun: TinyURL, Instagram

**Week 4 — HLD case studies (set 1)**
- Daily: WhatsApp / Uber / Netflix / Notification / Dropbox / Search / Web Crawler

**Week 5 — HLD case studies (set 2)**
- Top-K, Distributed cache, Yelp, Slack, Payment, E-com, Tinder, Zoom

**Week 6 — Mock interviews**
- Daily mock with peer / paid platform (interviewing.io, Pramp)
- Review recordings; iterate weak spots
- Re-read cheat sheet daily

---

## 🎤 Mock Interview Tips

- Record yourself (audio or screen) — listen back, note "ums" and silences
- Practice on a **physical whiteboard** if your interview is in-person
- Use **Excalidraw / draw.io** for virtual interviews
- Time-box ruthlessly
- After each mock, ask: *"What's the 1 thing I should improve?"*

---

## 🏁 Final Checklist Before Interview Day

- [ ] Re-read [`03-cheatsheet.md`](./03-cheatsheet.md)
- [ ] Re-skim Chapter 1 framework
- [ ] Look at your top-3 weak case studies
- [ ] Sleep well. Hydrate. Trust the prep.

---

## 💪 Final Words

You started not knowing what SOLID stood for.
You're now fluent in patterns, distributed systems, and trade-offs.

In the interview, you don't have to be the smartest person in the room. You just have to:

1. **Listen.**
2. **Think out loud.**
3. **Make trade-offs explicit.**
4. **Stay calm when challenged.**

You've put in the work. Walk in confident. **Go get the offer.** 🚀

---

🎉 **End of course.** Want to revisit anything? Start at the [README](../README.md).
