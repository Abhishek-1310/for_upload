// ============================================================
// App Configuration
// ============================================================

export const config = {
  // API Gateway endpoint (set after CDK deploy)
  apiUrl: import.meta.env.VITE_API_URL || 'https://your-api-id.execute-api.ap-south-1.amazonaws.com/prod',

  // Cognito configuration (set after CDK deploy)
  cognito: {
    userPoolId: import.meta.env.VITE_COGNITO_USER_POOL_ID || 'ap-south-1_XXXXXXXXX',
    clientId: import.meta.env.VITE_COGNITO_CLIENT_ID || 'your-client-id',
    region: import.meta.env.VITE_AWS_REGION || 'ap-south-1',
  },
};
