# 🎲 How to Play — Party Game Hub

## Getting Started

1. Open `http://localhost:5173` in your browser
2. Enter your **name** and optionally a **room code**
   - Leave room code blank → **creates a new room**
   - Enter an existing code → **joins that room**
3. Share the room code with friends (click the 📋 copy button)
4. Wait for 2–5 players to join
5. The **host** (first player, shown with 👑) picks a game to start

---

## 🎨 Game A: Pictionary

> One player draws, everyone else guesses the word!

### Roles
- **Drawer** — Sees the secret word and draws it on the canvas
- **Guessers** — Everyone else tries to guess by typing in the chat

### How to Play

1. **Host clicks "Start Round"** to begin
2. The **drawer** is chosen automatically (rotates each round)
3. The drawer sees the secret word (e.g., "elephant") and draws it on the canvas
4. Guessers see the word as blanks (e.g., `_ _ _ _ _ _ _ _`) and type guesses in the chat
5. **First correct guess** ends the round:
   - Guesser gets **+10 points**
   - Drawer gets **+5 points**
6. If nobody guesses before the **60-second timer** runs out, the round ends
7. Game continues for multiple rounds (each player gets a turn to draw)

### Drawing Tools (Drawer Only)
| Tool | Description |
|------|-------------|
| 🎨 **Color Palette** | 9 colors — black, red, orange, yellow, green, blue, purple, pink, white |
| 📏 **Brush Sizes** | 4 sizes — thin to thick |
| 🧹 **Clear** | Wipes the entire canvas |

### Tips
- Guessers: Watch the number of blanks to know the word length
- Drawer: Start with simple shapes, add details if nobody guesses
- Wrong guesses are visible to everyone in the chat

---

## 🔍 Game B: Wink Murder

> A secret murderer is eliminating players. Can the detective figure out who it is?

### Roles (Assigned Secretly)
| Role | Count | Goal |
|------|-------|------|
| 🔪 **Murderer** | 1 | Eliminate all civilians without getting caught |
| 🕵️ **Detective** | 1 | Identify the murderer before everyone is eliminated |
| 🧑 **Civilians** | 1–3 | Stay alive and help the detective |

### How to Play

1. **Host clicks "Assign Roles & Start"**
2. Each player sees **only their own role** (roles are hidden from others)
3. The game plays out in real-time:

#### If You're the Murderer 🔪
- Click on a player's avatar to **secretly eliminate them**
- You **cannot** eliminate the detective
- Try to eliminate all civilians before the detective catches you
- A red "Kill" badge appears on valid targets

#### If You're the Detective 🕵️
- Watch for players getting eliminated
- Click **"Call Meeting to Accuse"** when you're ready to make a guess
- Select a player and click **"Accuse"** to name them as the murderer
- You have **2 guesses** total — use them wisely!

#### If You're a Civilian 🧑
- You can't take any direct actions
- Watch what's happening and try to help the detective figure out the murderer
- If you get eliminated, you spectate for the rest of the game

### Win Conditions
| Winner | Condition |
|--------|-----------|
| 🕵️ **Detective wins** | Correctly accuses the murderer |
| 🔪 **Murderer wins** | All civilians eliminated, OR detective uses both guesses incorrectly |

### Tips
- Murderer: Space out your kills so it's not obvious
- Detective: Pay attention to which players are being eliminated — there might be a pattern
- Civilians: Communicate with your detective!

---

## 🃏 Game C: Bluff & Bust (Cheat)

> Play cards face-down, claim a rank, and challenge bluffs! First to empty their hand wins.

### Setup
- A standard 52-card deck is dealt evenly among all players
- Turn order follows the player list

### How to Play

1. **Host clicks "Deal Cards & Start"**
2. On **your turn:**
   - Select 1 or more cards from your hand (click to select, click again to deselect)
   - Choose a **claimed rank** from the dropdown (A, 2, 3, ... K)
   - Click **"Play X card(s) as [Rank]"**
   - Cards go face-down into the central pile
   - **You can lie about the rank!** 🤫
3. After someone plays, **any other player** can click the **"BLUFF!"** button to challenge

### Bluff Challenge Results

| Situation | Result |
|-----------|--------|
| Player **was bluffing** (cards don't match claimed rank) | Bluffer picks up the entire pile 😬 |
| Player **was honest** (all cards match claimed rank) | Challenger picks up the entire pile 😅 |

### Win Condition
🏆 **First player to empty their hand wins!**

### Card Display
- Your own cards are shown face-up with rank and suit
- Other players' card counts are visible, but not their cards
- The pile shows the total card count and the last claimed play

### Strategy Tips
- **Bluff sparingly** — if caught, you pick up the whole pile
- **Bluff boldly** — playing more cards at once empties your hand faster
- **Call bluffs wisely** — if you're wrong, YOU get the pile
- **Watch card counts** — if someone claims 3 Aces but you already have 2, they're likely bluffing!
- **Mix truth and lies** — play some real cards of the claimed rank mixed with fakes

---

## General Tips

- **Minimum 2 players** to start any game (Wink Murder needs 3+)
- **Maximum 5 players** per room
- Only the **host** (👑) can start games and return to lobby
- Room codes are shareable — friends can join from any browser on the same network
- The game runs entirely in real-time via WebSockets — no page refreshes needed!
