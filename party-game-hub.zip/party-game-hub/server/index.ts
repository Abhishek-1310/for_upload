import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import cors from 'cors';
import { v4 as uuidv4 } from 'uuid';

const app = express();
app.use(cors());

const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: { origin: '*', methods: ['GET', 'POST'] },
});

// ─── Types ────────────────────────────────────────────
interface Player {
  id: string;
  name: string;
  avatar: string;
  isHost: boolean;
  isConnected: boolean;
}

interface Room {
  roomId: string;
  players: Player[];
  gameStatus: 'lobby' | 'playing' | 'results';
  activeGame: string | null;
  hostId: string;
  gameState: unknown;
}

// ─── State ────────────────────────────────────────────
const rooms = new Map<string, Room>();
const socketToRoom = new Map<string, string>();
const socketToPlayer = new Map<string, string>();

const PICTIONARY_WORDS = [
  'elephant', 'pizza', 'airplane', 'guitar', 'sunshine', 'castle', 'dragon',
  'butterfly', 'basketball', 'snowman', 'volcano', 'robot', 'pirate', 'rainbow',
  'hamburger', 'penguin', 'bicycle', 'lighthouse', 'umbrella', 'telescope',
  'dinosaur', 'waterfall', 'spaceship', 'treasure', 'mermaid', 'tornado',
  'fireworks', 'mountain', 'octopus', 'parachute',
];

function broadcastRoom(roomId: string) {
  const room = rooms.get(roomId);
  if (!room) return;
  io.to(roomId).emit('room-state', {
    roomId: room.roomId,
    players: room.players,
    gameStatus: room.gameStatus,
    activeGame: room.activeGame,
    hostId: room.hostId,
  });
}

function broadcastGameState(roomId: string) {
  const room = rooms.get(roomId);
  if (!room || !room.gameState) return;

  // For bluff: send each player their own hand only
  if (room.activeGame === 'bluff-and-bust') {
    const state = room.gameState as BluffState;
    for (const p of room.players) {
      const personalState = {
        ...state,
        hands: Object.fromEntries(
          Object.entries(state.hands).map(([pid, hand]) => [
            pid,
            pid === p.id ? hand : hand.map(() => ({ id: '?', suit: 'spades', rank: '?' })),
          ])
        ),
      };
      io.to(p.id).emit('sync-state', personalState);
    }
    return;
  }

  // For wink murder: hide roles from non-self players
  if (room.activeGame === 'wink-murder') {
    const state = room.gameState as WinkState;
    for (const p of room.players) {
      const personalState = {
        ...state,
        roles: Object.fromEntries(
          Object.entries(state.roles).map(([pid, role]) => [
            pid,
            pid === p.id ? role : 'hidden',
          ])
        ),
        murdererId: p.id === state.murdererId ? state.murdererId : '',
      };
      io.to(p.id).emit('sync-state', personalState);
    }
    return;
  }

  // For pictionary: hide word from guessers
  if (room.activeGame === 'pictionary') {
    const state = room.gameState as PictionaryServerState;
    for (const p of room.players) {
      io.to(p.id).emit('sync-state', {
        ...state,
        word: p.id === state.drawerId ? state.word : '',
      });
    }
    return;
  }

  io.to(roomId).emit('sync-state', room.gameState);
}

// ─── Pictionary State ─────────────────────────────────
interface PictionaryServerState {
  drawerId: string;
  word: string;
  maskedWord: string;
  guesses: { playerId: string; playerName: string; message: string; isCorrect: boolean; timestamp: number }[];
  roundTime: number;
  timeLeft: number;
  scores: Record<string, number>;
  round: number;
  totalRounds: number;
  canvas: unknown[];
  isRoundActive: boolean;
}

const pictionaryTimers = new Map<string, ReturnType<typeof setInterval>>();

function startPictionaryRound(roomId: string) {
  const room = rooms.get(roomId);
  if (!room) return;
  const state = room.gameState as PictionaryServerState;

  const word = PICTIONARY_WORDS[Math.floor(Math.random() * PICTIONARY_WORDS.length)];
  const drawerIdx = (state.round - 1) % room.players.length;

  state.drawerId = room.players[drawerIdx].id;
  state.word = word;
  state.maskedWord = word.split('').map(c => c === ' ' ? '  ' : '_').join(' ');
  state.guesses = [];
  state.timeLeft = state.roundTime;
  state.isRoundActive = true;
  state.canvas = [];

  broadcastGameState(roomId);

  // Timer
  const timer = setInterval(() => {
    state.timeLeft--;
    if (state.timeLeft <= 0) {
      clearInterval(timer);
      pictionaryTimers.delete(roomId);
      state.isRoundActive = false;
      state.round++;
      if (state.round > state.totalRounds) {
        room.gameStatus = 'results';
        broadcastRoom(roomId);
      }
      broadcastGameState(roomId);
    } else if (state.timeLeft % 5 === 0) {
      broadcastGameState(roomId);
    }
  }, 1000);
  pictionaryTimers.set(roomId, timer);
}

// ─── Wink Murder State ────────────────────────────────
interface WinkState {
  roles: Record<string, string>;
  alivePlayerIds: string[];
  deadPlayerIds: string[];
  detectiveId: string;
  murdererId: string;
  meetingCalled: boolean;
  accusation: string | null;
  gameOver: boolean;
  winner: string | null;
  detectiveGuessesLeft: number;
}

// ─── Bluff State ──────────────────────────────────────
interface BluffCard {
  id: string;
  suit: string;
  rank: string;
}

interface BluffState {
  hands: Record<string, BluffCard[]>;
  pile: BluffCard[];
  currentPlayerIndex: number;
  turnOrder: string[];
  currentClaimedRank: string | null;
  lastMove: { playerId: string; claimedRank: string; actualCards: BluffCard[]; cardCount: number } | null;
  bluffCalled: boolean;
  bluffCallerId: string | null;
  bluffResult: string | null;
  gameOver: boolean;
  winnerId: string | null;
  message: string;
}

function createDeck(): BluffCard[] {
  const suits = ['hearts', 'diamonds', 'clubs', 'spades'];
  const ranks = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
  const deck: BluffCard[] = [];
  for (const suit of suits) {
    for (const rank of ranks) {
      deck.push({ id: uuidv4(), suit, rank });
    }
  }
  // Shuffle
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return deck;
}

// ─── Socket Handlers ──────────────────────────────────
io.on('connection', (socket) => {
  console.log(`⚡ Connected: ${socket.id}`);

  socket.on('join-room', ({ roomId, playerName }) => {
    let room = rooms.get(roomId);

    if (!room) {
      room = {
        roomId,
        players: [],
        gameStatus: 'lobby',
        activeGame: null,
        hostId: socket.id,
        gameState: null,
      };
      rooms.set(roomId, room);
    }

    if (room.players.length >= 5) {
      socket.emit('error', 'Room is full (max 5 players)');
      return;
    }

    if (room.gameStatus !== 'lobby') {
      socket.emit('error', 'Game already in progress');
      return;
    }

    const player: Player = {
      id: socket.id,
      name: playerName,
      avatar: '',
      isHost: room.players.length === 0,
      isConnected: true,
    };

    room.players.push(player);
    if (room.players.length === 1) room.hostId = socket.id;

    socketToRoom.set(socket.id, roomId);
    socketToPlayer.set(socket.id, player.id);
    socket.join(roomId);

    broadcastRoom(roomId);
    console.log(`👤 ${playerName} joined room ${roomId} (${room.players.length} players)`);
  });

  socket.on('start-game', ({ roomId, gameType }) => {
    const room = rooms.get(roomId);
    if (!room) return;
    if (socket.id !== room.hostId) return;
    if (room.players.length < 2) return;

    room.gameStatus = 'playing';
    room.activeGame = gameType;

    if (gameType === 'pictionary') {
      room.gameState = {
        drawerId: room.players[0].id,
        word: '',
        maskedWord: '_ _ _ _ _',
        guesses: [],
        roundTime: 60,
        timeLeft: 60,
        scores: Object.fromEntries(room.players.map(p => [p.id, 0])),
        round: 1,
        totalRounds: Math.min(room.players.length, 3),
        canvas: [],
        isRoundActive: false,
      } as PictionaryServerState;
    } else if (gameType === 'wink-murder') {
      room.gameState = {
        roles: {},
        alivePlayerIds: room.players.map(p => p.id),
        deadPlayerIds: [],
        detectiveId: '',
        murdererId: '',
        meetingCalled: false,
        accusation: null,
        gameOver: false,
        winner: null,
        detectiveGuessesLeft: 2,
      } as WinkState;
    } else if (gameType === 'bluff-and-bust') {
      room.gameState = {
        hands: {},
        pile: [],
        currentPlayerIndex: 0,
        turnOrder: [],
        currentClaimedRank: null,
        lastMove: null,
        bluffCalled: false,
        bluffCallerId: null,
        bluffResult: null,
        gameOver: false,
        winnerId: null,
        message: 'Waiting to deal cards…',
      } as BluffState;
    }

    broadcastRoom(roomId);
    broadcastGameState(roomId);
  });

  socket.on('game-action', (action) => {
    const room = rooms.get(action.roomId);
    if (!room) return;

    // ── Back to Lobby ──
    if (action.type === 'back-to-lobby') {
      const timer = pictionaryTimers.get(action.roomId);
      if (timer) { clearInterval(timer); pictionaryTimers.delete(action.roomId); }
      room.gameStatus = 'lobby';
      room.activeGame = null;
      room.gameState = null;
      broadcastRoom(action.roomId);
      return;
    }

    // ── Pictionary Actions ──
    if (action.type === 'pictionary-draw' || action.type === 'pictionary-clear') {
      // Broadcast draw events to all other players
      socket.to(action.roomId).emit('game-action', action);
      return;
    }

    if (action.type === 'pictionary-start-round') {
      startPictionaryRound(action.roomId);
      return;
    }

    if (action.type === 'pictionary-guess') {
      const state = room.gameState as PictionaryServerState;
      if (!state || !state.isRoundActive) return;
      const payload = action.payload as { message: string };
      const player = room.players.find(p => p.id === action.playerId);
      if (!player) return;

      const isCorrect = payload.message.toLowerCase().trim() === state.word.toLowerCase().trim();
      state.guesses.push({
        playerId: action.playerId,
        playerName: player.name,
        message: payload.message,
        isCorrect,
        timestamp: Date.now(),
      });

      if (isCorrect) {
        state.scores[action.playerId] = (state.scores[action.playerId] || 0) + 10;
        state.scores[state.drawerId] = (state.scores[state.drawerId] || 0) + 5;
        // End round
        const timer = pictionaryTimers.get(action.roomId);
        if (timer) { clearInterval(timer); pictionaryTimers.delete(action.roomId); }
        state.isRoundActive = false;
        state.round++;
        if (state.round > state.totalRounds) {
          room.gameStatus = 'results';
          broadcastRoom(action.roomId);
        }
      }
      broadcastGameState(action.roomId);
      return;
    }

    // ── Wink Murder Actions ──
    if (action.type === 'wink-start') {
      const state = room.gameState as WinkState;
      const playerIds = room.players.map(p => p.id);
      const shuffled = [...playerIds].sort(() => Math.random() - 0.5);

      state.murdererId = shuffled[0];
      state.detectiveId = shuffled[1];
      state.roles = {};
      for (const pid of playerIds) {
        if (pid === state.murdererId) state.roles[pid] = 'murderer';
        else if (pid === state.detectiveId) state.roles[pid] = 'detective';
        else state.roles[pid] = 'civilian';
      }
      state.alivePlayerIds = [...playerIds];
      state.deadPlayerIds = [];
      state.gameOver = false;
      state.winner = null;
      state.detectiveGuessesLeft = 2;
      state.meetingCalled = false;

      broadcastGameState(action.roomId);
      return;
    }

    if (action.type === 'wink-kill') {
      const state = room.gameState as WinkState;
      if (action.playerId !== state.murdererId) return;
      const { targetId } = action.payload as { targetId: string };
      if (state.deadPlayerIds.includes(targetId)) return;
      if (targetId === state.detectiveId) return;

      state.alivePlayerIds = state.alivePlayerIds.filter(id => id !== targetId);
      state.deadPlayerIds.push(targetId);

      // Broadcast kill animation
      io.to(action.roomId).emit('game-action', {
        type: 'wink-kill-anim',
        roomId: action.roomId,
        playerId: action.playerId,
        payload: { targetId },
      });

      // Check win condition: if all civilians are dead
      const aliveCivilians = state.alivePlayerIds.filter(
        id => id !== state.murdererId && id !== state.detectiveId
      );
      if (aliveCivilians.length === 0) {
        state.gameOver = true;
        state.winner = 'murderer';
      }

      broadcastGameState(action.roomId);
      return;
    }

    if (action.type === 'wink-call-meeting') {
      const state = room.gameState as WinkState;
      if (action.playerId !== state.detectiveId) return;
      state.meetingCalled = true;
      broadcastGameState(action.roomId);
      return;
    }

    if (action.type === 'wink-accuse') {
      const state = room.gameState as WinkState;
      if (action.playerId !== state.detectiveId) return;
      const { accusedId } = action.payload as { accusedId: string };

      state.detectiveGuessesLeft--;
      if (accusedId === state.murdererId) {
        state.gameOver = true;
        state.winner = 'detective';
      } else if (state.detectiveGuessesLeft <= 0) {
        state.gameOver = true;
        state.winner = 'murderer';
      }
      state.meetingCalled = false;
      state.accusation = accusedId;

      broadcastGameState(action.roomId);
      return;
    }

    // ── Bluff & Bust Actions ──
    if (action.type === 'bluff-start') {
      const state = room.gameState as BluffState;
      const deck = createDeck();
      const playerIds = room.players.map(p => p.id);
      state.turnOrder = [...playerIds];
      state.hands = {};
      for (const pid of playerIds) state.hands[pid] = [];

      let i = 0;
      for (const card of deck) {
        state.hands[state.turnOrder[i % playerIds.length]].push(card);
        i++;
      }

      state.currentPlayerIndex = 0;
      state.pile = [];
      state.lastMove = null;
      state.bluffResult = null;
      state.gameOver = false;
      state.message = `${room.players.find(p => p.id === state.turnOrder[0])?.name}'s turn`;

      broadcastGameState(action.roomId);
      return;
    }

    if (action.type === 'bluff-play') {
      const state = room.gameState as BluffState;
      if (state.turnOrder[state.currentPlayerIndex] !== action.playerId) return;

      const { cardIds, claimedRank } = action.payload as { cardIds: string[]; claimedRank: string };
      const hand = state.hands[action.playerId];
      const playedCards = hand.filter(c => cardIds.includes(c.id));
      state.hands[action.playerId] = hand.filter(c => !cardIds.includes(c.id));

      state.pile.push(...playedCards);
      state.lastMove = {
        playerId: action.playerId,
        claimedRank,
        actualCards: playedCards,
        cardCount: playedCards.length,
      };
      state.currentClaimedRank = claimedRank;
      state.bluffResult = null;

      const playerName = room.players.find(p => p.id === action.playerId)?.name;
      state.message = `${playerName} played ${playedCards.length} card(s) claiming ${claimedRank}`;

      // Check win
      if (state.hands[action.playerId].length === 0) {
        state.gameOver = true;
        state.winnerId = action.playerId;
        state.message = `${playerName} wins! 🏆`;
        broadcastGameState(action.roomId);
        return;
      }

      // Next turn
      state.currentPlayerIndex = (state.currentPlayerIndex + 1) % state.turnOrder.length;
      const nextPlayer = room.players.find(p => p.id === state.turnOrder[state.currentPlayerIndex]);
      state.message += ` • ${nextPlayer?.name}'s turn`;

      broadcastGameState(action.roomId);
      return;
    }

    if (action.type === 'bluff-call') {
      const state = room.gameState as BluffState;
      if (!state.lastMove) return;

      const lastMove = state.lastMove;
      const wasBluff = lastMove.actualCards.some(c => c.rank !== lastMove.claimedRank);
      const callerName = room.players.find(p => p.id === action.playerId)?.name;
      const blufferName = room.players.find(p => p.id === lastMove.playerId)?.name;

      state.bluffCalled = true;
      state.bluffCallerId = action.playerId;

      if (wasBluff) {
        // Bluffer picks up pile
        state.bluffResult = 'bluff';
        state.hands[lastMove.playerId].push(...state.pile);
        state.pile = [];
        state.message = `${callerName} caught ${blufferName} bluffing! ${blufferName} picks up the pile!`;
      } else {
        // Caller picks up pile
        state.bluffResult = 'honest';
        state.hands[action.playerId].push(...state.pile);
        state.pile = [];
        state.message = `${blufferName} was honest! ${callerName} picks up the pile!`;
      }

      state.lastMove = null;
      state.bluffCalled = false;

      broadcastGameState(action.roomId);
      return;
    }
  });

  socket.on('disconnect', () => {
    const roomId = socketToRoom.get(socket.id);
    if (roomId) {
      const room = rooms.get(roomId);
      if (room) {
        room.players = room.players.filter(p => p.id !== socket.id);
        if (room.players.length === 0) {
          rooms.delete(roomId);
          const timer = pictionaryTimers.get(roomId);
          if (timer) { clearInterval(timer); pictionaryTimers.delete(roomId); }
        } else {
          if (room.hostId === socket.id) {
            room.hostId = room.players[0].id;
            room.players[0].isHost = true;
          }
          broadcastRoom(roomId);
        }
      }
      socketToRoom.delete(socket.id);
      socketToPlayer.delete(socket.id);
    }
    console.log(`❌ Disconnected: ${socket.id}`);
  });
});

const PORT = process.env.PORT || 3001;
httpServer.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
