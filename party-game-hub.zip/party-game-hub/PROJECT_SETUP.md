# 🎮 Party Game Hub — Project Setup & Architecture

## How This Project Was Created

### Tech Stack
- **Frontend:** React 19 + TypeScript + Vite 7
- **Styling:** Tailwind CSS (via `@tailwindcss/vite` plugin)
- **Icons:** Lucide-React
- **Real-time:** Socket.io (client + server)
- **Backend:** Express + Socket.io on Node.js
- **Dev Tools:** tsx (TypeScript execution), concurrently (parallel scripts)

### Step-by-Step Build Process

#### Step 1 — Scaffold & Dependencies
Started from a Vite + React + TypeScript template, then installed:
```bash
npm install socket.io-client lucide-react tailwindcss @tailwindcss/vite
npm install -D socket.io express @types/express cors @types/cors uuid @types/uuid tsx concurrently
```

#### Step 2 — TypeScript Types (`src/types/index.ts`)
Defined all shared types:
- `Player` — id, name, avatar, isHost, isConnected
- `RoomState` — roomId, players[], gameStatus (lobby/playing/results), activeGame
- `PictionaryState` — drawerId, word, maskedWord, guesses, scores, canvas, timer
- `WinkMurderState` — roles, alivePlayerIds, deadPlayerIds, detectiveId, murdererId
- `BluffAndBustState` — hands, pile, turnOrder, lastMove, bluffResult
- `Card` — id, suit, rank
- Socket event interfaces for type-safe communication

#### Step 3 — Socket Hook (`src/hooks/useSocket.ts`)
Created `useSocket()` hook that:
- Connects to the backend via Socket.io
- Exposes: `joinRoom()`, `startGame()`, `sendAction()`
- Provides event listeners: `onRoomState()`, `onSyncState()`, `onGameAction()`, `onError()`

#### Step 4 — Room Context (`src/contexts/RoomContext.tsx`)
Built `RoomProvider` + `useRoom()` hook providing:
- Shared room state across all components
- Current player identity (`myId`, `myPlayer`)
- Actions: `joinRoom`, `startGame`, `sendAction`, `backToLobby`

#### Step 5 — Lobby UI (`src/components/Lobby.tsx`)
Two screens in one component:
- **Join Screen** — Enter name + room code (or create new room)
- **Lobby Screen** — Player grid (5 slots), room code with copy button, game selector (host-only)

#### Step 6 — Game Container (`src/components/GameContainer.tsx`)
Central router that switches views based on `room.gameStatus` and `room.activeGame`:
- `lobby` → Lobby component
- `playing` → Pictionary / WinkMurder / BluffAndBust
- `results` → Results component

#### Step 7 — Three Game Components
- `src/components/games/Pictionary.tsx` — Canvas drawing, brush tools, chat guessing
- `src/components/games/WinkMurder.tsx` — Role-based gameplay, kill/accuse mechanics
- `src/components/games/BluffAndBust.tsx` — Card hands, pile, bluff challenge

#### Step 8 — Backend Server (`server/index.ts`)
Express + Socket.io server handling:
- Room creation/joining (max 5 players)
- Game initialization with proper state for each game type
- All game logic (turns, scoring, role assignment, card dealing)
- Secure state broadcasting (hides secret info per player)

#### Step 9 — Styling & Config
- Tailwind CSS via Vite plugin (`vite.config.ts`)
- Glassmorphism UI with purple/violet gradients
- Responsive layout for all screen sizes

---

## Project Structure

```
party-game-hub/
├── server/
│   ├── index.ts              # Socket.io + Express backend
│   └── tsconfig.json         # Server TypeScript config
├── src/
│   ├── main.tsx              # React entry point
│   ├── App.tsx               # Root component (wraps RoomProvider)
│   ├── index.css             # Tailwind import + global styles
│   ├── types/
│   │   └── index.ts          # All TypeScript interfaces
│   ├── hooks/
│   │   └── useSocket.ts      # Socket.io connection hook
│   ├── contexts/
│   │   └── RoomContext.tsx    # Room state provider
│   └── components/
│       ├── GameContainer.tsx  # Game view router
│       ├── Lobby.tsx          # Join/lobby screens
│       ├── Results.tsx        # Game over screen
│       └── games/
│           ├── Pictionary.tsx
│           ├── WinkMurder.tsx
│           └── BluffAndBust.tsx
├── package.json
├── vite.config.ts
├── tsconfig.json
└── index.html
```

---

## How to Run

### Prerequisites
- Node.js 18+ installed
- npm installed

### Install Dependencies
```bash
npm install
```

### Run Both Server & Frontend Together
```bash
npm run dev:all
```
This starts:
- **Backend** on `http://localhost:3001`
- **Frontend** on `http://localhost:5173`

### Run Separately
```bash
# Terminal 1 — Backend server
npm run server

# Terminal 2 — Frontend dev server
npm run dev
```

### Build for Production
```bash
npm run build
```

### Available Scripts
| Script | Command | Description |
|--------|---------|-------------|
| `dev` | `vite` | Start frontend dev server |
| `server` | `npx tsx server/index.ts` | Start backend server |
| `dev:all` | `concurrently "npm run server" "npm run dev"` | Start both together |
| `build` | `tsc -b && vite build` | Production build |
| `preview` | `vite preview` | Preview production build |

---

## Socket.io Events

| Event | Direction | Description |
|-------|-----------|-------------|
| `join-room` | Client → Server | Join/create a room |
| `start-game` | Client → Server | Host starts a game |
| `game-action` | Client ↔ Server | In-game actions (draw, guess, kill, play cards, etc.) |
| `room-state` | Server → Client | Full room state update |
| `sync-state` | Server → Client | Game-specific state (personalized per player) |
| `error` | Server → Client | Error messages |
