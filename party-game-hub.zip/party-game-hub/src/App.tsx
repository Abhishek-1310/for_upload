import { RoomProvider } from './contexts/RoomContext';
import GameContainer from './components/GameContainer';

function App() {
  return (
    <RoomProvider>
      <GameContainer />
    </RoomProvider>
  );
}

export default App;
