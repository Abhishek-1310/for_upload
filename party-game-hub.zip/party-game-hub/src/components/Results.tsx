import { useRoom } from '../contexts/RoomContext';
import { Trophy, ArrowLeft } from 'lucide-react';

export default function Results() {
  const { room, backToLobby, myPlayer } = useRoom();
  if (!room) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-950 via-purple-900 to-indigo-950 flex items-center justify-center p-4">
      <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl p-8 w-full max-w-md text-center shadow-2xl">
        <Trophy className="w-16 h-16 text-yellow-400 mx-auto mb-4" />
        <h2 className="text-3xl font-black text-white mb-2">Game Over!</h2>
        <p className="text-purple-200 mb-6">Great game everyone! 🎉</p>

        <div className="space-y-3 mb-8">
          {room.players.map((p, i) => (
            <div key={p.id} className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/10">
              <span className="text-2xl">{['🥇', '🥈', '🥉', '4️⃣', '5️⃣'][i]}</span>
              <span className="text-white font-medium">{p.name}</span>
            </div>
          ))}
        </div>

        {myPlayer?.isHost && (
          <button
            onClick={backToLobby}
            className="flex items-center gap-2 mx-auto px-6 py-3 rounded-xl bg-gradient-to-r from-purple-500 to-pink-500 text-white font-bold hover:from-purple-600 hover:to-pink-600 transition-all"
          >
            <ArrowLeft className="w-5 h-5" /> Back to Lobby
          </button>
        )}
      </div>
    </div>
  );
}
