import { useEffect, useState } from 'react';
import { useRoom } from '../../contexts/RoomContext';
import type { WinkMurderState, WinkRole } from '../../types';
import { Eye, Skull, Users, ArrowLeft, AlertTriangle, ShieldCheck } from 'lucide-react';

const AVATARS = ['🦊', '🐱', '🐶', '🦁', '🐸'];

const DEFAULT_STATE: WinkMurderState = {
  roles: {},
  alivePlayerIds: [],
  deadPlayerIds: [],
  detectiveId: '',
  murdererId: '',
  meetingCalled: false,
  accusation: null,
  gameOver: false,
  winner: null,
  detectiveGuessesLeft: 2,
};

export default function WinkMurder() {
  const { room, myId, sendAction, onSyncState, onGameAction, backToLobby, myPlayer } = useRoom();
  const [gameState, setGameState] = useState<WinkMurderState>(DEFAULT_STATE);
  const [selectedPlayer, setSelectedPlayer] = useState<string | null>(null);
  const [showKillAnim, setShowKillAnim] = useState<string | null>(null);
  const [message, setMessage] = useState('');

  const myRole: WinkRole = gameState.roles[myId] || 'civilian';
  const amAlive = gameState.alivePlayerIds.includes(myId);
  const amDetective = myId === gameState.detectiveId;
  const amMurderer = myId === gameState.murdererId;

  useEffect(() => {
    const unsub = onSyncState((state) => {
      setGameState(state as WinkMurderState);
    });
    return unsub;
  }, [onSyncState]);

  useEffect(() => {
    const unsub = onGameAction((action) => {
      if (action.type === 'wink-kill-anim') {
        const targetId = (action.payload as { targetId: string }).targetId;
        setShowKillAnim(targetId);
        setTimeout(() => setShowKillAnim(null), 2000);
      }
    });
    return unsub;
  }, [onGameAction]);

  const handleKill = (targetId: string) => {
    if (!room || !amMurderer || targetId === myId || targetId === gameState.detectiveId) return;
    if (gameState.deadPlayerIds.includes(targetId)) return;
    sendAction({
      type: 'wink-kill',
      roomId: room.roomId,
      playerId: myId,
      payload: { targetId },
    });
  };

  const handleCallMeeting = () => {
    if (!room || !amDetective) return;
    sendAction({
      type: 'wink-call-meeting',
      roomId: room.roomId,
      playerId: myId,
      payload: null,
    });
  };

  const handleAccuse = () => {
    if (!room || !amDetective || !selectedPlayer) return;
    sendAction({
      type: 'wink-accuse',
      roomId: room.roomId,
      playerId: myId,
      payload: { accusedId: selectedPlayer },
    });
    setSelectedPlayer(null);
  };

  const handleStartGame = () => {
    if (!room) return;
    sendAction({ type: 'wink-start', roomId: room.roomId, playerId: myId, payload: null });
  };

  const getRoleBadge = () => {
    switch (myRole) {
      case 'murderer': return <span className="bg-red-500/20 text-red-300 px-3 py-1 rounded-lg text-sm font-bold flex items-center gap-1"><Skull className="w-4 h-4" /> Murderer</span>;
      case 'detective': return <span className="bg-blue-500/20 text-blue-300 px-3 py-1 rounded-lg text-sm font-bold flex items-center gap-1"><Eye className="w-4 h-4" /> Detective</span>;
      default: return <span className="bg-green-500/20 text-green-300 px-3 py-1 rounded-lg text-sm font-bold flex items-center gap-1"><ShieldCheck className="w-4 h-4" /> Civilian</span>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-gray-900 to-slate-950 p-4">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <button onClick={backToLobby} className="flex items-center gap-1 text-gray-400 hover:text-white transition text-sm">
            <ArrowLeft className="w-4 h-4" /> Lobby
          </button>
          <h2 className="text-2xl font-black text-white flex items-center gap-2">
            <Eye className="w-6 h-6 text-red-400" /> Wink Murder
          </h2>
          <div>{getRoleBadge()}</div>
        </div>

        {/* Game Over */}
        {gameState.gameOver && (
          <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-8 text-center mb-6">
            <div className="text-5xl mb-4">{gameState.winner === 'detective' ? '🕵️' : '💀'}</div>
            <h3 className="text-3xl font-black text-white mb-2">
              {gameState.winner === 'detective' ? 'Detective Wins!' : 'Murderer Wins!'}
            </h3>
            <p className="text-gray-300 mb-4">
              The murderer was: {room?.players.find(p => p.id === gameState.murdererId)?.name}
            </p>
            {myPlayer?.isHost && (
              <button onClick={backToLobby} className="px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white font-bold rounded-xl hover:from-purple-600 hover:to-pink-600 transition">
                Back to Lobby
              </button>
            )}
          </div>
        )}

        {/* Pre-game */}
        {Object.keys(gameState.roles).length === 0 && !gameState.gameOver && (
          <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-8 text-center mb-6">
            <div className="text-5xl mb-4">🔍</div>
            <h3 className="text-xl text-white font-bold mb-2">Ready to play?</h3>
            <p className="text-gray-400 mb-4">Roles will be assigned secretly. The murderer kills by clicking. The detective investigates.</p>
            {myPlayer?.isHost && room && room.players.length >= 3 && (
              <button onClick={handleStartGame} className="px-6 py-3 bg-gradient-to-r from-red-500 to-pink-500 text-white font-bold rounded-xl hover:from-red-600 hover:to-pink-600 transition">
                Assign Roles & Start
              </button>
            )}
            {myPlayer?.isHost && room && room.players.length < 3 && (
              <p className="text-yellow-300 text-sm mt-2">Need at least 3 players</p>
            )}
          </div>
        )}

        {/* Player Grid */}
        {Object.keys(gameState.roles).length > 0 && !gameState.gameOver && (
          <>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4 mb-6">
              {room?.players.map((p, i) => {
                const isDead = gameState.deadPlayerIds.includes(p.id);
                const isKilling = showKillAnim === p.id;
                const isMe = p.id === myId;
                const canKill = amMurderer && !isDead && !isMe && p.id !== gameState.detectiveId;
                const canSelect = amDetective && gameState.meetingCalled && !isMe;

                return (
                  <button
                    key={p.id}
                    onClick={() => {
                      if (canKill && !gameState.meetingCalled) handleKill(p.id);
                      if (canSelect) setSelectedPlayer(p.id);
                    }}
                    disabled={isDead && !canSelect}
                    className={`relative flex flex-col items-center p-4 rounded-2xl border-2 transition-all duration-300 ${
                      isDead ? 'opacity-50 border-red-500/30 bg-red-900/20' :
                      isKilling ? 'border-red-500 bg-red-500/30 animate-pulse' :
                      selectedPlayer === p.id ? 'border-yellow-400 bg-yellow-500/20' :
                      isMe ? 'border-purple-400 bg-purple-500/20' :
                      canKill ? 'border-white/20 bg-white/5 hover:border-red-400 hover:bg-red-500/10 cursor-pointer' :
                      'border-white/10 bg-white/5'
                    }`}
                  >
                    <div className={`text-4xl mb-2 transition-transform ${isKilling ? 'animate-bounce' : ''}`}>
                      {isDead ? '💀' : AVATARS[i % AVATARS.length]}
                    </div>
                    <span className={`font-medium text-sm ${isDead ? 'text-red-400 line-through' : 'text-white'}`}>{p.name}</span>
                    {isMe && <span className="text-xs text-purple-300 mt-1">(You)</span>}
                    {isDead && <span className="text-xs text-red-400 mt-1">Eliminated</span>}
                    {amMurderer && canKill && !gameState.meetingCalled && (
                      <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">Kill</span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Detective Controls */}
            {amDetective && amAlive && !gameState.gameOver && (
              <div className="bg-blue-500/10 border border-blue-400/30 rounded-2xl p-4 mb-4">
                <h3 className="text-blue-300 font-bold mb-2 flex items-center gap-2">
                  <Eye className="w-5 h-5" /> Detective Actions
                  <span className="text-sm font-normal ml-auto">Guesses left: {gameState.detectiveGuessesLeft}</span>
                </h3>
                {!gameState.meetingCalled ? (
                  <button onClick={handleCallMeeting} className="w-full py-3 bg-blue-500/30 text-blue-200 rounded-xl hover:bg-blue-500/50 transition font-bold flex items-center justify-center gap-2">
                    <AlertTriangle className="w-5 h-5" /> Call Meeting to Accuse
                  </button>
                ) : (
                  <div className="space-y-2">
                    <p className="text-blue-200 text-sm">Select a player above, then accuse:</p>
                    <button
                      onClick={handleAccuse}
                      disabled={!selectedPlayer}
                      className="w-full py-3 bg-yellow-500/30 text-yellow-200 rounded-xl hover:bg-yellow-500/50 disabled:opacity-40 disabled:cursor-not-allowed transition font-bold"
                    >
                      Accuse {selectedPlayer ? room?.players.find(p => p.id === selectedPlayer)?.name : '...'}
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* Status */}
            {!amAlive && !gameState.gameOver && (
              <div className="bg-red-500/10 border border-red-400/30 rounded-2xl p-4 text-center">
                <Skull className="w-8 h-8 text-red-400 mx-auto mb-2" />
                <p className="text-red-300 font-bold">You have been eliminated! Watch the game unfold…</p>
              </div>
            )}

            {/* Info for Civilians */}
            {myRole === 'civilian' && amAlive && !gameState.gameOver && (
              <div className="bg-green-500/10 border border-green-400/30 rounded-2xl p-4 text-center">
                <Users className="w-8 h-8 text-green-400 mx-auto mb-2" />
                <p className="text-green-300 font-bold">You are a Civilian. Stay alive and help the detective!</p>
              </div>
            )}

            {/* Info for Murderer */}
            {amMurderer && !gameState.gameOver && (
              <div className="bg-red-500/10 border border-red-400/30 rounded-2xl p-4 text-center mt-4">
                <Skull className="w-6 h-6 text-red-400 mx-auto mb-2" />
                <p className="text-red-300 text-sm">Click on a player's avatar to eliminate them secretly. Don't get caught!</p>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
