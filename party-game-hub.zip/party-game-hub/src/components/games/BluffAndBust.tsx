import { useEffect, useState } from 'react';
import { useRoom } from '../../contexts/RoomContext';
import type { BluffAndBustState, Card, Rank } from '../../types';
import { ArrowLeft, AlertCircle } from 'lucide-react';

const RANKS: Rank[] = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];

const SUIT_DISPLAY: Record<string, string> = {
  hearts: '♥',
  diamonds: '♦',
  clubs: '♣',
  spades: '♠',
};

const SUIT_COLOR: Record<string, string> = {
  hearts: 'text-red-400',
  diamonds: 'text-red-400',
  clubs: 'text-white',
  spades: 'text-white',
};

const DEFAULT_STATE: BluffAndBustState = {
  hands: {},
  pile: [],
  currentPlayerIndex: 0,
  turnOrder: [],
  currentClaimedRank: null,
  lastMove: null,
  bluffCalled: false,
  bluffCallerId: null,
  bluffResult: null,
  gameOver: false,
  winnerId: null,
  message: 'Waiting to start…',
};

export default function BluffAndBust() {
  const { room, myId, sendAction, onSyncState, backToLobby, myPlayer } = useRoom();
  const [gameState, setGameState] = useState<BluffAndBustState>(DEFAULT_STATE);
  const [selectedCards, setSelectedCards] = useState<string[]>([]);
  const [claimedRank, setClaimedRank] = useState<Rank>('A');
  const [showBluffResult, setShowBluffResult] = useState(false);

  const myHand = gameState.hands[myId] || [];
  const isMyTurn = gameState.turnOrder[gameState.currentPlayerIndex] === myId;
  const currentPlayerId = gameState.turnOrder[gameState.currentPlayerIndex];
  const currentPlayerName = room?.players.find(p => p.id === currentPlayerId)?.name || '???';

  useEffect(() => {
    const unsub = onSyncState((state) => {
      const s = state as BluffAndBustState;
      setGameState(s);
      if (s.bluffResult) {
        setShowBluffResult(true);
        setTimeout(() => setShowBluffResult(false), 3000);
      }
    });
    return unsub;
  }, [onSyncState]);

  const toggleCard = (cardId: string) => {
    setSelectedCards(prev =>
      prev.includes(cardId) ? prev.filter(c => c !== cardId) : [...prev, cardId]
    );
  };

  const handlePlayCards = () => {
    if (!room || selectedCards.length === 0) return;
    sendAction({
      type: 'bluff-play',
      roomId: room.roomId,
      playerId: myId,
      payload: { cardIds: selectedCards, claimedRank },
    });
    setSelectedCards([]);
  };

  const handleCallBluff = () => {
    if (!room) return;
    sendAction({
      type: 'bluff-call',
      roomId: room.roomId,
      playerId: myId,
      payload: null,
    });
  };

  const handleStartGame = () => {
    if (!room) return;
    sendAction({
      type: 'bluff-start',
      roomId: room.roomId,
      playerId: myId,
      payload: null,
    });
  };

  const renderCard = (card: Card, selectable = false) => {
    const isSelected = selectedCards.includes(card.id);
    return (
      <button
        key={card.id}
        onClick={() => selectable && toggleCard(card.id)}
        className={`relative w-16 h-24 sm:w-20 sm:h-28 rounded-xl border-2 flex flex-col items-center justify-center transition-all ${
          isSelected
            ? 'border-yellow-400 bg-yellow-500/20 -translate-y-3 shadow-lg shadow-yellow-500/20'
            : 'border-white/20 bg-white/5 hover:border-white/40 hover:bg-white/10'
        } ${selectable ? 'cursor-pointer' : ''}`}
      >
        <span className={`text-lg font-black ${SUIT_COLOR[card.suit]}`}>{card.rank}</span>
        <span className={`text-xl ${SUIT_COLOR[card.suit]}`}>{SUIT_DISPLAY[card.suit]}</span>
      </button>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-950 via-green-900 to-teal-950 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <button onClick={backToLobby} className="flex items-center gap-1 text-green-300 hover:text-white transition text-sm">
            <ArrowLeft className="w-4 h-4" /> Lobby
          </button>
          <h2 className="text-2xl font-black text-white">🃏 Bluff & Bust</h2>
          <div className="text-green-200 text-sm">Pile: {gameState.pile.length} cards</div>
        </div>

        {/* Message */}
        <div className={`text-center mb-4 p-3 rounded-xl border transition-all ${
          showBluffResult
            ? gameState.bluffResult === 'bluff'
              ? 'bg-red-500/20 border-red-400/40 text-red-200'
              : 'bg-green-500/20 border-green-400/40 text-green-200'
            : 'bg-white/10 border-white/20 text-white'
        }`}>
          <p className="font-bold">{gameState.message}</p>
        </div>

        {/* Game Over */}
        {gameState.gameOver && (
          <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-8 text-center mb-6">
            <div className="text-5xl mb-4">🏆</div>
            <h3 className="text-3xl font-black text-white mb-2">
              {room?.players.find(p => p.id === gameState.winnerId)?.name} Wins!
            </h3>
            {myPlayer?.isHost && (
              <button onClick={backToLobby} className="mt-4 px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white font-bold rounded-xl hover:from-green-600 hover:to-emerald-600 transition">
                Back to Lobby
              </button>
            )}
          </div>
        )}

        {/* Pre-game */}
        {gameState.turnOrder.length === 0 && !gameState.gameOver && (
          <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-8 text-center mb-6">
            <div className="text-5xl mb-4">🃏</div>
            <h3 className="text-xl text-white font-bold mb-2">Ready to play Bluff & Bust?</h3>
            <p className="text-green-300 text-sm mb-4">Play cards face-down, claim a rank, and challenge bluffs!</p>
            {myPlayer?.isHost && (
              <button onClick={handleStartGame} className="px-6 py-3 bg-gradient-to-r from-green-500 to-teal-500 text-white font-bold rounded-xl hover:from-green-600 hover:to-teal-600 transition">
                Deal Cards & Start
              </button>
            )}
          </div>
        )}

        {/* Game Board */}
        {gameState.turnOrder.length > 0 && !gameState.gameOver && (
          <>
            {/* Other Players */}
            <div className="flex justify-center gap-4 mb-6 flex-wrap">
              {room?.players.filter(p => p.id !== myId).map(p => {
                const hand = gameState.hands[p.id] || [];
                const isTurn = gameState.turnOrder[gameState.currentPlayerIndex] === p.id;
                return (
                  <div key={p.id} className={`flex flex-col items-center p-3 rounded-xl border-2 transition-all ${
                    isTurn ? 'border-yellow-400 bg-yellow-500/10' : 'border-white/10 bg-white/5'
                  }`}>
                    <span className="text-white font-medium text-sm">{p.name}</span>
                    <span className="text-green-300 text-xs">{hand.length} cards</span>
                    {isTurn && <span className="text-yellow-300 text-xs mt-1 animate-pulse">Playing…</span>}
                  </div>
                );
              })}
            </div>

            {/* Center Pile */}
            <div className="flex justify-center mb-6">
              <div className="bg-green-800/50 border-2 border-green-600/30 rounded-2xl p-6 min-w-48 text-center">
                <div className="text-3xl mb-2">📦</div>
                <p className="text-green-200 font-bold">{gameState.pile.length} cards in pile</p>
                {gameState.lastMove && (
                  <p className="text-green-300 text-sm mt-2">
                    Last play: {gameState.lastMove.cardCount} × {gameState.lastMove.claimedRank}
                  </p>
                )}
              </div>
            </div>

            {/* Bluff Button */}
            {gameState.lastMove && gameState.lastMove.playerId !== myId && !isMyTurn && (
              <div className="flex justify-center mb-6">
                <button
                  onClick={handleCallBluff}
                  className="px-8 py-4 bg-gradient-to-r from-red-500 to-orange-500 text-white font-black text-xl rounded-2xl hover:from-red-600 hover:to-orange-600 transition-all shadow-lg hover:shadow-red-500/25 flex items-center gap-2 animate-pulse"
                >
                  <AlertCircle className="w-6 h-6" /> BLUFF!
                </button>
              </div>
            )}

            {/* My Hand */}
            <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-white font-bold">Your Hand ({myHand.length} cards)</h3>
                {isMyTurn && <span className="text-yellow-300 text-sm animate-pulse font-bold">Your Turn!</span>}
              </div>

              <div className="flex flex-wrap gap-2 mb-4 justify-center">
                {myHand.map(card => renderCard(card, isMyTurn))}
              </div>

              {/* Play Controls */}
              {isMyTurn && (
                <div className="flex items-center gap-3 pt-3 border-t border-white/10">
                  <div className="flex items-center gap-2">
                    <span className="text-green-200 text-sm">Claim rank:</span>
                    <select
                      value={claimedRank}
                      onChange={e => setClaimedRank(e.target.value as Rank)}
                      className="px-3 py-2 rounded-lg bg-white/10 border border-white/20 text-white text-sm focus:outline-none focus:ring-2 focus:ring-green-400"
                    >
                      {RANKS.map(r => (
                        <option key={r} value={r} className="bg-gray-800">{r}</option>
                      ))}
                    </select>
                  </div>
                  <button
                    onClick={handlePlayCards}
                    disabled={selectedCards.length === 0}
                    className="flex-1 py-3 bg-gradient-to-r from-green-500 to-teal-500 text-white font-bold rounded-xl hover:from-green-600 hover:to-teal-600 disabled:opacity-40 disabled:cursor-not-allowed transition"
                  >
                    Play {selectedCards.length} card{selectedCards.length !== 1 ? 's' : ''} as {claimedRank}
                  </button>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
