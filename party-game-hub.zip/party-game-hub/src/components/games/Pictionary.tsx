import { useEffect, useRef, useState, useCallback } from 'react';
import { useRoom } from '../../contexts/RoomContext';
import type { PictionaryState, DrawPoint, ChatMessage } from '../../types';
import { Palette, Clock, Send, ArrowLeft, Eraser } from 'lucide-react';

const COLORS = ['#000000', '#EF4444', '#F97316', '#EAB308', '#22C55E', '#3B82F6', '#8B5CF6', '#EC4899', '#FFFFFF'];
const SIZES = [3, 6, 10, 16];

const DEFAULT_STATE: PictionaryState = {
  drawerId: '',
  word: '',
  maskedWord: '_ _ _ _ _',
  guesses: [],
  roundTime: 60,
  timeLeft: 60,
  scores: {},
  round: 1,
  totalRounds: 3,
  canvas: [],
  isRoundActive: false,
};

export default function Pictionary() {
  const { room, myId, sendAction, onSyncState, onGameAction, backToLobby, myPlayer } = useRoom();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [gameState, setGameState] = useState<PictionaryState>(DEFAULT_STATE);
  const [brushColor, setBrushColor] = useState('#000000');
  const [brushSize, setBrushSize] = useState(6);
  const [guess, setGuess] = useState('');
  const [isDrawing, setIsDrawing] = useState(false);

  const isDrawer = myId === gameState.drawerId;

  // Sync game state from server
  useEffect(() => {
    const unsub = onSyncState((state) => {
      setGameState(state as PictionaryState);
    });
    return unsub;
  }, [onSyncState]);

  // Handle incoming draw actions
  useEffect(() => {
    const unsub = onGameAction((action) => {
      if (action.type === 'pictionary-draw') {
        const point = action.payload as DrawPoint;
        drawOnCanvas(point);
      }
      if (action.type === 'pictionary-clear') {
        clearCanvas();
      }
    });
    return unsub;
  }, [onGameAction]);

  const drawOnCanvas = useCallback((point: DrawPoint) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    if (point.type === 'start') {
      ctx.beginPath();
      ctx.moveTo(point.x, point.y);
    } else if (point.type === 'draw') {
      ctx.lineTo(point.x, point.y);
      ctx.strokeStyle = point.color;
      ctx.lineWidth = point.size;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.stroke();
    }
  }, []);

  const clearCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }, []);

  useEffect(() => {
    clearCanvas();
  }, [clearCanvas]);

  const getCanvasCoords = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    return {
      x: ((e.clientX - rect.left) / rect.width) * canvas.width,
      y: ((e.clientY - rect.top) / rect.height) * canvas.height,
    };
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawer || !room) return;
    setIsDrawing(true);
    const { x, y } = getCanvasCoords(e);
    const point: DrawPoint = { x, y, color: brushColor, size: brushSize, type: 'start' };
    drawOnCanvas(point);
    sendAction({ type: 'pictionary-draw', roomId: room.roomId, playerId: myId, payload: point });
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !isDrawer || !room) return;
    const { x, y } = getCanvasCoords(e);
    const point: DrawPoint = { x, y, color: brushColor, size: brushSize, type: 'draw' };
    drawOnCanvas(point);
    sendAction({ type: 'pictionary-draw', roomId: room.roomId, playerId: myId, payload: point });
  };

  const handleMouseUp = () => {
    setIsDrawing(false);
  };

  const handleClear = () => {
    if (!room) return;
    clearCanvas();
    sendAction({ type: 'pictionary-clear', roomId: room.roomId, playerId: myId, payload: null });
  };

  const handleGuess = () => {
    if (!guess.trim() || !room) return;
    sendAction({
      type: 'pictionary-guess',
      roomId: room.roomId,
      playerId: myId,
      payload: { message: guess.trim() },
    });
    setGuess('');
  };

  const handleStartRound = () => {
    if (!room) return;
    sendAction({ type: 'pictionary-start-round', roomId: room.roomId, playerId: myId, payload: null });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-950 via-purple-900 to-indigo-950 p-4">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <button onClick={backToLobby} className="flex items-center gap-1 text-purple-300 hover:text-white transition text-sm">
            <ArrowLeft className="w-4 h-4" /> Lobby
          </button>
          <div className="flex items-center gap-4">
            <span className="text-purple-200 text-sm">Round {gameState.round}/{gameState.totalRounds}</span>
            <div className="flex items-center gap-1 text-white bg-white/10 px-3 py-1 rounded-lg">
              <Clock className="w-4 h-4 text-yellow-400" />
              <span className="font-mono font-bold">{gameState.timeLeft}s</span>
            </div>
          </div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Palette className="w-5 h-5 text-pink-400" /> Pictionary
          </h2>
        </div>

        {/* Word Display */}
        <div className="text-center mb-4">
          {isDrawer ? (
            <div className="inline-block bg-green-500/20 border border-green-400/40 rounded-xl px-6 py-2">
              <span className="text-green-300 text-sm">Your word:</span>
              <span className="text-white font-bold text-xl ml-2">{gameState.word || '???'}</span>
            </div>
          ) : (
            <div className="inline-block bg-white/10 border border-white/20 rounded-xl px-6 py-2">
              <span className="text-purple-300 text-sm">Guess:</span>
              <span className="text-white font-bold text-xl ml-2 tracking-[0.3em]">{gameState.maskedWord}</span>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Canvas Area */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl overflow-hidden shadow-xl">
              <canvas
                ref={canvasRef}
                width={800}
                height={500}
                onMouseDown={handleMouseDown}
                onMouseMove={handleMouseMove}
                onMouseUp={handleMouseUp}
                onMouseLeave={handleMouseUp}
                className={`w-full aspect-[8/5] ${isDrawer ? 'cursor-crosshair' : 'cursor-default'}`}
              />
            </div>

            {/* Drawing Tools */}
            {isDrawer && (
              <div className="flex items-center gap-4 mt-3 p-3 bg-white/10 rounded-xl">
                <div className="flex gap-1">
                  {COLORS.map(c => (
                    <button
                      key={c}
                      onClick={() => setBrushColor(c)}
                      className={`w-7 h-7 rounded-full border-2 transition ${brushColor === c ? 'border-white scale-110' : 'border-transparent'}`}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
                <div className="flex gap-1">
                  {SIZES.map(s => (
                    <button
                      key={s}
                      onClick={() => setBrushSize(s)}
                      className={`w-8 h-8 rounded-lg flex items-center justify-center transition ${brushSize === s ? 'bg-white/30 text-white' : 'bg-white/10 text-white/60'}`}
                    >
                      <div className="rounded-full bg-current" style={{ width: s, height: s }} />
                    </button>
                  ))}
                </div>
                <button onClick={handleClear} className="flex items-center gap-1 px-3 py-1.5 bg-red-500/30 text-red-300 rounded-lg hover:bg-red-500/50 transition text-sm">
                  <Eraser className="w-4 h-4" /> Clear
                </button>
              </div>
            )}

            {/* Start Round Button */}
            {!gameState.isRoundActive && myPlayer?.isHost && (
              <button onClick={handleStartRound} className="mt-3 w-full py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white font-bold rounded-xl hover:from-green-600 hover:to-emerald-600 transition">
                Start Round
              </button>
            )}
          </div>

          {/* Chat / Scores */}
          <div className="flex flex-col gap-4">
            {/* Scores */}
            <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-4">
              <h3 className="text-white font-bold mb-2">Scores</h3>
              {room?.players.map(p => (
                <div key={p.id} className={`flex items-center justify-between py-1 ${p.id === gameState.drawerId ? 'text-yellow-300' : 'text-white'}`}>
                  <span className="text-sm">{p.name} {p.id === gameState.drawerId ? '🎨' : ''}</span>
                  <span className="font-mono font-bold">{gameState.scores[p.id] || 0}</span>
                </div>
              ))}
            </div>

            {/* Chat */}
            <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-4 flex-1 flex flex-col">
              <h3 className="text-white font-bold mb-2">Guesses</h3>
              <div className="flex-1 overflow-y-auto space-y-1 mb-3 max-h-64">
                {gameState.guesses.map((g, i) => (
                  <div key={i} className={`text-sm p-1.5 rounded-lg ${g.isCorrect ? 'bg-green-500/20 text-green-300' : 'text-purple-200'}`}>
                    <span className="font-bold">{g.playerName}:</span> {g.isCorrect ? '✅ Correct!' : g.message}
                  </div>
                ))}
              </div>
              {!isDrawer && (
                <div className="flex gap-2">
                  <input
                    value={guess}
                    onChange={e => setGuess(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && handleGuess()}
                    placeholder="Type your guess…"
                    className="flex-1 px-3 py-2 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/40 text-sm focus:outline-none focus:ring-2 focus:ring-purple-400"
                  />
                  <button onClick={handleGuess} className="p-2 bg-purple-500 rounded-lg text-white hover:bg-purple-600 transition">
                    <Send className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
