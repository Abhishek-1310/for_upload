import { useState } from 'react';
import { useRoom } from '../contexts/RoomContext';
import { Users, Gamepad2, Wifi, WifiOff, Crown, Copy, Check } from 'lucide-react';
import type { GameType } from '../types';

const AVATARS = ['🦊', '🐱', '🐶', '🦁', '🐸'];

const GAMES: { type: GameType; name: string; desc: string; emoji: string }[] = [
  { type: 'pictionary', name: 'Pictionary', desc: 'Draw & Guess words in real-time', emoji: '🎨' },
  { type: 'wink-murder', name: 'Wink Murder', desc: 'Find the secret murderer!', emoji: '🔍' },
  { type: 'bluff-and-bust', name: 'Bluff & Bust', desc: 'Play cards & call out bluffs', emoji: '🃏' },
];

export default function Lobby() {
  const { room, myPlayer, isConnected, joinRoom, startGame } = useRoom();
  const [playerName, setPlayerName] = useState('');
  const [roomInput, setRoomInput] = useState('');
  const [copied, setCopied] = useState(false);

  const handleJoin = () => {
    if (!playerName.trim()) return;
    const rid = roomInput.trim() || Math.random().toString(36).substring(2, 8).toUpperCase();
    setRoomInput(rid);
    joinRoom(rid, playerName.trim());
  };

  const copyRoomId = () => {
    if (!room) return;
    navigator.clipboard.writeText(room.roomId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // ── Join Screen ─────────────────────────────────────
  if (!room) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-violet-950 via-purple-900 to-indigo-950 flex items-center justify-center p-4">
        <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl p-8 w-full max-w-md shadow-2xl">
          <div className="text-center mb-8">
            <div className="text-6xl mb-3">🎮</div>
            <p className="text-purple-300 text-sm font-medium mb-1">Welcome to</p>
            <h1 className="text-4xl font-black text-white tracking-tight">Abhishek's Game Hub</h1>
            <p className="text-purple-200 mt-2">Up to 5 players • 3 awesome games</p>
          </div>

          <div className="flex items-center gap-2 mb-6 text-sm">
            {isConnected ? (
              <><Wifi className="w-4 h-4 text-green-400" /><span className="text-green-400">Connected</span></>
            ) : (
              <><WifiOff className="w-4 h-4 text-red-400" /><span className="text-red-400">Connecting…</span></>
            )}
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-purple-200 text-sm font-medium mb-1 block">Your Name</label>
              <input
                value={playerName}
                onChange={e => setPlayerName(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleJoin()}
                placeholder="Enter your name"
                maxLength={16}
                className="w-full px-4 py-3 rounded-xl bg-white/10 border border-white/20 text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-purple-400 transition"
              />
            </div>
            <div>
              <label className="text-purple-200 text-sm font-medium mb-1 block">Room Code (leave blank to create)</label>
              <input
                value={roomInput}
                onChange={e => setRoomInput(e.target.value.toUpperCase())}
                onKeyDown={e => e.key === 'Enter' && handleJoin()}
                placeholder="e.g. ABC123"
                maxLength={8}
                className="w-full px-4 py-3 rounded-xl bg-white/10 border border-white/20 text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-purple-400 transition uppercase tracking-widest"
              />
            </div>
            <button
              onClick={handleJoin}
              disabled={!playerName.trim() || !isConnected}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-purple-500 to-pink-500 text-white font-bold text-lg hover:from-purple-600 hover:to-pink-600 disabled:opacity-40 disabled:cursor-not-allowed transition-all shadow-lg hover:shadow-purple-500/25"
            >
              {roomInput ? 'Join Room' : 'Create Room'}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ── Lobby Screen ────────────────────────────────────
  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-950 via-purple-900 to-indigo-950 p-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-2xl font-black text-white flex items-center gap-2">
                <Gamepad2 className="w-7 h-7 text-purple-300" /> Game Lobby
              </h2>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-purple-300 text-sm">Room:</span>
                <span className="font-mono font-bold text-white tracking-widest text-lg">{room.roomId}</span>
                <button onClick={copyRoomId} className="text-purple-300 hover:text-white transition">
                  {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>
            <div className="text-right">
              <div className="flex items-center gap-1 text-purple-200">
                <Users className="w-4 h-4" />
                <span className="text-sm">{room.players.length}/5 players</span>
              </div>
            </div>
          </div>

          {/* Player List */}
          <div className="grid grid-cols-5 gap-3">
            {room.players.map((p, i) => (
              <div key={p.id} className={`flex flex-col items-center p-3 rounded-xl border transition-all ${p.id === myPlayer?.id ? 'bg-purple-500/30 border-purple-400' : 'bg-white/5 border-white/10'}`}>
                <div className="text-3xl mb-1">{AVATARS[i % AVATARS.length]}</div>
                <span className="text-white text-sm font-medium truncate w-full text-center">{p.name}</span>
                {p.isHost && <Crown className="w-4 h-4 text-yellow-400 mt-1" />}
              </div>
            ))}
            {Array.from({ length: 5 - room.players.length }).map((_, i) => (
              <div key={`empty-${i}`} className="flex flex-col items-center p-3 rounded-xl border border-dashed border-white/10">
                <div className="text-3xl mb-1 opacity-20">👤</div>
                <span className="text-white/30 text-sm">Waiting…</span>
              </div>
            ))}
          </div>
        </div>

        {/* Game Selection */}
        <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-6">
          <h3 className="text-xl font-bold text-white mb-4">Choose a Game</h3>
          <div className="space-y-3">
            {GAMES.map(g => (
              <button
                key={g.type}
                onClick={() => startGame(g.type)}
                disabled={!myPlayer?.isHost || room.players.length < 2}
                className="w-full flex items-center gap-4 p-4 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 hover:border-purple-400/50 disabled:opacity-40 disabled:cursor-not-allowed transition-all text-left group"
              >
                <span className="text-4xl group-hover:scale-110 transition-transform">{g.emoji}</span>
                <div>
                  <div className="text-white font-bold text-lg">{g.name}</div>
                  <div className="text-purple-300 text-sm">{g.desc}</div>
                </div>
              </button>
            ))}
          </div>
          {!myPlayer?.isHost && (
            <p className="text-purple-300 text-sm mt-4 text-center">Waiting for the host to pick a game…</p>
          )}
          {myPlayer?.isHost && room.players.length < 2 && (
            <p className="text-yellow-300 text-sm mt-4 text-center">Need at least 2 players to start</p>
          )}
        </div>
      </div>
    </div>
  );
}
