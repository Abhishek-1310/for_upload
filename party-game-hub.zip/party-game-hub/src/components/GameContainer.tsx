import { useRoom } from '../contexts/RoomContext';
import Lobby from './Lobby';
import Pictionary from './games/Pictionary';
import WinkMurder from './games/WinkMurder';
import BluffAndBust from './games/BluffAndBust';
import Results from './Results';

export default function GameContainer() {
  const { room } = useRoom();

  if (!room || room.gameStatus === 'lobby') {
    return <Lobby />;
  }

  if (room.gameStatus === 'results') {
    return <Results />;
  }

  switch (room.activeGame) {
    case 'pictionary':
      return <Pictionary />;
    case 'wink-murder':
      return <WinkMurder />;
    case 'bluff-and-bust':
      return <BluffAndBust />;
    default:
      return <Lobby />;
  }
}
