import { useEffect, useRef, useCallback, useState } from 'react';
import { io, Socket } from 'socket.io-client';
import type { ServerToClientEvents, ClientToServerEvents, GameAction, RoomState, GameType } from '../types';

const SERVER_URL = import.meta.env.VITE_SERVER_URL || 'http://localhost:3001';

type AppSocket = Socket<ServerToClientEvents, ClientToServerEvents>;

export function useSocket() {
  const socketRef = useRef<AppSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    const socket: AppSocket = io(SERVER_URL, {
      autoConnect: true,
      transports: ['websocket', 'polling'],
    });

    socket.on('connect', () => setIsConnected(true));
    socket.on('disconnect', () => setIsConnected(false));

    socketRef.current = socket;

    return () => {
      socket.disconnect();
    };
  }, []);

  const joinRoom = useCallback((roomId: string, playerName: string) => {
    socketRef.current?.emit('join-room', { roomId, playerName });
  }, []);

  const startGame = useCallback((roomId: string, gameType: GameType) => {
    socketRef.current?.emit('start-game', { roomId, gameType });
  }, []);

  const sendAction = useCallback((action: GameAction) => {
    socketRef.current?.emit('game-action', action);
  }, []);

  const onRoomState = useCallback((cb: (state: RoomState) => void) => {
    socketRef.current?.on('room-state', cb);
    return () => { socketRef.current?.off('room-state', cb); };
  }, []);

  const onSyncState = useCallback((cb: (state: unknown) => void) => {
    socketRef.current?.on('sync-state', cb as never);
    return () => { socketRef.current?.off('sync-state', cb as never); };
  }, []);

  const onGameAction = useCallback((cb: (action: GameAction) => void) => {
    socketRef.current?.on('game-action', cb);
    return () => { socketRef.current?.off('game-action', cb); };
  }, []);

  const onError = useCallback((cb: (msg: string) => void) => {
    socketRef.current?.on('error', cb);
    return () => { socketRef.current?.off('error', cb); };
  }, []);

  return {
    socket: socketRef,
    isConnected,
    joinRoom,
    startGame,
    sendAction,
    onRoomState,
    onSyncState,
    onGameAction,
    onError,
  };
}
