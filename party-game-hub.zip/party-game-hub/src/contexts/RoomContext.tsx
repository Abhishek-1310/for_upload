import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react';
import type { RoomState, Player, GameType, GameStatus, GameAction } from '../types';
import { useSocket } from '../hooks/useSocket';

interface RoomContextValue {
  room: RoomState | null;
  myPlayer: Player | null;
  myId: string;
  isConnected: boolean;
  joinRoom: (roomId: string, playerName: string) => void;
  startGame: (gameType: GameType) => void;
  sendAction: (action: GameAction) => void;
  setRoom: React.Dispatch<React.SetStateAction<RoomState | null>>;
  onSyncState: (cb: (state: unknown) => void) => (() => void) | undefined;
  onGameAction: (cb: (action: GameAction) => void) => (() => void) | undefined;
  backToLobby: () => void;
}

const RoomContext = createContext<RoomContextValue | null>(null);

export function RoomProvider({ children }: { children: ReactNode }) {
  const [room, setRoom] = useState<RoomState | null>(null);
  const [myId, setMyId] = useState('');
  const sock = useSocket();

  useEffect(() => {
    const unsub = sock.onRoomState((state: RoomState) => {
      setRoom(state);
      // The server sends us our id embedded - we detect ourselves by latest join
      if (!myId && state.players.length > 0) {
        setMyId(state.players[state.players.length - 1].id);
      }
    });
    return unsub;
  }, [sock, myId]);

  useEffect(() => {
    const unsub = sock.onError((msg: string) => {
      console.error('Socket error:', msg);
      alert(msg);
    });
    return unsub;
  }, [sock]);

  const joinRoom = useCallback((roomId: string, playerName: string) => {
    sock.joinRoom(roomId, playerName);
  }, [sock]);

  const startGame = useCallback((gameType: GameType) => {
    if (!room) return;
    sock.startGame(room.roomId, gameType);
  }, [sock, room]);

  const sendAction = useCallback((action: GameAction) => {
    sock.sendAction(action);
  }, [sock]);

  const backToLobby = useCallback(() => {
    if (!room) return;
    sock.sendAction({
      type: 'back-to-lobby',
      roomId: room.roomId,
      playerId: myId,
      payload: null,
    });
  }, [sock, room, myId]);

  const myPlayer = room?.players.find(p => p.id === myId) ?? null;

  return (
    <RoomContext.Provider value={{
      room, myPlayer, myId, isConnected: sock.isConnected,
      joinRoom, startGame, sendAction, setRoom,
      onSyncState: sock.onSyncState,
      onGameAction: sock.onGameAction,
      backToLobby,
    }}>
      {children}
    </RoomContext.Provider>
  );
}

export function useRoom() {
  const ctx = useContext(RoomContext);
  if (!ctx) throw new Error('useRoom must be used within RoomProvider');
  return ctx;
}

export type { GameStatus, GameType };
