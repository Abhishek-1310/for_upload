// ─── Player ───────────────────────────────────────────
export interface Player {
  id: string;
  name: string;
  avatar: string;
  isHost: boolean;
  isConnected: boolean;
}

// ─── Room / Lobby ─────────────────────────────────────
export type GameStatus = 'lobby' | 'playing' | 'results';
export type GameType = 'pictionary' | 'wink-murder' | 'bluff-and-bust';

export interface RoomState {
  roomId: string;
  players: Player[];
  gameStatus: GameStatus;
  activeGame: GameType | null;
  hostId: string;
}

// ─── Pictionary ───────────────────────────────────────
export interface DrawPoint {
  x: number;
  y: number;
  color: string;
  size: number;
  type: 'start' | 'draw' | 'end';
}

export interface PictionaryState {
  drawerId: string;
  word: string;
  maskedWord: string;
  guesses: ChatMessage[];
  roundTime: number;
  timeLeft: number;
  scores: Record<string, number>;
  round: number;
  totalRounds: number;
  canvas: DrawPoint[];
  isRoundActive: boolean;
}

export interface ChatMessage {
  playerId: string;
  playerName: string;
  message: string;
  isCorrect: boolean;
  timestamp: number;
}

// ─── Wink Murder ──────────────────────────────────────
export type WinkRole = 'murderer' | 'detective' | 'civilian';

export interface WinkMurderState {
  roles: Record<string, WinkRole>;
  alivePlayerIds: string[];
  deadPlayerIds: string[];
  detectiveId: string;
  murdererId: string;
  meetingCalled: boolean;
  accusation: string | null;
  gameOver: boolean;
  winner: 'murderer' | 'detective' | null;
  detectiveGuessesLeft: number;
}

// ─── Bluff & Bust (Cheat) ────────────────────────────
export type Suit = 'hearts' | 'diamonds' | 'clubs' | 'spades';
export type Rank = 'A' | '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' | '10' | 'J' | 'Q' | 'K';

export interface Card {
  id: string;
  suit: Suit;
  rank: Rank;
}

export interface BluffMove {
  playerId: string;
  claimedRank: Rank;
  actualCards: Card[];
  cardCount: number;
}

export interface BluffAndBustState {
  hands: Record<string, Card[]>;
  pile: Card[];
  currentPlayerIndex: number;
  turnOrder: string[];
  currentClaimedRank: Rank | null;
  lastMove: BluffMove | null;
  bluffCalled: boolean;
  bluffCallerId: string | null;
  bluffResult: 'honest' | 'bluff' | null;
  gameOver: boolean;
  winnerId: string | null;
  message: string;
}

// ─── Socket Events ────────────────────────────────────
export interface ServerToClientEvents {
  'room-state': (state: RoomState) => void;
  'sync-state': (state: PictionaryState | WinkMurderState | BluffAndBustState) => void;
  'game-action': (action: GameAction) => void;
  'error': (message: string) => void;
  'player-joined': (player: Player) => void;
  'player-left': (playerId: string) => void;
}

export interface ClientToServerEvents {
  'join-room': (data: { roomId: string; playerName: string }) => void;
  'start-game': (data: { roomId: string; gameType: GameType }) => void;
  'game-action': (action: GameAction) => void;
  'sync-state': (data: { roomId: string; state: unknown }) => void;
}

export interface GameAction {
  type: string;
  roomId: string;
  playerId: string;
  payload: unknown;
}
